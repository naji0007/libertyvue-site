# LibertyVue Player for Android TV

Native Android TV / Google TV / Fire TV player with:

- M3U and M3U8 playlist URLs
- compatible Xtream Codes portal logins
- Live TV, movie, series and episode browsing
- Media3 / ExoPlayer playback, including HLS and DASH
- encrypted local storage for playlist credentials
- a device ID, device key and seven-day local beta trial
- D-pad-friendly Compose interface
- a French TV dashboard with separate saved M3U and Xtream connections
- Live with EPG: selected-channel preview, current/upcoming programmes and fullscreen playback
- XMLTV / XMLTV.gz via an optional playlist URL or M3U header; matches exact `tvg-id` values
- Xtream short EPG from the provider, without downloading the full guide
- 2/4-screen live playback, selectable audio and per-screen channel selection

## Version 0.16 notes

Opening a connection loads live channels first, so the dashboard appears
immediately even on huge providers. Movies and series load on demand when
their section opens, with a small loading message that disappears once the
section arrives. Refresh reloads live, then the already-opened sections.

## Version 0.15 notes

The home screen now opens on a centered hero logo with the connection type choice
(M3U / M3U8 or Xtream Codes) in the middle; saved connections of the chosen type
appear below. Sync, website, add and settings actions moved to the top side.
The home and dashboard footers show the Xtream subscription expiry date
(`exp_date`) when the provider supplies one. Channel artwork accepts
protocol-relative URLs and unencoded spaces, with a monogram fallback (initial
letter) for channels, movies and series, and a larger live grid. Exiting the
player returns the guide to the watched channel. Xtream categories and catalogs
load in parallel for faster entry. User-facing errors and messages follow the
device language (French, English, Arabic). Huge providers (100k+ entries) load
progressively: the dashboard appears with the first channels while movies and
series keep arriving in the background.

## Version 0.14 notes

The Android TV dashboard and settings now show the exact annual licence expiry date alongside the
remaining days. The application ID and release certificate remain unchanged so a signed 0.14.0 build
can update an installed release in place.

## Version 0.12 notes

Xtream live streams now honour the provider's `stream_type` and request HLS (`.m3u8`) when supplied;
the player also tries the other live extension once when a provider accepts both forms. This helps
UHD channels whose `.ts` endpoint is not the compatible rendition. Channel artwork retries the
opposite HTTP/HTTPS scheme when a provider's image certificate is misconfigured, and channel names
use two lines in the browse grid so UHD/event labels remain readable. A fixed 3840p stream with no
HD/HLS rendition still requires a compatible alternative from the provider.

## Version 0.11 notes

On phones, adaptive HLS/DASH playback requests a 1920×1080 / 12 Mbps rendition before starting,
so 4K live channels, movies and series can use the provider's compatible HD stream. TVs keep the
provider's highest rendition. A fixed direct 4K URL still needs an HD alternative from the provider;
the app cannot convert that file locally.

## Version 0.10 notes

Video playback now enables Media3's lower-priority decoder fallback. If a 4K/UHD movie, live
channel or series episode fails to initialise, the player
automatically retries once with a 1920×1080 / 12 Mbps ceiling when the provider exposes an adaptive
HLS or DASH rendition. A fixed, direct 4K URL cannot be converted on the device; in that case the
player shows a clear compatibility error instead of retrying forever. CH+/CH− and D-pad up/down
continue to zap Live TV and radio in place, while OK opens the in-player channel list.

## Version 0.9 notes

The launcher now supplies raster icons and 16:9 branded banners at all five TV densities, plus an
adaptive icon. Both phone and Leanback launcher activities explicitly use the LibertyVue artwork.
The package ID and release certificate remain unchanged for in-place updates from 0.7/0.8.

Live TV and radio now support channel zapping without leaving playback. CH+/CH− or D-pad up/down
select the next/previous entry in the current category/search/favorites order, wrapping at the ends.
OK/left/menu opens an in-player browser with categories, channels, the playing preview and current/next
EPG (when supplied). OK on the current channel or Back closes the browser; Back again returns to the
original library or guide. Movies/episodes retain Media3's normal playback controls.

The browser uses lazy rows for large catalogs. History order is frozen on player entry so zapping
cannot reorder itself. TV, radio and unplayable entries remain separated. A channel switch replaces
the media source on one ExoPlayer, including its request headers. Opening the browser changes the
video's size without recreating it. Pausing/backgrounding the activity still releases playback.

Regression tests cover wraparound, empty/single queues, changed categories, favorites/sort order,
radio/video separation, duplicates and missing stream URLs. Actual TV launcher and remote behavior
still needs confirmation on a physical device; automated build/test/lint is not a device playback test.

References: [Android TV icons and banners](https://developer.android.com/design/ui/tv/guides/system/tv-app-icon-guidelines),
[Media3 playlists](https://developer.android.com/media/media3/exoplayer/playlists).

## Version 0.8 notes

The dashboard now uses the LibertyVue logo's gold and navy palette, with Live TV, Films and Series
above Radio, Live with EPG and Multi-screen. The same gold focus indicators and selection colors apply
to connections, browsing, the guide and playback controls.

Radio has its own searchable grid/list and audio player with station artwork, play/pause, buffering,
retry and audio focus handling. Stations come from the user's playlist; none are bundled. M3U honors
explicit `radio` metadata, radio categories/names and common audio file extensions. Xtream live entries
use supplied radio flags/types or radio categories/names while retaining their existing live endpoint.
These name/category rules are fallbacks; stations without identifying metadata may remain in Live TV.
TV, movies and series are not reclassified based on radio-looking host names or account credentials.
Old favorites and history for reclassified stations retain their identity. Radio playback stops on
screen exit or app background, like video playback; no background service or new permission is added.

This update uses the same release key as 0.7, so an in-place update retains saved connections.
Automated regression tests cover radio classification, mixed playlists and existing favorites/history.
Playback on physical devices and a real provider still needs verification.

References: [M3U radio metadata](https://github.com/kodi-pvr/pvr.iptvsimple#supported-m3u-and-xmltv-elements),
[Media3 playback lifecycle](https://developer.android.com/media/media3/exoplayer/hello-world).

## Version 0.7 notes

Browsing uses a compact dark grid with provider logos for live channels and portrait posters for films,
series and episodes. A list view, category search, provider/A–Z/Z–A ordering, favorites and recent items
are available in each section. The default keeps the provider's category order. Empty or invalid artwork
uses a visible fallback; no external catalogue or fabricated posters are substituted.

Coil 3.1 is pinned for compatibility with this project's Kotlin 2.1 / Compose baseline. Images are decoded
at display size, with a shared 32 MiB memory cache and Coil's disk cache. Catalogue filtering runs off the
UI thread. Favorites and the last 100 unique opened items are encrypted per saved connection. Browsing
scroll position and series filters are retained when returning from playback.

The CI workflow builds a non-debuggable, resource-shrunk release and runs unit tests and Android Lint.
Its APK is unsigned until `scripts/sign-release.py` applies the owner's stable release key. The private
keystore and password must stay outside Git and Actions artifacts. Retain the owner's private signing
backup (`LibertyVue-Private-Signing-Backup.zip`) and reuse it for every update; do not generate another certificate when making future builds.
The release certificate SHA-256 is `EA:6E:40:1A:96:1C:74:32:3F:99:16:F7:BD:F6:14:02:BF:3E:C2:D2:E8:95:64:A2:12:7A:EB:B6:7F:2D:DE:8A`.
The one-time move from versions 0.6 and earlier requires uninstalling those debug-signed builds, which
clears device-local connections. Save account details before that migration.

Signing does not establish Google Play Protect reputation or guarantee that its warning disappears.
The reported screenshot says Google has not seen this developer before. The release still needs
Google's scan/review and physical device testing. No Play Protect setting is changed by the app.

References: [Coil image loading](https://coil-kt.github.io/coil/compose/),
[Android signing and updates](https://developer.android.com/studio/publish/app-signing),
[Play Protect warning guidance](https://developers.google.com/android/play-protect/warning-dev-guidance).

## Version 0.6 notes

The dashboard reuses a loaded catalogue when returning to the same connection. Refresh explicitly reloads it.
EPG displays provider-supplied data only: a provider may return no programmes for a channel. XMLTV timestamps
use their supplied UTC offsets (UTC when absent); only the relevant channels and a two-day window are retained.
XMLTV responses are streamed and cached in memory for 15 minutes. External XML entities are not fetched.

Each populated multi-screen tile opens one live stream. Known Xtream `max_connections` limits are enforced;
for M3U accounts with no advertised limit, the user must check their provider's allowance. Hardware decoder
capacity and available bandwidth can still prevent 4-stream playback. Only the selected tile plays audio.
All video players are released when their screen leaves composition or the activity is paused.

Automated tests cover M3U parsing, 25,000 streamed entries, EPG channel IDs, XMLTV timezone conversion,
date/channel filtering and external-DTD suppression. The debug assembly runs these unit tests before
the existing workflow uploads the APK. Physical TV/phone playback still needs device/provider testing.

Implementation references: [Media3 lifecycle](https://developer.android.com/media/media3/exoplayer/hello-world),
[XMLTV format](https://github.com/XMLTV/xmltv/blob/master/xmltv.dtd),
[Xtream client API reference](https://github.com/tellytv/go.xtream-codes/blob/master/xtream-codes.go).

LibertyVue Player ships without channels, playlists or media. It is intended only for personal media, free-to-air streams, or content the user is authorised to access.

## Build and sign a release installer

The GitHub workflow in `.github/workflows/build-apk.yml` produces an unsigned release, test/lint reports
and official Android Build Tools for offline signing. Locally, use JDK 17, Android SDK 35 / Build Tools
35.0.0 and Gradle 8.11.1:

```bash
gradle :app:assembleRelease :app:testReleaseUnitTest :app:lintRelease
```

The unsigned APK is written to `app/build/outputs/apk/release/app-release-unsigned.apk`.
After extracting the CI artifact, run the signing helper with its extracted root, the existing private
keystore, its password file, and an output APK path. The helper aligns and verifies APK signatures.

## Production work still required

The beta trial is currently stored locally. Before selling licences, connect the app to a server-side device and licence service, add billing/webhook verification, publish a privacy-reviewed backend, complete distribution review and run tests on physical Android TV and Fire TV devices.

#!/usr/bin/env python3
"""Render the existing LibertyVue LV geometry as density-specific Android TV assets."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

RES = Path(__file__).resolve().parents[1] / 'app/src/main/res'
NAVY, GOLD = '#080d15', '#e8b64a'

def monogram(image, box):
    draw = ImageDraw.Draw(image)
    x, y, size = box
    draw.rounded_rectangle((x, y, x + size, y + size), radius=size * .22, fill=GOLD)
    polygons = [[(29,37),(41,37),(41,81),(62,81),(62,93),(29,93)],
                [(62,37),(75,37),(86,74),(97,37),(110,37),(92,93),(80,93)]]
    for polygon in polygons:
        draw.polygon([(x + px * size / 130, y + py * size / 130) for px, py in polygon], fill=NAVY)

icon = Image.new('RGB', (640,640), NAVY)
monogram(icon, (100,100,440))
banner = Image.new('RGB', (1280,720), NAVY)
monogram(banner, (110,210,300))
draw = ImageDraw.Draw(banner)
draw.text((470,270), 'LibertyVue', fill='#f6f7fa', font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',100))
draw.text((478,395), 'P L A Y E R', fill=GOLD, font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',45))
for density, size in [('mdpi',80),('hdpi',120),('xhdpi',160),('xxhdpi',240),('xxxhdpi',320)]:
    folder = RES / ('mipmap-' + density)
    folder.mkdir(exist_ok=True)
    icon.resize((size,size), Image.Resampling.LANCZOS).save(folder / 'ic_launcher.png', optimize=True)
    banner.resize((size * 2, size * 9 // 8), Image.Resampling.LANCZOS).save(folder / 'tv_banner.png', optimize=True)
    print(density, 'icon', size, 'banner', size*2, size*9//8)

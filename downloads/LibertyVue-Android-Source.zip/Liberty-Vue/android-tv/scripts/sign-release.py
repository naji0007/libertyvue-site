#!/usr/bin/env python3
"""Sign a verified CI release with the owner's existing private key. Never creates keys."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--build-dir", type=Path, required=True)
parser.add_argument("--keystore", type=Path, required=True)
parser.add_argument("--password-file", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--alias", default="libertyvue-release")
args = parser.parse_args()
build = args.build_dir.resolve()
unsigned = build / "outputs/apk/release/app-release-unsigned.apk"
tools = build / "outputs/signing-tools"
jar = tools / "apksigner.jar"
align = tools / "zipalign"
for path in (unsigned, jar, align, args.keystore, args.password_file):
    if not path.is_file():
        parser.error(f"Missing required input: {path}")
align.chmod(0o700)
env = dict(os.environ)
env["LD_LIBRARY_PATH"] = str(tools / "lib64") + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
args.output.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix="libertyvue-sign-", dir=args.output.parent) as scratch:
    aligned = Path(scratch) / "aligned.apk"
    subprocess.run([str(align), "-f", "-P", "16", "4", str(unsigned), str(aligned)], env=env, check=True)
    subprocess.run(["java", "-jar", str(jar), "sign", "--ks", str(args.keystore.resolve()),
                    "--ks-key-alias", args.alias, "--ks-pass", "file:" + str(args.password_file.resolve()),
                    "--v1-signing-enabled", "true",
                    "--v2-signing-enabled", "true", "--v3-signing-enabled", "true", "--v4-signing-enabled", "false",
                    "--out", str(args.output.resolve()), str(aligned)], check=True)
subprocess.run([str(align), "-c", "-P", "16", "4", str(args.output.resolve())], env=env, check=True)
subprocess.run(["java", "-jar", str(jar), "verify", "--verbose", "--print-certs", str(args.output.resolve())], check=True)

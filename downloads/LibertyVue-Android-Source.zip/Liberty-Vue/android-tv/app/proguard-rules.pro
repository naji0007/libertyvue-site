# LibertyVue currently relies on Android framework JSON and Media3 only.

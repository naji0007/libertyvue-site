package com.libertyvue.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ArtworkUrlTest {
    @Test
    fun keepsAbsoluteHttpUrls() {
        assertEquals(
            "http://img.example/logo.png",
            artworkUrl("http://img.example/logo.png"),
        )
    }

    @Test
    fun upgradesProtocolRelativeUrlsToHttps() {
        assertEquals(
            "https://img.example/logo.png",
            artworkUrl("//img.example/logo.png"),
        )
    }

    @Test
    fun encodesRawSpacesInLogoUrls() {
        assertEquals(
            "https://img.example/my%20logo.png",
            artworkUrl("https://img.example/my logo.png"),
        )
    }

    @Test
    fun resolvesRelativeUrlsAgainstPlaylistSource() {
        assertEquals(
            "https://provider.example/list/logos/a.png",
            artworkUrl("logos/a.png", "https://provider.example/list/index.m3u"),
        )
    }

    @Test
    fun rejectsBlankAndNonHttpUrls() {
        assertNull(artworkUrl(null))
        assertNull(artworkUrl("   "))
        assertNull(artworkUrl("null"))
        assertNull(artworkUrl("ftp://img.example/logo.png"))
        assertNull(artworkUrl("/no-host.png"))
    }
}

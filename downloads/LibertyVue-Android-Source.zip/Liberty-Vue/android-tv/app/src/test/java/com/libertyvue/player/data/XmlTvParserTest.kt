package com.libertyvue.player.data

import java.io.StringReader
import org.junit.Assert.*
import org.junit.Test

class XmlTvParserTest {
    @Test
    fun convertsExplicitTimezoneAndUtc() {
        assertEquals(XmlTvParser.parseTime("20260908090000 +0000"), XmlTvParser.parseTime("20260908100000 +0100"))
        assertEquals(XmlTvParser.parseTime("20260908090000 +0000"), XmlTvParser.parseTime("20260908090000"))
        assertNull(XmlTvParser.parseTime("invalid"))
    }

    @Test
    fun filtersChannelsAndDatesAndPreservesTitles() {
        val now = XmlTvParser.parseTime("20260908093000 +0000")!!
        val xml = """
            <tv>
              <programme start="20260908090000 +0000" stop="20260908100000 +0000" channel="news.fr">
                <title>Actualités &amp; météo</title><desc>Le journal.</desc>
              </programme>
              <programme start="20260908100000 +0000" stop="20260908110000 +0000" channel="news.fr"><title>Ensuite</title></programme>
              <programme start="20260908100000 +0000" stop="20260908110000 +0000" channel="other"><title>Other</title></programme>
              <programme start="20260801100000 +0000" stop="20260801110000 +0000" channel="news.fr"><title>Old</title></programme>
            </tv>
        """.trimIndent()
        val result = XmlTvParser().parse(StringReader(xml), setOf("news.fr"), now)
        assertEquals(setOf("news.fr"), result.keys)
        assertEquals(2, result["news.fr"]!!.size)
        val first = result["news.fr"]!!.first()
        assertEquals("Actualités & météo", first.title)
        assertEquals("Le journal.", first.description)
        assertTrue(first.isOnAir(now))
        assertFalse(first.isOnAir(first.endMillis))
    }

    @Test(timeout = 2000)
    fun doesNotFetchExternalDtd() {
        val xml = """<!DOCTYPE tv SYSTEM "https://invalid.example/no-download.dtd"><tv/>"""
        assertTrue(XmlTvParser().parse(StringReader(xml), setOf("one"), System.currentTimeMillis()).isEmpty())
    }
}

package com.libertyvue.player.data

import org.junit.Assert.*
import org.junit.Test

class BrowseCatalogTest {
    private val live = StreamItem("live-1", "Relax Time HD", "https://example.test/live/1", categoryName = "RELAX TIME")
    private val other = StreamItem("live-2", "News HD", "https://example.test/live/2", categoryName = "NEWS")
    private val movie = StreamItem("film-1", "A Film", "https://example.test/movie/1.mp4", contentType = ContentType.MOVIE)

    @Test fun providerOrderAndCountsArePreserved() {
        val catalog = BrowseCatalog(listOf(live, other, live.copy(id = "live-3", streamUrl = "https://example.test/live/3")))
        assertEquals(listOf("RELAX TIME", "NEWS"), catalog.categories.keys.toList())
        assertEquals(2, catalog.categories["RELAX TIME"])
        assertEquals(3, catalog.select(null, "", BrowseScope.ALL, BrowseSort.PROVIDER, emptySet(), emptyList()).size)
    }

    @Test fun favoritesAndRecentsNeverLeakFromAnotherSection() {
        val catalog = BrowseCatalog(listOf(live, other))
        val favorites = setOf(live.browseKey, movie.browseKey)
        assertEquals(listOf(live), catalog.select(null, "", BrowseScope.FAVORITES, BrowseSort.PROVIDER, favorites, emptyList()))
        assertEquals(listOf(other, live), catalog.select(null, "", BrowseScope.HISTORY, BrowseSort.PROVIDER,
            favorites, listOf(movie.browseKey, other.browseKey, live.browseKey)))
    }

    @Test fun categorySearchAndNameSortKeepTheMatchingStreams() {
        val catalog = BrowseCatalog(listOf(live, other))
        assertEquals(listOf(live), catalog.select("RELAX TIME", "time hd", BrowseScope.ALL, BrowseSort.NAME_ASC, emptySet(), emptyList()))
        assertEquals(listOf(other, live), catalog.select(null, "", BrowseScope.ALL, BrowseSort.NAME_ASC, emptySet(), emptyList()))
        assertEquals(emptyList<StreamItem>(), catalog.select("NEWS", "relax", BrowseScope.ALL, BrowseSort.PROVIDER, emptySet(), emptyList()))
    }

    @Test fun recentsAreDistinctAndBounded() {
        var memory = BrowseMemory()
        repeat(110) { memory = memory.visited("item-$it") }
        memory = memory.visited("item-50")
        assertEquals(100, memory.history.size)
        assertEquals("item-50", memory.history.first())
        assertEquals(1, memory.history.count { it == "item-50" })
        assertFalse(memory.history.contains("item-0"))
    }

    @Test fun relativeArtworkIsResolvedAndNonNetworkSchemesAreIgnored() {
        assertEquals("https://example.test/logos/one.png?a=1&b=2", artworkUrl("/logos/one.png?a=1&amp;b=2", "https://example.test/get.php"))
        assertEquals("https://cdn.example.test/cover.jpg", artworkUrl("//cdn.example.test/cover.jpg", "https://example.test/"))
        assertNull(artworkUrl("null"))
        assertNull(artworkUrl("file:///private/secret.jpg"))
        assertNull(artworkUrl("javascript:alert(1)"))
    }
}

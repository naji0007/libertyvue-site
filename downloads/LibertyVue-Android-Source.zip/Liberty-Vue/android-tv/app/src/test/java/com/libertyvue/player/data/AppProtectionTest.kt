package com.libertyvue.player.data

import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class AppProtectionTest {
    @Test
    fun protectionMessagesTranslate() {
        val previous = Locale.getDefault()
        val saved = AppLanguage.override
        try {
            for (language in listOf("fr", "en", "ar")) {
                AppLanguage.override = language
                assertTrue(AppProtection.tamperMessage().isNotBlank())
                assertTrue(AppProtection.rootWarning().isNotBlank())
            }
        } finally {
            AppLanguage.override = saved
            Locale.setDefault(previous)
        }
    }
}

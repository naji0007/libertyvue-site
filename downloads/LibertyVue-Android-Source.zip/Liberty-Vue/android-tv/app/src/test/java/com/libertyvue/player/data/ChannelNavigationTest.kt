package com.libertyvue.player.data

import org.junit.Assert.*
import org.junit.Test

class ChannelNavigationTest {
    private val one = StreamItem("1", "News", "https://example.test/1", categoryName = "FR")
    private val two = StreamItem("2", "Sport", "https://example.test/2", categoryName = "FR")
    private val three = StreamItem("3", "Culture", "https://example.test/3", categoryName = "AR")

    @Test fun zappingWrapsInBothDirections() {
        val queue = listOf(one, two, three)
        assertEquals(two, adjacentChannel(queue, one.browseKey, 1))
        assertEquals(three, adjacentChannel(queue, one.browseKey, -1))
        assertEquals(one, adjacentChannel(queue, three.browseKey, 1))
    }

    @Test fun emptySingleAndChangedCategoryAreHandled() {
        assertNull(adjacentChannel(emptyList(), one.browseKey, 1))
        assertEquals(one, adjacentChannel(listOf(one), one.browseKey, -1))
        assertEquals(two, adjacentChannel(listOf(two, three), one.browseKey, 1))
        assertEquals(three, adjacentChannel(listOf(two, three), one.browseKey, -1))
    }

    @Test fun radioMoviesDuplicatesAndUnplayableEntriesDoNotLeakIntoTvQueue() {
        val radio = two.copy(contentType = ContentType.RADIO)
        val movie = three.copy(contentType = ContentType.MOVIE)
        val input = listOf(one, radio, movie, two.copy(streamUrl = ""), three.copy(streamUrl = null), one)
        assertEquals(listOf(one), channelItems(input, ContentType.LIVE))
        assertEquals(listOf(radio), channelItems(input, ContentType.RADIO))
        assertTrue(channelItems(input, ContentType.MOVIE).isEmpty())
    }

    @Test fun queueUsesCategoryFavoritesAndDisplaySort() {
        val catalog = BrowseCatalog(channelItems(listOf(one, two, three), ContentType.LIVE))
        val queue = catalog.select("FR", "", BrowseScope.FAVORITES, BrowseSort.NAME_DESC,
            setOf(one.browseKey, two.browseKey, three.browseKey), emptyList())
        assertEquals(listOf(two, one), queue)
        assertEquals(one, adjacentChannel(queue, two.browseKey, 1))
        assertEquals(two, adjacentChannel(queue, one.browseKey, 1))
    }
}

package com.libertyvue.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {
    @Test
    fun parsesMetadataAndRelativeUrls() {
        val document = """
            #EXTM3U
            #EXTINF:-1 tvg-id="demo" tvg-logo="https://img.example/logo.png" group-title="News",Demo News
            streams/news.m3u8
            #EXTINF:-1 group-title="Movies",Demo Film
            https://media.example/film.mp4
        """.trimIndent()

        val items = M3uParser().parse(document, "https://provider.example/list/index.m3u")

        assertEquals(2, items.size)
        assertEquals("demo", items[0].epgChannelId)
        assertEquals("https://provider.example/list/streams/news.m3u8", items[0].streamUrl)
        assertEquals(ContentType.LIVE, items[0].contentType)
        assertEquals(ContentType.MOVIE, items[1].contentType)
    }

    @Test
    fun ignoresCommentsBetweenMetadataAndUrl() {
        val document = """
            #EXTM3U
            #EXTINF:-1 group-title="Live",Channel
            #EXTVLCOPT:http-user-agent=Example
            https://media.example/live.ts
        """.trimIndent()

        val items = M3uParser().parse(document)

        assertEquals(1, items.size)
        assertTrue(items.first().id.isNotBlank())
    }

    @Test
    fun acceptsSingleQuotedAttributesAndPlainStreamUrls() {
        val document = """
            #EXTM3U
            #EXTINF:-1 group-title='SERIES | EN',Episode One
            https://media.example/episode.mkv
            https://media.example/live/channel.ts
        """.trimIndent()

        val items = M3uParser().parse(document)

        assertEquals(2, items.size)
        assertEquals("SERIES | EN", items[0].categoryName)
        assertEquals(ContentType.EPISODE, items[0].contentType)
        assertEquals(ContentType.LIVE, items[1].contentType)
    }

    @Test
    fun dropsDuplicateEntriesByBrowseKey() {
        val document = """
            #EXTM3U
            #EXTINF:-1 tvg-id="dup" tvg-logo="https://img.example/logo.png" group-title="News",Demo News
            https://media.example/live/dup.ts
            #EXTINF:-1 tvg-id="dup" tvg-logo="https://img.example/logo.png" group-title="Other",Demo News
            https://media.example/live/dup.ts
            #EXTINF:-1 group-title="News",Other Channel
            https://media.example/live/other.ts
        """.trimIndent()

        val items = M3uParser().parse(document)

        assertEquals(2, items.size)
        assertEquals(2, items.map { it.browseKey }.toSet().size)
    }

    @Test
    fun treatsAnHlsManifestAsOnePlayableStream() {
        val document = """
            #EXTM3U
            #EXT-X-TARGETDURATION:10
            #EXT-X-MEDIA-SEQUENCE:1
            segment-1.ts
        """.trimIndent()

        val items = M3uParser().parse(document, "https://media.example/live/main.m3u8")

        assertEquals(1, items.size)
        assertEquals("https://media.example/live/main.m3u8", items.first().streamUrl)
    }

    @Test
    fun parsesAPlaylistFromStreamingLines() {
        val channelCount = 25_000
        val lines = sequence {
            yield("#EXTM3U")
            repeat(channelCount) { index ->
                yield("#EXTINF:-1 group-title=\"Live\",Channel $index")
                yield("https://media.example/live/$index.ts")
            }
        }

        val items = M3uParser().parse(lines, "https://provider.example/playlist.m3u")

        assertEquals(channelCount, items.size)
        assertEquals("Channel 0", items.first().name)
        assertEquals("Channel ${channelCount - 1}", items.last().name)
    }
}

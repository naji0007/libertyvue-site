package com.libertyvue.player.data

import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class AppErrorTest {
    private val samples: List<AppError> = listOf(
        AppError.HttpStatus(500),
        AppError.ResponseTooLarge,
        AppError.PlaylistTooLarge,
        AppError.BadUrl(AppError.UrlLabel.M3U),
        AppError.BadUrl(AppError.UrlLabel.SERVER),
        AppError.BadUrl(AppError.UrlLabel.XMLTV),
        AppError.UsernameRequired,
        AppError.PasswordRequired,
        AppError.WrongContent(AppError.WrongContentKind.WEB_PAGE),
        AppError.WrongContent(AppError.WrongContentKind.JSON),
        AppError.WrongContent(AppError.WrongContentKind.EMPTY),
        AppError.SeriesRequiresXtream,
        AppError.NoEpisodes,
        AppError.NoPlayableUrl,
        AppError.PortalNoAccount,
        AppError.PortalBadCredentials,
        AppError.PortalStatus("Active"),
        AppError.PortalBadList,
        AppError.GuideLoad,
        AppError.EpgNoTvgId,
        AppError.EpgNoSource,
        AppError.EpgNoStreamId,
        AppError.PersistFailed,
        AppError.CorruptedStorage,
        AppError.LoadPlaylist,
        AppError.LoadTimeout,
        AppError.NoConnection,
        AppError.EmptySection("Films"),
        AppError.LoadEpisodes,
        AppError.SyncWebsite,
        AppError.DeviceForbidden,
        AppError.RemovePlaylist,
        AppError.TrialEnded,
    )

    @Test
    fun everyErrorTranslatesToFrenchEnglishAndArabic() {
        val previous = Locale.getDefault()
        try {
            for (language in listOf("fr", "en", "ar")) {
                Locale.setDefault(Locale(language))
                for (error in samples) {
                    assertTrue("$language:${error::class.simpleName}", error.localized().isNotBlank())
                }
                assertTrue(infoConnectionSaved().isNotBlank())
                assertTrue(infoNoWebsiteYet().isNotBlank())
            }
        } finally {
            Locale.setDefault(previous)
        }
    }

    @Test
    fun languageOverrideBeatsDeviceLocale() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale("fr"))
            AppLanguage.override = "ar"
            assertTrue(AppError.NoPlayableUrl.localized().contains("رابط"))
            AppLanguage.override = "en"
            assertTrue(AppError.NoPlayableUrl.localized().contains("playable stream URL"))
            AppLanguage.override = "system"
            assertTrue(AppError.NoPlayableUrl.localized().contains("URL lisible"))
        } finally {
            AppLanguage.override = null
            Locale.setDefault(previous)
        }
    }

    @Test
    fun spotChecksEachLanguage() {
        val previous = Locale.getDefault()
        try {
            Locale.setDefault(Locale("fr"))
            assertTrue(AppError.NoPlayableUrl.localized().contains("URL lisible"))
            Locale.setDefault(Locale("en"))
            assertTrue(AppError.NoPlayableUrl.localized().contains("playable stream URL"))
            Locale.setDefault(Locale("ar"))
            assertTrue(AppError.NoPlayableUrl.localized().contains("رابط"))
        } finally {
            Locale.setDefault(previous)
        }
    }
}

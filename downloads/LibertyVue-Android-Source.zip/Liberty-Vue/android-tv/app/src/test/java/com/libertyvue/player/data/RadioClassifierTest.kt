package com.libertyvue.player.data

import org.junit.Assert.*
import org.junit.Test

class RadioClassifierTest {
    @Test fun recognizesProviderRadioMetadataAndLocalizedGroups() {
        assertTrue(RadioClassifier.isRadio("Live TV", "Station", declaredType = "radio"))
        assertTrue(RadioClassifier.isRadio("News", "Station", radioFlag = "1"))
        assertTrue(RadioClassifier.isRadio("FR | RADIOS", "Station"))
        assertTrue(RadioClassifier.isRadio("إذاعات المغرب", "Station"))
        assertTrue(RadioClassifier.isRadio("Music", "Radio Example"))
        assertTrue(RadioClassifier.isRadio("", "", "https://example.test/music.aac?token=demo"))
    }

    @Test fun keepsVideoChannelsWhenMetadataSaysSoAndIgnoresIncidentalWords() {
        assertFalse(RadioClassifier.isRadio("Radio", "Radio TV", radioFlag = "false"))
        assertFalse(RadioClassifier.isRadio("Cinema", "Radioactive"))
        assertFalse(RadioClassifier.isRadio("News", "News HD", "https://radio.example.test/live.ts?username=radio"))
        assertFalse(RadioClassifier.isRadio("Music TV", "Concerts"))
    }

    @Test fun importsRadioAndVideoIntoDistinctSectionsWithoutDroppingEntries() {
        val entries = M3uParser().parse("""
            #EXTM3U
            #EXTINF:-1 radio="TRUE" group-title="News",One
            https://example.test/live/1.ts
            #EXTINF:-1 group-title="MA | RADIO",Film music
            https://example.test/live/2.ts
            #EXTINF:-1 group-title="Music",Three
            audio/three.mp3
            #EXTINF:-1 radio="false" group-title="Radio TV",Four
            https://example.test/live/4.ts
            #EXTINF:-1 group-title="Movies",Radio Days
            https://example.test/movie/5.mp4
            #EXTINF:-1 group-title="Series",Radio Show S01 E01
            https://example.test/series/6.mp4
        """.trimIndent(), "https://example.test/playlist.m3u")
        assertEquals(listOf(ContentType.RADIO, ContentType.RADIO, ContentType.RADIO,
            ContentType.LIVE, ContentType.MOVIE, ContentType.EPISODE), entries.map { it.contentType })
        assertEquals("https://example.test/audio/three.mp3", entries[2].streamUrl)
        assertEquals(3, BrowseCatalog(entries.filter { it.contentType == ContentType.RADIO }).items.size)
    }

    @Test fun importsPlainRelativeAudioUrls() {
        val items = M3uParser().parse("#EXTM3U\nstation.opus\nstation.aac", "https://example.test/list.m3u")
        assertEquals(2, items.size)
        assertTrue(items.all { it.contentType == ContentType.RADIO })
    }

    @Test fun preservesPreviouslySavedRadioFavoritesAndHistory() {
        val previous = StreamItem("live-10", "Station", "https://example.test/live/10.ts")
        val radio = previous.copy(contentType = ContentType.RADIO)
        val catalog = BrowseCatalog(listOf(radio))
        assertEquals(listOf(radio), catalog.select(null, "", BrowseScope.FAVORITES,
            BrowseSort.PROVIDER, setOf(previous.browseKey), emptyList()))
        assertEquals(listOf(radio), catalog.select(null, "", BrowseScope.HISTORY,
            BrowseSort.PROVIDER, emptySet(), listOf(previous.browseKey)))
    }
}

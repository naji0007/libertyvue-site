package com.libertyvue.player.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.libertyvue.player.AppScreen
import com.libertyvue.player.AppUiState
import com.libertyvue.player.MainViewModel
import com.libertyvue.player.data.PlaylistConfig
import com.libertyvue.player.data.PlaylistType
import com.libertyvue.player.data.pickLanguage

private const val MANAGE_URL = "https://libertyvue-player.naji-abdellah1.chatgpt.site/manage"

@Composable
fun LibertyVueApp(viewModel: MainViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val browseStateHolder = rememberSaveableStateHolder()
    BackHandler(enabled = state.screen != AppScreen.HOME) {
        when (state.screen) {
            AppScreen.PLAYER -> viewModel.closePlayer()
            AppScreen.EPISODES -> viewModel.backFromEpisodes()
            AppScreen.LIBRARY, AppScreen.GUIDE, AppScreen.MULTI_SCREEN -> viewModel.showSections()
            AppScreen.ADD_PLAYLIST -> viewModel.showAddPlaylist()
            else -> viewModel.showHome()
        }
    }
    Surface(Modifier.fillMaxSize(), color = LibertyNavy, contentColor = LibertyText) {
        val blocked = state.blockedMessage
        if (blocked != null) {
            // Repackaged clone: refuse to run, in the selected language.
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("LV", color = LibertyGold, fontWeight = FontWeight.Black, fontSize = 44.sp)
                    Text(blocked, fontSize = 16.sp)
                }
            }
        } else {
        Box(Modifier.fillMaxSize().displayCutoutPadding()) {
            when (state.screen) {
                AppScreen.HOME -> TvHomeScreen(state, viewModel::showAddPlaylist, { viewModel.syncDevice() },
                    viewModel::openPlaylist, viewModel::showSettings) {
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(MANAGE_URL))) }
                }
                AppScreen.PLAYLIST_TYPE -> PlaylistTypeScreen(viewModel::showHome, viewModel::choosePlaylistType)
                AppScreen.ADD_PLAYLIST -> AddPlaylistScreen(state.newPlaylistType, viewModel::showAddPlaylist,
                    viewModel::addM3u, viewModel::addXtream)
                AppScreen.SECTIONS -> TvDashboardScreen(state, viewModel::showHome, viewModel::refresh,
                    viewModel::openSection, viewModel::showGuide, viewModel::showMultiScreen, viewModel::showSettings)
                AppScreen.LIBRARY, AppScreen.EPISODES -> browseStateHolder.SaveableStateProvider(
                    "browse:${state.activePlaylist?.id}:${state.filter}:${state.screen}:${state.sectionTitle}") {
                    BrowseScreen(state,
                        if (state.screen == AppScreen.EPISODES) viewModel::backFromEpisodes else viewModel::showSections,
                        viewModel::refresh, viewModel::setCategory, viewModel::setSearch, viewModel::openItem,
                        viewModel::setBrowseScope, viewModel::setBrowseSort, viewModel::toggleBrowseLayout, viewModel::toggleFavorite)
                }
                AppScreen.GUIDE -> GuideScreen(state, viewModel::showSections, viewModel::selectGuideChannel,
                    viewModel::openItem, viewModel::refreshGuide, viewModel::saveEpgSource)
                AppScreen.MULTI_SCREEN -> MultiScreen(state, viewModel::showSections, viewModel::setMultiSize,
                    viewModel::setMultiChannel, viewModel::setAudioSlot)
                AppScreen.SETTINGS -> SettingsScreen(state, viewModel::showHome, viewModel::removePlaylist, viewModel::showAddPlaylist,
                    viewModel::setLanguage)
                AppScreen.PLAYER -> state.playingItem?.let {
                    PlayerScreen(state, viewModel::switchChannel, viewModel::selectGuideChannel,
                        viewModel::toggleFavorite, viewModel::closePlayer)
                }
            }
            state.error?.let { message ->
                Surface(Modifier.align(Alignment.TopCenter).padding(12.dp).widthIn(max = 720.dp).fillMaxWidth(),
                    color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(message, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 14.sp)
                        TextButton(onClick = viewModel::clearError) { Text(pickLanguage("Fermer", "Close", "إغلاق")) }
                    }
                }
            }
            state.crashReport?.let { report ->
                CrashReportDialog(report, viewModel::clearCrashReport)
            }
            if (state.error == null) state.rootWarning?.let { warning ->
                Surface(Modifier.align(Alignment.TopCenter).padding(12.dp).widthIn(max = 720.dp).fillMaxWidth(),
                    color = LibertySelected, shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, LibertyGold)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(warning, Modifier.weight(1f), color = LibertyGoldSoft, fontSize = 14.sp)
                        TextButton(onClick = viewModel::dismissRootWarning) { Text(pickLanguage("Fermer", "Close", "إغلاق")) }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun AddPlaylistScreen(type: PlaylistType, onBack: () -> Unit,
    onAddM3u: (String, String, String) -> Unit, onAddXtream: (String, String, String, String) -> Unit) {
    var name by rememberSaveable(type) { mutableStateOf("") }
    var url by rememberSaveable(type) { mutableStateOf("") }
    var username by rememberSaveable(type) { mutableStateOf("") }
    var password by rememberSaveable(type) { mutableStateOf("") }
    var epgUrl by rememberSaveable(type) { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(22.dp)) {
        TvTopBar(if (type == PlaylistType.M3U) pickLanguage("Ajouter une liste M3U", "Add an M3U list", "إضافة قائمة M3U") else pickLanguage("Ajouter un compte Xtream", "Add an Xtream account", "إضافة حساب Xtream"), onBack)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Column(Modifier.weight(1f)) {
                Icon(if (type == PlaylistType.M3U) Icons.Default.PlaylistPlay else Icons.Default.Dns,
                    null, Modifier.size(54.dp), tint = LibertyGold)
                Spacer(Modifier.height(12.dp))
                Text(if (type == PlaylistType.M3U) "M3U / M3U8" else "XTREAM CODES", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(pickLanguage("Utilisez les informations de votre fournisseur.", "Use your provider details.", "استعمل معلومات مزود الخدمة."), color = LibertyMuted, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Text(pickLanguage("La connexion reste enregistrée sur cet appareil.", "The connection stays saved on this device.", "يبقى الاتصال محفوظاً على هذا الجهاز."), color = LibertyGold, fontSize = 14.sp)
            }
            Column(Modifier.weight(2f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(pickLanguage("Nom de la connexion", "Connection name", "اسم الاتصال")) }, singleLine = true)
                OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(),
                    label = { Text(if (type == PlaylistType.M3U) "URL M3U / M3U8" else pickLanguage("URL du serveur", "Server URL", "رابط السيرفر")) },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                if (type == PlaylistType.XTREAM) {
                    OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), label = { Text(pickLanguage("Identifiant", "Username", "المعرف")) }, singleLine = true)
                    OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text(pickLanguage("Mot de passe", "Password", "كلمة المرور")) },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                } else {
                    OutlinedTextField(epgUrl, { epgUrl = it }, Modifier.fillMaxWidth(), label = { Text(pickLanguage("URL EPG / XMLTV (facultatif)", "EPG / XMLTV URL (optional)", "رابط EPG / XMLTV (اختياري)")) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                }
                Button(onClick = { if (type == PlaylistType.M3U) onAddM3u(name, url, epgUrl) else onAddXtream(name, url, username, password) }) {
                    Icon(Icons.Default.Save, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(pickLanguage("Enregistrer", "Save", "حفظ"))
                }
                Text(pickLanguage("Ajoutez uniquement des contenus que vous êtes autorisé à regarder.", "Only add content you are allowed to watch.", "أضف فقط المحتوى المسموح لك بمشاهدته."), color = LibertyMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: AppUiState, onBack: () -> Unit, onRemove: (PlaylistConfig) -> Unit, onAdd: () -> Unit,
    onLanguage: (String) -> Unit) {
    var removing by remember { mutableStateOf<PlaylistConfig?>(null) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TvTopBar(pickLanguage("Réglages", "Settings", "الإعدادات"), onBack) { Button(onClick = onAdd) { Text(pickLanguage("Ajouter", "Add", "إضافة")) } }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Surface(color = LibertyPanel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Langue / Language / اللغة", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LanguageChip("Système", com.libertyvue.player.data.SettingsStore.LANGUAGE_SYSTEM,
                                state.language, onLanguage, Modifier.weight(1f))
                            LanguageChip("Français", com.libertyvue.player.data.SettingsStore.LANGUAGE_FRENCH,
                                state.language, onLanguage, Modifier.weight(1f))
                            LanguageChip("English", com.libertyvue.player.data.SettingsStore.LANGUAGE_ENGLISH,
                                state.language, onLanguage, Modifier.weight(1f))
                            LanguageChip("العربية", com.libertyvue.player.data.SettingsStore.LANGUAGE_ARABIC,
                                state.language, onLanguage, Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                Surface(color = LibertyPanel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("LibertyVue Player · ${com.libertyvue.player.BuildConfig.VERSION_NAME}", fontWeight = FontWeight.Bold)
                        Text("ID : ${state.trial.deviceId}   ·   ${pickLanguage("Clé :", "Key:", "المفتاح:")} ${state.trial.deviceKey}", color = LibertyGold)
                        Text(
                            when {
                                state.trial.isLicensed && state.trial.licenseType == "lifetime" -> pickLanguage("Licence Lifetime active", "Lifetime license active", "ترخيص مدى الحياة مفعّل")
                                state.trial.isLicensed -> "${pickLanguage("Licence annuelle", "Annual license", "ترخيص سنوي")}${licenseExpiryDate(state.trial.licenseExpiresAt)?.let { " · ${pickLanguage("jusqu’au", "until", "حتى")} $it" }.orEmpty()} : ${state.trial.licenseDaysRemaining ?: 0} ${pickLanguage("jours restants", "days left", "يوم متبق")}"
                                state.trial.isActive -> "${pickLanguage("Essai gratuit", "Free trial", "تجربة مجانية")} : ${state.trial.daysRemaining} ${pickLanguage("jours restants", "days left", "يوم متبق")}"
                                else -> pickLanguage("Essai terminé · Activez cet appareil sur le site", "Trial ended · Activate this device on the website", "انتهت التجربة · فعّل هذا الجهاز على الموقع")
                            },
                            color = if (state.trial.isLicensed) LibertyGold else LibertyMuted,
                            fontSize = 14.sp,
                        )
                    }
                }
            }
            items(state.playlists, key = { it.id }) { playlist ->
                Surface(color = LibertyPanel, shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, fontWeight = FontWeight.Bold)
                            Text(if (playlist.type == PlaylistType.M3U) "M3U / M3U8" else "Xtream Codes", color = LibertyMuted, fontSize = 13.sp)
                        }
                        OutlinedButton(onClick = { removing = playlist }) { Icon(Icons.Default.DeleteOutline, null); Text(pickLanguage("Supprimer", "Delete", "حذف")) }
                    }
                }
            }
        }
    }
    removing?.let { playlist ->
        AlertDialog(onDismissRequest = { removing = null }, title = { Text(pickLanguage("Supprimer cette connexion ?", "Delete this connection?", "حذف هذا الاتصال؟")) },
            text = { Text(pickLanguage("« ${playlist.name} » sera supprimée de cet appareil.", "“${playlist.name}” will be removed from this device.", "سيتم حذف «${playlist.name}» من هذا الجهاز.")) },
            confirmButton = { TextButton(onClick = { onRemove(playlist); removing = null }) { Text(pickLanguage("Supprimer", "Delete", "حذف")) } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text(pickLanguage("Annuler", "Cancel", "إلغاء")) } })
    }
}

@Composable
private fun CrashReportDialog(report: String, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(pickLanguage("L’application a planté", "The app crashed", "التطبيق تعطّل")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    pickLanguage(
                        "Voici le rapport. Copiez-le et envoyez-le pour corriger le problème.",
                        "Here is the report. Copy it and send it so the problem can be fixed.",
                        "هذا هو التقرير. انسخه وأرسله لإصلاح المشكلة.",
                    ),
                    color = LibertyMuted, fontSize = 13.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text(report.take(1200), fontSize = 11.sp, color = LibertyText)
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(report)); onDismiss() }) {
                Text(pickLanguage("Copier", "Copy", "نسخ"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(pickLanguage("Fermer", "Close", "إغلاق")) } })
}

@Composable
private fun LanguageChip(label: String, code: String, current: String, onChoose: (String) -> Unit,
    modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val selected = current == code
    Surface(onClick = { onChoose(code) }, interactionSource = interaction, modifier = modifier,
        color = if (selected) LibertyGold else LibertyPanelSoft,
        contentColor = if (selected) LibertyGoldInk else LibertyText,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (focused) LibertyGoldSoft else LibertyBorder)) {
        Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp)
        }
    }
}

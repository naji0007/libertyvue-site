package com.libertyvue.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.pickLanguage

@Composable
internal fun RadioPlayerFace(item: StreamItem, player: Player, buffering: Boolean) {
    var playing by remember(player) { mutableStateOf(player.isPlaying) }
    var playRequested by remember(player) { mutableStateOf(player.playWhenReady) }
    val focus = remember { FocusRequester() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { playRequested = playWhenReady }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) { focus.requestFocus() }
    BoxWithConstraints(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(LibertyPanelSoft, LibertyNavy)))
        .padding(start = 28.dp, end = 28.dp, top = 58.dp, bottom = 18.dp), contentAlignment = Alignment.Center) {
        val artworkSize = (maxHeight - 20.dp).coerceIn(64.dp, 180.dp)
        val compact = maxHeight < 210.dp
        Row(Modifier.widthIn(max = 760.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Surface(shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, LibertyGold.copy(alpha = .4f))) {
                MediaArtwork(item, Modifier.size(artworkSize))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(if (compact) 6.dp else 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Radio, null, Modifier.size(20.dp), tint = LibertyGold)
                    Text("RADIO", color = LibertyGold, fontSize = 14.sp, letterSpacing = 2.sp)
                }
                Text(item.name, color = LibertyText, fontSize = if (compact) 20.sp else 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold,
                    maxLines = if (compact) 1 else 2, overflow = TextOverflow.Ellipsis)
                if (!compact) Text(item.categoryName, color = LibertyMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (buffering) CircularProgressIndicator(Modifier.size(16.dp), color = LibertyGold, strokeWidth = 2.dp)
                    Text(if (buffering) pickLanguage("Connexion…", "Connecting…", "جارٍ الاتصال…") else if (playing) pickLanguage("En écoute", "Playing", "يشتغل الآن") else pickLanguage("En pause", "Paused", "متوقف"),
                        color = LibertyGoldSoft, fontSize = 14.sp)
                }
                Button(onClick = { if (player.playWhenReady) player.pause() else player.play() },
                    modifier = Modifier.focusRequester(focus).heightIn(min = 48.dp)) {
                    Icon(if (playRequested) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (playRequested) pickLanguage("Pause", "Pause", "إيقاف") else pickLanguage("Écouter", "Listen", "استمع"))
                }
            }
        }
    }
}

package com.libertyvue.player.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.Reader
import java.net.URLEncoder

class XtreamClient(
    private val http: HttpTextClient = HttpTextClient(),
) {
    enum class XtreamSection { MOVIES, SERIES }

    private class AccountInfo(
        val baseUrl: String,
        val status: String?,
        val maxConnections: Int?,
        val accountExpiresAt: Long?,
    )

    private suspend fun loadAccount(config: PlaylistConfig): AccountInfo {
        require(config.type == PlaylistType.XTREAM)
        val baseUrl = normalizeServer(config.url)
        val account = JSONObject(http.get(apiUrl(baseUrl, config)))
        validateAccount(account)
        val userInfo = account.optJSONObject("user_info")
        // Xtream reports the subscription end as a Unix timestamp in seconds.
        return AccountInfo(
            baseUrl = baseUrl,
            status = userInfo?.optString("status")?.takeIf(String::isNotBlank),
            maxConnections = userInfo?.optString("max_connections")
                ?.toIntOrNull()?.takeIf { it > 0 },
            accountExpiresAt = userInfo?.optString("exp_date")
                ?.takeIf { it.isNotBlank() && it != "null" }
                ?.toLongOrNull()?.takeIf { it > 0L }
                ?.let { if (it < 100_000_000_000L) it * 1_000L else it },
        )
    }

    private fun LibraryPayloadMeta(info: AccountInfo, items: List<StreamItem>) = LibraryPayload(
        items = items,
        accountMessage = info.status?.let { "Portal status: $it" },
        maxConnections = info.maxConnections,
        accountExpiresAt = info.accountExpiresAt,
    )

    /** Entry load: account + live channels only, reported chunk by chunk. */
    suspend fun loadLive(config: PlaylistConfig, onPartial: ((LibraryPayload) -> Unit)? = null): LibraryPayload {
        val info = loadAccount(config)
        fun partial(items: List<StreamItem>) {
            onPartial?.invoke(LibraryPayloadMeta(info, items))
        }
        // Huge providers send the same entry twice: drop duplicates by key,
        // otherwise lazy lists crash on non-unique keys.
        val seen = mutableSetOf<String>()
        val all = mutableListOf<StreamItem>()
        fun appendUnique(chunk: List<StreamItem>) {
            chunk.forEach { item ->
                if (seen.add(item.browseKey)) all += item
            }
        }
        var lastEmitSize = 0
        var lastEmitTime = 0L
        fun considerEmit(force: Boolean) {
            val now = System.currentTimeMillis()
            if (force || (all.size - lastEmitSize >= 20_000 && now - lastEmitTime >= 2_000L)) {
                lastEmitSize = all.size
                lastEmitTime = now
                partial(all.toList())
            }
        }
        val liveCategories = categories(info.baseUrl, config, "get_live_categories")
        all += streams(
            baseUrl = info.baseUrl,
            config = config,
            action = "get_live_streams",
            categories = liveCategories,
            type = ContentType.LIVE,
            onChunk = { chunk -> appendUnique(chunk); considerEmit(false) },
        )
        considerEmit(true)
        return LibraryPayloadMeta(info, all.toList())
    }

    /** On-demand section load (movies or series). Sequential: some portals
        hang when the same account opens several API calls at once. */
    suspend fun loadSection(
        config: PlaylistConfig,
        section: XtreamSection,
        onProgress: ((Int) -> Unit)? = null,
    ): List<StreamItem> {
        val baseUrl = normalizeServer(config.url)
        val (categoriesAction, streamsAction, type) = when (section) {
            XtreamSection.MOVIES -> Triple("get_vod_categories", "get_vod_streams", ContentType.MOVIE)
            XtreamSection.SERIES -> Triple("get_series_categories", "get_series", ContentType.SERIES)
        }
        val sectionCategories = categories(baseUrl, config, categoriesAction)
        val seen = mutableSetOf<String>()
        val output = mutableListOf<StreamItem>()
        output += streams(
            baseUrl = baseUrl,
            config = config,
            action = streamsAction,
            categories = sectionCategories,
            type = type,
            onChunk = { chunk ->
                chunk.forEach { item -> if (seen.add(item.browseKey)) output += item }
                onProgress?.invoke(output.size)
            },
        )
        return output.toList()
    }

    fun loadEpisodes(config: PlaylistConfig, seriesId: Int): List<StreamItem> {
        require(config.type == PlaylistType.XTREAM)
        val baseUrl = normalizeServer(config.url)
        val payload = JSONObject(
            http.get(apiUrl(baseUrl, config, "get_series_info", "series_id" to seriesId.toString())),
        )
        val output = mutableListOf<StreamItem>()
        val episodes = payload.opt("episodes")
        when (episodes) {
            is JSONObject -> {
                val seasons = episodes.keys()
                while (seasons.hasNext()) {
                    val seasonKey = seasons.next()
                    val values = episodes.optJSONArray(seasonKey) ?: continue
                    appendEpisodes(output, values, seasonKey, baseUrl, config)
                }
            }
            is JSONArray -> appendEpisodes(output, episodes, "1", baseUrl, config)
        }
        return output.sortedWith(
            compareBy<StreamItem> { it.categoryId?.toIntOrNull() ?: Int.MAX_VALUE }
                .thenBy { it.subtitle.orEmpty() },
        )
    }

    private fun appendEpisodes(
        output: MutableList<StreamItem>,
        episodes: JSONArray,
        season: String,
        baseUrl: String,
        config: PlaylistConfig,
    ) {
        for (index in 0 until episodes.length()) {
            val row = episodes.optJSONObject(index) ?: continue
            val id = row.optString("id").ifBlank { row.optInt("id", -1).toString() }
            if (id.isBlank() || id == "-1") continue
            val extension = row.optString("container_extension").ifBlank { "mp4" }
            val episodeNumber = row.optInt("episode_num", index + 1)
            val info = row.optJSONObject("info")
            val title = row.optString("title").ifBlank { "Episode $episodeNumber" }
            val generatedUrl = "$baseUrl/series/${path(config.username)}/${path(config.password)}/${path(id)}.${safeExtension(extension)}"
            val directSource = row.optString("direct_source").trim()
            output += StreamItem(
                id = "episode-$id",
                name = title,
                // Some portals return a signed HLS URL for episodes. Prefer it
                // when present so Media3 can choose an HD rendition instead of
                // being forced to decode a single UHD file.
                streamUrl = directSource.takeIf { isHttpUrl(it) } ?: generatedUrl,
                logoUrl = artworkUrl(info?.optString("movie_image"), "$baseUrl/"),
                categoryId = season,
                categoryName = "Season $season",
                contentType = ContentType.EPISODE,
                subtitle = "S${season.padStart(2, '0')} E${episodeNumber.toString().padStart(2, '0')}",
            )
        }
    }

    private fun categories(
        baseUrl: String,
        config: PlaylistConfig,
        action: String,
    ): Map<String, String> {
        val output = linkedMapOf<String, String>()
        forEachArrayObject(apiUrl(baseUrl, config, action)) { row ->
            val id = row.optString("category_id")
            val name = row.optString("category_name")
            if (id.isNotBlank() && name.isNotBlank()) {
                output[id] = name
            }
        }
        return output
    }

    private fun streams(
        baseUrl: String,
        config: PlaylistConfig,
        action: String,
        categories: Map<String, String>,
        type: ContentType,
        onChunk: ((List<StreamItem>) -> Unit)? = null,
    ): List<StreamItem> {
        val output = mutableListOf<StreamItem>()
        var lastChunk = 0
        fun flushChunk(force: Boolean) {
            if (force || output.size - lastChunk >= 5_000) {
                if (output.size > lastChunk) {
                    onChunk?.invoke(output.subList(lastChunk, output.size).toList())
                }
                lastChunk = output.size
            }
        }
        forEachArrayObject(apiUrl(baseUrl, config, action)) objectLoop@{ row ->
            val categoryId = row.optString("category_id").takeIf(String::isNotBlank)
            val categoryName = categoryId?.let(categories::get)
                ?: when (type) {
                    ContentType.LIVE -> "Live TV"
                    ContentType.RADIO -> "Radio"
                    ContentType.MOVIE -> "Movies"
                    ContentType.SERIES -> "Series"
                    ContentType.EPISODE -> "Episodes"
                }
            val name = row.optString("name").ifBlank { "Untitled" }
            val streamType = row.optString("stream_type").trim().lowercase()
            val logo = artworkUrl(when (type) {
                ContentType.SERIES -> row.optString("cover")
                else -> row.optString("stream_icon")
            }, "$baseUrl/")

            if (type == ContentType.SERIES) {
                val seriesId = row.optInt("series_id", -1)
                if (seriesId < 0) return@objectLoop
                output += StreamItem(
                    id = "series-$seriesId",
                    name = name,
                    streamUrl = null,
                    logoUrl = logo,
                    categoryId = categoryId,
                    categoryName = categoryName,
                    contentType = ContentType.SERIES,
                    seriesId = seriesId,
                    subtitle = row.optString("releaseDate").takeIf(String::isNotBlank),
                )
            } else {
                val streamId = row.optString("stream_id")
                    .ifBlank { row.optInt("stream_id", -1).toString() }
                if (streamId.isBlank() || streamId == "-1") return@objectLoop
                val streamUrl = when (type) {
                    ContentType.LIVE -> "$baseUrl/live/${path(config.username)}/${path(config.password)}/${path(streamId)}.${liveExtension(streamType)}"
                    ContentType.MOVIE -> {
                        val extension = if (streamType.contains("m3u8") || streamType.contains("hls")) {
                            "m3u8"
                        } else safeExtension(
                            row.optString("container_extension").ifBlank { "mp4" },
                        )
                        val generatedUrl = "$baseUrl/movie/${path(config.username)}/${path(config.password)}/${path(streamId)}.$extension"
                        val directSource = row.optString("direct_source").trim()
                        directSource.takeIf { isHttpUrl(it) } ?: generatedUrl
                    }
                    else -> null
                }
                val contentType = if (type == ContentType.LIVE && RadioClassifier.isRadio(
                        categoryName, name, streamUrl.orEmpty(),
                        row.optString("radio").ifBlank { row.optString("is_radio") }, row.optString("stream_type")))
                    ContentType.RADIO else type
                output += StreamItem(
                    id = "${type.name.lowercase()}-$streamId",
                    name = name,
                    streamUrl = streamUrl,
                    logoUrl = logo,
                    categoryId = categoryId,
                    categoryName = categoryName,
                    contentType = contentType,
                    epgChannelId = row.optString("epg_channel_id").takeIf { it.isNotBlank() && it != "null" },
                    providerStreamId = streamId,
                )
            }
            flushChunk(false)
        }
        flushChunk(true)
        return output
    }

    private fun forEachArrayObject(url: String, block: (JSONObject) -> Unit) {
        http.withReader(url, MAX_XTREAM_CHARACTERS) { reader ->
            JsonObjectArrayReader(reader).forEach(block)
        }
    }

    private fun validateAccount(payload: JSONObject) {
        val user = payload.optJSONObject("user_info")
            ?: throw AppError.PortalNoAccount
        val auth = user.opt("auth")?.toString()
        if (auth != "1" && !auth.equals("true", ignoreCase = true)) {
            throw AppError.PortalBadCredentials
        }
        val status = user.optString("status")
        if (status.isNotBlank() && !status.equals("active", ignoreCase = true)) {
            throw AppError.PortalStatus(status)
        }
    }

    private fun apiUrl(
        baseUrl: String,
        config: PlaylistConfig,
        action: String? = null,
        extra: Pair<String, String>? = null,
    ): String = buildString {
        append(baseUrl)
        append("/player_api.php?username=")
        append(query(config.username))
        append("&password=")
        append(query(config.password))
        action?.let {
            append("&action=")
            append(query(it))
        }
        extra?.let { (key, value) ->
            append('&')
            append(query(key))
            append('=')
            append(query(value))
        }
    }

    private fun normalizeServer(value: String): String {
        val server = value.trim().trimEnd('/')
            .substringBefore("/player_api.php")
            .substringBefore("/get.php")
        require(server.startsWith("http://") || server.startsWith("https://")) {
            "Server URL must start with http:// or https://"
        }
        return server
    }

    private fun query(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun path(value: String): String = query(value).replace("+", "%20")

    private fun safeExtension(value: String): String = value
        .lowercase()
        .filter { it.isLetterOrDigit() }
        .ifBlank { "mp4" }

    private fun liveExtension(streamType: String): String = when {
        streamType.contains("m3u8") || streamType.contains("hls") -> "m3u8"
        else -> "ts"
    }

    private fun isHttpUrl(value: String): Boolean =
        value.startsWith("http://", ignoreCase = true) || value.startsWith("https://", ignoreCase = true)

    private companion object {
        const val MAX_XTREAM_CHARACTERS = 128 * 1024 * 1024
    }

    private class JsonObjectArrayReader(
        private val reader: Reader,
    ) {
        fun forEach(block: (JSONObject) -> Unit) {
            var token = nextNonWhitespace()
            if (token != '['.code) invalidResponse()

            token = nextNonWhitespace()
            if (token == ']'.code) return

            while (token >= 0) {
                if (token != '{'.code) invalidResponse()
                block(JSONObject(readObject()))

                token = nextNonWhitespace()
                when (token) {
                    ','.code -> token = nextNonWhitespace()
                    ']'.code -> return
                    else -> invalidResponse()
                }
            }
            invalidResponse()
        }

        private fun readObject(): String {
            val output = StringBuilder().append('{')
            var depth = 1
            var inString = false
            var escaped = false

            while (depth > 0) {
                val value = reader.read()
                if (value < 0) invalidResponse()
                val character = value.toChar()
                output.append(character)

                if (inString) {
                    when {
                        escaped -> escaped = false
                        character == '\\' -> escaped = true
                        character == '"' -> inString = false
                    }
                } else {
                    when (character) {
                        '"' -> inString = true
                        '{' -> depth += 1
                        '}' -> depth -= 1
                    }
                }
            }
            return output.toString()
        }

        private fun nextNonWhitespace(): Int {
            while (true) {
                val value = reader.read()
                if (value < 0) return value
                val character = value.toChar()
                if (!character.isWhitespace() && character != '\uFEFF') return value
            }
        }

            private fun invalidResponse(): Nothing =
                throw AppError.PortalBadList
    }
}

package com.libertyvue.player.data

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.Reader
import java.io.PushbackInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

class HttpTextClient {
    fun get(url: String, maxCharacters: Int = DEFAULT_MAX_CHARACTERS): String {
        return withReader(url, maxCharacters) { reader ->
            val output = StringBuilder()
            val buffer = CharArray(8_192)
            while (true) {
                val read = reader.read(buffer)
                if (read < 0) break
                output.append(buffer, 0, read)
            }
            output.toString()
        }
    }

    fun <T> withReader(
        url: String,
        maxCharacters: Int = DEFAULT_MAX_CHARACTERS,
        block: (BufferedReader) -> T,
    ): T {
        require(maxCharacters > 0) { "Response limit must be positive" }
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json, application/x-mpegURL, text/plain, */*")
            setRequestProperty("Accept-Encoding", "gzip")
            setRequestProperty("User-Agent", "LibertyVuePlayer/0.6 (Android TV)")
        }

        return try {
            val status = connection.responseCode
            if (status !in 200..299) {
                throw AppError.HttpStatus(status)
            }
            val raw = PushbackInputStream(connection.inputStream, 2)
            val first = raw.read()
            val second = raw.read()
            if (second >= 0) raw.unread(second)
            if (first >= 0) raw.unread(first)
            // Also handles .xml.gz sources without a Content-Encoding header.
            val input = if (first == 0x1f && second == 0x8b) GZIPInputStream(raw) else raw
            BufferedReader(
                CharacterLimitReader(
                    InputStreamReader(input, Charsets.UTF_8),
                    maxCharacters,
                ),
            ).use(block)
        } finally {
            connection.disconnect()
        }
    }

    private companion object {
        const val DEFAULT_MAX_CHARACTERS = 20 * 1024 * 1024
    }

    private class CharacterLimitReader(
        private val delegate: Reader,
        private val maxCharacters: Int,
    ) : Reader() {
        private var charactersRead = 0L

        override fun read(buffer: CharArray, offset: Int, length: Int): Int {
            val read = delegate.read(buffer, offset, length)
            if (read > 0) {
                charactersRead += read
                if (charactersRead > maxCharacters) {
                    throw AppError.PlaylistTooLarge
                }
            }
            return read
        }

        override fun close() = delegate.close()
    }
}

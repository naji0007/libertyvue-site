package com.libertyvue.player.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.Reader
import java.io.StringReader
import java.net.URI
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import javax.xml.parsers.SAXParserFactory
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler

class EpgRepository(private val http: HttpTextClient = HttpTextClient()) {
    private val xmlMutex = Mutex()
    private var xmlCacheUrl: String? = null
    private var xmlCacheTime = 0L
    private var xmlCache: Map<String, List<EpgProgram>> = emptyMap()
    private var xmlCacheIds: Set<String> = emptySet()

    suspend fun load(
        config: PlaylistConfig,
        xtream: PlaylistConfig?,
        channel: StreamItem,
        xmlUrl: String?,
        channels: List<StreamItem>,
    ): List<EpgProgram> = withContext(Dispatchers.IO) {
        // An explicit XMLTV source always wins over automatic portal discovery.
        val source = config.epgUrl.ifBlank { xmlUrl.orEmpty() }
        if (source.isNotBlank()) {
            PlaylistRepository.validateHttpUrl(source, AppError.UrlLabel.XMLTV)
            return@withContext xmlMutex.withLock {
                val ids = channels.mapNotNull { it.epgChannelId }.toSet()
                if (xmlCacheUrl != source || xmlCacheIds != ids || System.currentTimeMillis() - xmlCacheTime > 15 * 60_000) {
                    if (ids.isEmpty()) throw AppError.EpgNoTvgId
                    val result = http.withReader(source, 256 * 1024 * 1024) {
                        XmlTvParser().parse(it, ids, System.currentTimeMillis())
                    }
                    xmlCache = result
                    xmlCacheUrl = source
                    xmlCacheIds = ids
                    xmlCacheTime = System.currentTimeMillis()
                }
                xmlCache[channel.epgChannelId].orEmpty()
            }
        }
        if (xtream == null) {
            throw AppError.EpgNoSource
        }
        val id = channel.providerStreamId ?: runCatching {
            URI(channel.streamUrl.orEmpty().substringBefore('|')).path
                .substringAfterLast('/').substringBefore('.').takeIf { it.toLongOrNull() != null }
        }.getOrNull() ?: throw AppError.EpgNoStreamId
        val base = xtream.url.trim().trimEnd('/').substringBefore("/player_api.php").substringBefore("/get.php")
        val url = "$base/player_api.php?username=${query(xtream.username)}&password=${query(xtream.password)}" +
            "&action=get_short_epg&stream_id=${query(id)}&limit=12"
        val root = JSONObject(http.get(url, 4 * 1024 * 1024))
        val rows = root.optJSONArray("epg_listings") ?: return@withContext emptyList()
        buildList {
            for (index in 0 until rows.length()) {
                val row = rows.optJSONObject(index) ?: continue
                val start = epochMillis(row.optString("start_timestamp")) ?: continue
                val end = epochMillis(row.optString("stop_timestamp"))
                    ?: epochMillis(row.optString("end_timestamp")) ?: continue
                if (end <= start) continue
                add(EpgProgram(decode(row.optString("title")).ifBlank { "Programme" },
                    decode(row.optString("description")), start, end))
            }
        }.distinctBy { it.startMillis to it.title }.sortedBy { it.startMillis }
    }

    suspend fun invalidate() = xmlMutex.withLock { xmlCacheTime = 0L }

    private fun epochMillis(value: String): Long? = value.toLongOrNull()?.takeIf { it > 0 }?.let {
        if (it < 100_000_000_000L) it * 1000 else it
    }

    private fun query(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun decode(value: String): String = runCatching {
        val decoded = String(Base64.decode(value, Base64.DEFAULT), Charsets.UTF_8)
        if (decoded.contains('\uFFFD') || decoded.any { it.isISOControl() && it !in "\n\r\t" }) value else decoded
    }.getOrDefault(value)
}

/** Streaming XMLTV reader: keeps only relevant channels and the next two days. */
class XmlTvParser {
    fun parse(reader: Reader, channelIds: Set<String>, now: Long): Map<String, List<EpgProgram>> {
        val output = mutableMapOf<String, MutableList<EpgProgram>>()
        val factory = SAXParserFactory.newInstance().apply { isNamespaceAware = false; isValidating = false }
        runCatching { factory.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true) }
        val parser = factory.newSAXParser().xmlReader
        listOf(
            "http://xml.org/sax/features/external-general-entities",
            "http://xml.org/sax/features/external-parameter-entities",
            "http://apache.org/xml/features/nonvalidating/load-external-dtd",
        ).forEach { feature -> runCatching { parser.setFeature(feature, false) } }
        parser.entityResolver = org.xml.sax.EntityResolver { _, _ -> InputSource(StringReader("")) }
        parser.contentHandler = object : DefaultHandler() {
            var channel: String? = null
            var start = 0L
            var stop = 0L
            var field: String? = null
            val text = StringBuilder()
            var title = ""
            var description = ""
            var retainedCount = 0

            override fun startElement(uri: String?, localName: String?, qName: String, attributes: Attributes) {
                if (qName == "programme") {
                    val id = attributes.getValue("channel")
                    start = parseTime(attributes.getValue("start")) ?: 0L
                    stop = parseTime(attributes.getValue("stop")) ?: 0L
                    channel = id?.takeIf { it in channelIds && stop > now - 6 * 3_600_000L &&
                        start < now + 48 * 3_600_000L && stop > start && retainedCount < 100_000 }
                    title = ""; description = ""
                } else if (channel != null && qName in listOf("title", "desc")) {
                    field = qName
                    text.setLength(0)
                }
            }

            override fun characters(ch: CharArray, start: Int, length: Int) {
                if (field != null && text.length < 8192) text.append(ch, start, minOf(length, 8192 - text.length))
            }

            override fun endElement(uri: String?, localName: String?, qName: String) {
                if (qName == field) {
                    if (field == "title" && title.isBlank()) title = text.toString().trim()
                    if (field == "desc" && description.isBlank()) description = text.toString().trim()
                    field = null
                }
                if (qName == "programme") {
                    channel?.let { id ->
                        if (title.isNotBlank()) {
                            output.getOrPut(id) { mutableListOf() }.add(EpgProgram(title, description, start, stop))
                            retainedCount++
                        }
                    }
                    channel = null; field = null
                }
            }
        }
        parser.parse(InputSource(reader))
        return output.mapValues { (_, programs) -> programs.distinctBy { it.startMillis to it.title }.sortedBy { it.startMillis } }
    }

    companion object {
        fun parseTime(value: String?): Long? {
            if (value.isNullOrBlank()) return null
            val parts = value.trim().split(Regex("\\s+"), limit = 2)
            val pattern = when (parts[0].length) {
                14 -> "yyyyMMddHHmmss"
                12 -> "yyyyMMddHHmm"
                else -> return null
            }
            val hasZone = parts.size > 1
            return runCatching {
                SimpleDateFormat(pattern + if (hasZone) " Z" else "", Locale.US).apply {
                    isLenient = false
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(value.trim())?.time
            }.getOrNull()
        }
    }
}

package com.libertyvue.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.libertyvue.player.AppUiState
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.pickLanguage

@Composable
fun MultiScreen(state: AppUiState, onBack: () -> Unit, onSize: (Int) -> Unit,
    onChannel: (Int, StreamItem?) -> Unit, onAudio: (Int) -> Unit) {
    var choosingSlot by remember { mutableStateOf<Int?>(null) }
    val channels = remember(state.catalogItems) { state.catalogItems.filter { it.contentType == ContentType.LIVE && !it.streamUrl.isNullOrBlank() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        TvTopBar(pickLanguage("Multi-écrans", "Multi-screen", "شاشات متعددة"), onBack) {
            FilterChip(state.multiSize == 2, { onSize(2) }, label = { Text(pickLanguage("2 écrans", "2 screens", "شاشتين")) })
            FilterChip(state.multiSize == 4, { onSize(4) }, label = { Text(pickLanguage("4 écrans", "4 screens", "4 شاشات")) },
                enabled = state.maxConnections == null || state.maxConnections >= 4)
        }
        Text(state.maxConnections?.let { "${pickLanguage("Compte :", "Account:", "الحساب:")} $it ${pickLanguage("connexions maximum · Choisissez une chaîne dans chaque écran.", "connections max · Choose a channel per screen.", "اتصالات كحد أقصى · اختر قناة لكل شاشة.")}" }
            ?: pickLanguage("Chaque écran utilise une connexion. Vérifiez l’autorisation de votre fournisseur.", "Each screen uses one connection. Check your provider allowance.", "كل شاشة تستعمل اتصالاً. تحقق من المسموح به لدى مزودك."),
            color = LibertyMuted, fontSize = 12.sp, maxLines = 2)
        Spacer(Modifier.height(6.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(if (state.multiSize == 4) 2 else 1) { row ->
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(2) { column ->
                        val slot = row * 2 + column
                        val channel = state.multiSlots[slot]
                        val audible = state.audioSlot == slot
                        Surface(Modifier.weight(1f).fillMaxHeight(), color = LibertyPanel,
                            border = BorderStroke(if (audible) 2.dp else 1.dp, if (audible) LibertyGold else LibertyPanelSoft),
                            shape = RoundedCornerShape(12.dp)) {
                            Column {
                                Row(Modifier.fillMaxWidth().height(42.dp).padding(horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text("${slot + 1}. ${channel?.name ?: pickLanguage("Choisir une chaîne", "Choose a channel", "اختر قناة")}", Modifier.weight(1f),
                                        fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    IconButton(onClick = { choosingSlot = slot }, modifier = Modifier.size(38.dp)) {
                                        Icon(Icons.Default.Edit, "${pickLanguage("Choisir la chaîne", "Choose channel", "اختر القناة")} ${slot + 1}", Modifier.size(18.dp))
                                    }
                                    if (channel != null) {
                                        IconButton(onClick = { onAudio(slot) }, modifier = Modifier.size(38.dp)) {
                                            Icon(if (audible) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                                "${pickLanguage("Écouter l’écran", "Listen to screen", "استمع للشاشة")} ${slot + 1}", Modifier.size(18.dp), tint = if (audible) LibertyGold else LibertyMuted)
                                        }
                                        IconButton(onClick = { onChannel(slot, null) }, modifier = Modifier.size(38.dp)) {
                                            Icon(Icons.Default.Close, "${pickLanguage("Arrêter l’écran", "Stop screen", "إيقاف الشاشة")} ${slot + 1}", Modifier.size(18.dp))
                                        }
                                    }
                                }
                                if (channel == null) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    OutlinedButton(onClick = { choosingSlot = slot }) { Icon(Icons.Default.Add, null); Text(pickLanguage("Ajouter une chaîne", "Add a channel", "إضافة قناة")) }
                                } else VideoPane(channel, Modifier.weight(1f).fillMaxWidth(), audible = audible, compact = true)
                            }
                        }
                    }
                }
            }
        }
    }
    choosingSlot?.let { slot ->
        var query by remember(slot) { mutableStateOf("") }
        val filtered = remember(channels, query) { channels.filter { it.name.contains(query, true) || it.categoryName.contains(query, true) } }
        AlertDialog(onDismissRequest = { choosingSlot = null }, title = { Text("${pickLanguage("Chaîne pour l’écran", "Channel for screen", "قناة للشاشة")} ${slot + 1}") },
            text = { Column {
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text(pickLanguage("Rechercher", "Search", "بحث")) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(filtered, key = { "${it.id}:${it.streamUrl}" }) { channel ->
                        TextButton(onClick = { onChannel(slot, channel); choosingSlot = null }, modifier = Modifier.fillMaxWidth()) {
                            Text(channel.name, Modifier.fillMaxWidth(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (filtered.isEmpty()) item { Text(pickLanguage("Aucune chaîne trouvée", "No channel found", "لا توجد قنوات"), Modifier.padding(10.dp)) }
                }
            } }, confirmButton = { TextButton(onClick = { choosingSlot = null }) { Text(pickLanguage("Fermer", "Close", "إغلاق")) } })
    }
}

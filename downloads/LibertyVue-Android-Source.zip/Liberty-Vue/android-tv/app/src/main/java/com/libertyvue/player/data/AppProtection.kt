package com.libertyvue.player.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.libertyvue.player.BuildConfig
import java.io.File
import java.security.MessageDigest

/** Release protections: repackaged clones are blocked, recording is disabled. */
object AppProtection {
    // SHA-256 of the stable release certificate (same key reused for every update).
    private const val RELEASE_SHA256 =
        "EA:6E:40:1A:96:1C:74:32:3F:99:16:F7:BD:F6:14:02:BF:3E:C2:D2:E8:95:64:A2:12:7A:EB:B6:7F:2D:DE:8A"

    /** False when a release build is not signed with the official certificate. */
    fun isGenuine(context: Context): Boolean {
        if (BuildConfig.DEBUG) return true
        val signatures = runCatching {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                context.packageManager.getPackageInfo(
                    context.packageName, PackageManager.GET_SIGNING_CERTIFICATES,
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signing = info.signingInfo ?: return false
                if (signing.hasMultipleSigners()) signing.apkContentsSigners else signing.signingCertificateHistory
            } else {
                @Suppress("DEPRECATION")
                info.signatures
            }
        }.getOrNull() ?: return false
        if (signatures.isEmpty()) return false
        val digest = MessageDigest.getInstance("SHA-256")
        return signatures.any { signature ->
            digest.digest(signature.toByteArray()).joinToString(":") { "%02X".format(it) } == RELEASE_SHA256
        }
    }

    /** Best-effort rooted-device detection (warning only, never a block). */
    fun isRooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        if (File("/system/app/Superuser.apk").exists()) return true
        val paths = (System.getenv("PATH") ?: "/sbin:/system/sbin:/system/bin:/system/xbin").split(':')
        return paths.any { dir ->
            File(dir, "su").exists()
        }
    }

    fun tamperMessage(): String = pickLanguage(
        "Application non officielle détectée. Installez la version originale LibertyVue.",
        "Unofficial app detected. Please install the original LibertyVue version.",
        "تم اكتشاف نسخة غير رسمية. ثبّت نسخة LibertyVue الأصلية.",
    )

    fun rootWarning(): String = pickLanguage(
        "Appareil rooté détecté : la lecture peut être instable et la garantie annulée.",
        "Rooted device detected: playback may be unstable and warranty void.",
        "تم اكتشاف جهاز مروت: قد يكون التشغيل غير مستقر والضمان لاغياً.",
    )
}

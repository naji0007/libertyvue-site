package com.libertyvue.player

import android.os.Bundle
import android.view.KeyEvent
import android.view.Window
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.libertyvue.player.ui.LibertyVueApp
import com.libertyvue.player.ui.LibertyVueTheme
import com.libertyvue.player.data.AppLanguage
import com.libertyvue.player.data.CrashReporter
import com.libertyvue.player.data.SettingsStore
import coil3.ImageLoader
import coil3.SingletonImageLoader
import coil3.disk.DiskCache
import coil3.memory.MemoryCache
import okio.Path.Companion.toOkioPath

class MainActivity : ComponentActivity() {
    // PlayerView can own native focus, so route TV keys before either view system consumes them.
    var playerKeyHandler: ((KeyEvent) -> Boolean)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(this)
        // Release builds cannot be screenshotted or screen-recorded.
        if (!com.libertyvue.player.BuildConfig.DEBUG) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE,
            )
        }
        AppLanguage.override = SettingsStore(this).language()
        // Use the public Window callback API; ComponentActivity's override is AndroidX-internal.
        val activityCallback = window.callback
        window.callback = object : Window.Callback by activityCallback {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean =
                playerKeyHandler?.invoke(event) == true || activityCallback.dispatchKeyEvent(event)
        }
        // Disk cache creation can fail on full storage: never let it kill startup.
        runCatching {
            SingletonImageLoader.setSafe { context ->
                runCatching {
                    ImageLoader.Builder(context)
                        // 25% of the app memory class: big catalogs keep their logos
                        // in memory while scrolling instead of reloading them.
                        .memoryCache {
                            MemoryCache.Builder().maxSizePercent(context, 0.25).build()
                        }
                        // Half a gigabyte on disk so channel and poster artwork
                        // survives app restarts.
                        .diskCache {
                            DiskCache.Builder()
                                .directory(context.cacheDir.resolve("libertyvue_images").toOkioPath())
                                .maxSizeBytes(512L * 1024 * 1024)
                                .build()
                        }.build()
                }.getOrElse {
                    ImageLoader.Builder(context).build()
                }
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            LibertyVueTheme {
                LibertyVueApp()
            }
        }
    }
}

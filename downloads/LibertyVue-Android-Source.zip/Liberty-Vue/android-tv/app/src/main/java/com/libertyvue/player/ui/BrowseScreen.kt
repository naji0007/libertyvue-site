package com.libertyvue.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.libertyvue.player.AppScreen
import com.libertyvue.player.AppUiState
import com.libertyvue.player.LibraryFilter
import com.libertyvue.player.data.usesStationArtwork
import com.libertyvue.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.ceil

@Composable
internal fun BrowseScreen(state: AppUiState, onBack: () -> Unit, onRefresh: () -> Unit,
    onCategory: (String?) -> Unit, onSearch: (String) -> Unit, onOpen: (StreamItem) -> Unit,
    onScope: (BrowseScope) -> Unit, onSort: (BrowseSort) -> Unit, onLayout: () -> Unit,
    onFavorite: (StreamItem) -> Unit) {
    var categoryQuery by rememberSaveable { mutableStateOf("") }
    var sortMenu by remember { mutableStateOf(false) }
    var searchVisible by rememberSaveable { mutableStateOf(state.search.isNotBlank()) }
    var focusedTitle by rememberSaveable { mutableStateOf("") }
    val catalog by produceState<BrowseCatalog?>(null, state.items, state.filter) {
        value = null
        value = withContext(Dispatchers.Default) {
            BrowseCatalog(state.items.filter {
                when (state.filter) {
                    LibraryFilter.ALL -> true
                    LibraryFilter.LIVE -> it.contentType == ContentType.LIVE
                    LibraryFilter.RADIO -> it.contentType == ContentType.RADIO
                    LibraryFilter.MOVIES -> it.contentType == ContentType.MOVIE
                    LibraryFilter.SERIES -> it.contentType == ContentType.SERIES || it.contentType == ContentType.EPISODE
                }
            })
        }
    }
    val visible by produceState<List<StreamItem>?>(null, catalog, state.category, state.search,
        state.browseScope, state.browseSort, state.browseMemory) {
        value = null
        if (state.search.isNotBlank()) delay(120)
        value = withContext(Dispatchers.Default) {
            catalog?.select(state.category, state.search, state.browseScope, state.browseSort,
                state.browseMemory.favorites, state.browseMemory.history)
        }
    }
    val categories = remember(catalog, categoryQuery) {
        catalog?.categories?.entries?.filter { it.key.contains(categoryQuery.trim(), ignoreCase = true) }.orEmpty()
    }
    val favoritesCount = remember(catalog, state.browseMemory.favorites) {
        state.browseMemory.favorites.count { catalog?.byKey?.containsKey(it) == true }
    }
    val historyCount = remember(catalog, state.browseMemory.history) {
        state.browseMemory.history.count { catalog?.byKey?.containsKey(it) == true }
    }
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    val categoryState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    var restoreFocus by remember { mutableStateOf(state.lastBrowsedKey != null) }
    val contentKey = "${state.category}:${state.search}:${state.browseScope}:${state.browseSort}"
    var previousKey by rememberSaveable { mutableStateOf(contentKey) }
    LaunchedEffect(contentKey) {
        if (previousKey != contentKey) {
            restoreFocus = false
            gridState.scrollToItem(0); listState.scrollToItem(0)
            focusedTitle = ""
            previousKey = contentKey
        }
    }
    LaunchedEffect(categoryQuery) {
        if (categoryQuery.isNotBlank()) categoryState.scrollToItem(0)
    }
    LaunchedEffect(visible, state.lastBrowsedKey) {
        if (restoreFocus && visible != null) {
            val index = visible!!.indexOfFirst { it.browseKey == state.lastBrowsedKey }
            if (index >= 0) {
                withFrameNanos { }
                if (state.browseAsList) {
                    if (listState.layoutInfo.visibleItemsInfo.none { it.index == index }) listState.scrollToItem(index)
                } else if (gridState.layoutInfo.visibleItemsInfo.none { it.index == index }) gridState.scrollToItem(index)
                withFrameNanos { }
                runCatching { focusRequester.requestFocus() }
            }
            restoreFocus = false
        }
    }
    val section = if (state.screen == AppScreen.EPISODES) state.sectionTitle else state.filter.title()
    val selectedLabel = when (state.browseScope) {
        BrowseScope.FAVORITES -> pickLanguage("Favoris", "Favorites", "المفضلة")
        BrowseScope.HISTORY -> pickLanguage("Récents", "Recent", "الأخيرة")
        BrowseScope.ALL -> state.category ?: pickLanguage("Tout", "All", "الكل")
    }
    BoxWithConstraints(Modifier.fillMaxSize().imePadding()) {
        // Téléphone (étroit ou bas comme en paysage) : barre latérale cachée
        // par défaut et une seule ligne d'outils compacte en haut.
        val narrow = maxWidth < 640.dp
        val compactHeight = maxHeight < 520.dp
        val phoneUi = narrow || compactHeight
        var sidebarVisible by rememberSaveable(phoneUi) { mutableStateOf(!phoneUi) }
        val sidebarWidth = (maxWidth * .27f).coerceIn(172.dp, 244.dp)
        val contentWidth = maxWidth - 28.dp - (if (sidebarVisible) sidebarWidth + 12.dp else 0.dp)
        val targetWidth = if (state.filter == LibraryFilter.LIVE || state.filter == LibraryFilter.RADIO) 118.dp
            else ((maxHeight - 180.dp) * (2f / 3f)).coerceIn(80.dp, 124.dp)
        val columns = ceil((contentWidth.value + 8f) / (targetWidth.value + 8f)).toInt().coerceIn(2, 10)
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 7.dp)) {
            if (phoneUi) {
                // Une seule ligne compacte en haut sur téléphone.
                Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BrowseAction(Icons.Default.ArrowBack, pickLanguage("Retour", "Back", "رجوع"), onBack, boxSize = 34.dp)
                    BrowseAction(Icons.Default.Menu, if (sidebarVisible) pickLanguage("Masquer les catégories", "Hide categories", "إخفاء الفئات") else pickLanguage("Afficher les catégories", "Show categories", "إظهار الفئات"),
                        { sidebarVisible = !sidebarVisible }, selected = sidebarVisible, boxSize = 34.dp)
                    if (state.screen == AppScreen.LIBRARY) BrowseAction(Icons.Default.Refresh, pickLanguage("Actualiser", "Refresh", "تحديث"), onRefresh,
                        enabled = !state.loading, boxSize = 34.dp)
                    if (searchVisible) BrowseSearch(state.search, onSearch, pickLanguage("Rechercher", "Search", "بحث"), Modifier.weight(1f), minHeight = 34.dp)
                    else Text(
                        if (state.filter in state.sectionLoading && (state.filter == LibraryFilter.MOVIES || state.filter == LibraryFilter.SERIES)) {
                            "$selectedLabel · ${pickLanguage("Chargement…", "Loading…", "جارٍ التحميل…")} ${formatCount(state.loadingCount)}"
                        } else {
                            visible?.size?.let { "${formatCount(it)} ${pickLanguage("éléments", "items", "عنصر")}" } ?: "…"
                        }, Modifier.weight(1f),
                        color = LibertyMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    BrowseAction(if (searchVisible) Icons.Default.Close else Icons.Default.Search,
                        if (searchVisible) pickLanguage("Fermer la recherche", "Close search", "إغلاق البحث") else pickLanguage("Rechercher", "Search", "بحث"), {
                            searchVisible = !searchVisible
                            if (!searchVisible) onSearch("")
                        }, selected = searchVisible, boxSize = 34.dp)
                    Box {
                        BrowseAction(Icons.Default.Sort, "${pickLanguage("Trier", "Sort", "ترتيب")} : ${state.browseSort.label()}", { sortMenu = true }, boxSize = 34.dp)
                        DropdownMenu(sortMenu, onDismissRequest = { sortMenu = false }) {
                            BrowseSort.entries.forEach { sort ->
                                DropdownMenuItem(text = { Text(sort.label(), fontSize = 14.sp) },
                                    leadingIcon = { if (sort == state.browseSort) Icon(Icons.Default.Check, null, tint = LibertyGold) },
                                    onClick = { onSort(sort); sortMenu = false })
                            }
                        }
                    }
                    BrowseAction(if (state.browseAsList) Icons.Default.GridView else Icons.Default.ViewList,
                        if (state.browseAsList) pickLanguage("Afficher la grille", "Show grid", "عرض الشبكة") else pickLanguage("Afficher la liste", "Show list", "عرض القائمة"), onLayout, boxSize = 34.dp)
                }
                Text("$selectedLabel", color = LibertyGold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            } else {
            Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrowseAction(Icons.Default.ArrowBack, pickLanguage("Retour", "Back", "رجوع"), onBack)
                Column(Modifier.weight(1f)) {
                    Text(section, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("LibertyVue  /  ${state.activePlaylist?.name.orEmpty()}", color = LibertyMuted,
                        fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                BrowseAction(Icons.Default.Menu, if (sidebarVisible) pickLanguage("Masquer les catégories", "Hide categories", "إخفاء الفئات") else pickLanguage("Afficher les catégories", "Show categories", "إظهار الفئات"),
                    { sidebarVisible = !sidebarVisible }, selected = sidebarVisible)
                if (state.screen == AppScreen.LIBRARY) BrowseAction(Icons.Default.Refresh, pickLanguage("Actualiser", "Refresh", "تحديث"), onRefresh, enabled = !state.loading)
            }
            }
            Spacer(Modifier.height(if (narrow) 4.dp else 8.dp))
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (sidebarVisible) Column(Modifier.width(sidebarWidth).fillMaxHeight().focusGroup()) {
                    BrowseSearch(categoryQuery, { categoryQuery = it }, pickLanguage("Catégories", "Categories", "الفئات"), Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.weight(1f), state = categoryState,
                        verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                        item {
                            CategoryRow(pickLanguage("Tout", "All", "الكل"), catalog?.items?.size ?: 0,
                                state.browseScope == BrowseScope.ALL && state.category == null, Icons.Default.Apps) { onCategory(null) }
                            CategoryRow(pickLanguage("Favoris", "Favorites", "المفضلة"), favoritesCount, state.browseScope == BrowseScope.FAVORITES,
                                Icons.Default.StarOutline) { onScope(BrowseScope.FAVORITES) }
                            CategoryRow(pickLanguage("Récents", "Recent", "الأخيرة"), historyCount, state.browseScope == BrowseScope.HISTORY,
                                Icons.Default.History) { onScope(BrowseScope.HISTORY) }
                            HorizontalDivider(Modifier.padding(vertical = 7.dp), color = LibertyBorder)
                        }
                        items(categories, key = { it.key }) { category ->
                            CategoryRow(category.key, category.value,
                                state.category == category.key && state.browseScope == BrowseScope.ALL) { onCategory(category.key) }
                        }
                        if (categories.isEmpty() && categoryQuery.isNotBlank()) item {
                            Text(pickLanguage("Aucune catégorie", "No category", "لا توجد فئات"), Modifier.padding(12.dp), color = LibertyMuted, fontSize = 13.sp)
                        }
                    }
                }
                Column(Modifier.weight(1f).fillMaxHeight().focusGroup()) {
                    if (!phoneUi) {
                    Row(Modifier.height(40.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (searchVisible) BrowseSearch(state.search, onSearch, pickLanguage("Rechercher", "Search", "بحث"), Modifier.weight(1f))
                        else Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(selectedLabel, color = LibertyGold, fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (state.filter in state.sectionLoading && (state.filter == LibraryFilter.MOVIES || state.filter == LibraryFilter.SERIES)) {
                                    "${pickLanguage("Chargement…", "Loading…", "جارٍ التحميل…")} ${formatCount(state.loadingCount)}"
                                } else {
                                    visible?.size?.let { "${formatCount(it)} ${pickLanguage("éléments", "items", "عنصر")}" } ?: "…"
                                }, color = LibertyMuted, fontSize = 11.sp)
                        }
                        BrowseAction(if (searchVisible) Icons.Default.Close else Icons.Default.Search,
                            if (searchVisible) pickLanguage("Fermer la recherche", "Close search", "إغلاق البحث") else pickLanguage("Rechercher", "Search", "بحث"), {
                                searchVisible = !searchVisible
                                if (!searchVisible) onSearch("")
                            }, selected = searchVisible)
                        Box {
                            BrowseAction(Icons.Default.Sort, "${pickLanguage("Trier", "Sort", "ترتيب")} : ${state.browseSort.label()}", { sortMenu = true })
                            DropdownMenu(sortMenu, onDismissRequest = { sortMenu = false }) {
                                BrowseSort.entries.forEach { sort ->
                                    DropdownMenuItem(text = { Text(sort.label(), fontSize = 14.sp) },
                                        leadingIcon = { if (sort == state.browseSort) Icon(Icons.Default.Check, null, tint = LibertyGold) },
                                        onClick = { onSort(sort); sortMenu = false })
                                }
                            }
                        }
                        BrowseAction(if (state.browseAsList) Icons.Default.GridView else Icons.Default.ViewList,
                            if (state.browseAsList) pickLanguage("Afficher la grille", "Show grid", "عرض الشبكة") else pickLanguage("Afficher la liste", "Show list", "عرض القائمة"), onLayout)
                    }
                    }
                    Spacer(Modifier.height(if (phoneUi) 4.dp else 8.dp))
                    val rows = visible
                    when {
                        state.loading || rows == null -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(26.dp), color = LibertyGold, strokeWidth = 2.dp)
                        }
                        rows.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(if (state.browseScope == BrowseScope.FAVORITES) Icons.Default.StarOutline else Icons.Default.Search,
                                    null, Modifier.size(32.dp), tint = LibertyMuted)
                                Text(when {
                                    state.search.isNotBlank() -> pickLanguage("Aucun résultat", "No results", "لا توجد نتائج")
                                    state.browseScope == BrowseScope.FAVORITES -> pickLanguage("Ajoutez des favoris avec l’étoile", "Add favorites with the star", "أضف للمفضلة بالنجمة")
                                    state.browseScope == BrowseScope.HISTORY -> pickLanguage("Vos derniers éléments ouverts apparaîtront ici", "Recently opened items will appear here", "العناصر المفتوحة مؤخراً تظهر هنا")
                                    state.filter == LibraryFilter.RADIO && catalog?.items?.isEmpty() == true -> pickLanguage("Aucune station radio identifiée dans cette liste", "No radio station found in this list", "لا توجد محطات راديو في هذه القائمة")
                                    else -> pickLanguage("Aucun contenu dans cette catégorie", "No content in this category", "لا يوجد محتوى في هذه الفئة")
                                }, color = LibertyMuted, fontSize = 13.sp)
                            }
                        }
                        state.browseAsList -> LazyColumn(Modifier.weight(1f), state = listState,
                            verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                            items(rows, key = { it.browseKey }) { item ->
                                MediaRow(item, item.browseKey in state.browseMemory.favorites,
                                    { onOpen(item) }, { onFavorite(item) }, { focusedTitle = item.name },
                                    if (item.browseKey == state.lastBrowsedKey) Modifier.focusRequester(focusRequester) else Modifier)
                            }
                        }
                        else -> LazyVerticalGrid(columns = GridCells.Fixed(columns),
                            modifier = Modifier.weight(1f), state = gridState,
                            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(9.dp),
                            contentPadding = PaddingValues(bottom = 8.dp)) {
                            gridItems(rows, key = { it.browseKey }) { item ->
                                MediaCard(item, item.browseKey in state.browseMemory.favorites,
                                    { onOpen(item) }, { onFavorite(item) }, { focusedTitle = item.name },
                                    if (item.browseKey == state.lastBrowsedKey) Modifier.focusRequester(focusRequester) else Modifier)
                            }
                        }
                    }
                    Text(focusedTitle.ifBlank { "${state.browseSort.label()}  ·  ★ ${pickLanguage("Favoris", "Favorites", "المفضلة")}" },
                        Modifier.fillMaxWidth().padding(top = 3.dp), color = LibertyMuted, fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun CategoryRow(title: String, count: Int, selected: Boolean, icon: ImageVector? = null, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Surface(onClick = onClick, interactionSource = interaction, modifier = Modifier.fillMaxWidth(),
        color = if (selected) LibertySelected else if (focused) LibertyPanelSoft else Color.Transparent,
        contentColor = LibertyText, shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (focused) LibertyGold else Color.Transparent)) {
        Row(Modifier.heightIn(min = 42.dp).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, Modifier.size(16.dp), tint = if (selected) Color.White else LibertyMuted)
            Text(title, Modifier.weight(1f), fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(count.toString(), color = if (selected) Color.White else LibertyMuted, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun BrowseSearch(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    minHeight: Dp = 40.dp) {
    val focus = LocalFocusManager.current
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Surface(modifier.heightIn(min = minHeight), color = LibertyPanel, shape = RoundedCornerShape(7.dp),
        border = BorderStroke(1.dp, if (focused) LibertyGold else LibertyBorder)) {
        BasicTextField(value, onChange, Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            textStyle = TextStyle(color = LibertyText, fontSize = 14.sp), singleLine = true,
            cursorBrush = SolidColor(LibertyGold), interactionSource = interaction,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
            decorationBox = { input -> Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Search, null, Modifier.size(18.dp), tint = LibertyMuted)
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(hint, color = LibertyMuted, fontSize = 14.sp, maxLines = 1)
                    input()
                }
            } })
    }
}

@Composable
internal fun BrowseAction(icon: ImageVector, label: String, onClick: () -> Unit,
    selected: Boolean = false, enabled: Boolean = true, modifier: Modifier = Modifier, boxSize: Dp = 40.dp) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Surface(onClick = onClick, enabled = enabled, interactionSource = interaction,
        color = if (selected || focused) LibertySelected else LibertyPanel,
        shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, if (focused) LibertyGold else LibertyBorder),
        modifier = modifier.size(boxSize)) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, label, Modifier.size(boxSize * 0.5f), tint = if (!enabled) LibertyMuted else if (selected) LibertyGold else LibertyText)
        }
    }
}

@Composable
private fun MediaCard(item: StreamItem, favorite: Boolean, onOpen: () -> Unit, onFavorite: () -> Unit,
    onFocus: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    LaunchedEffect(focused) { if (focused) onFocus() }
    val live = item.usesStationArtwork
    Surface(onClick = onOpen, interactionSource = interaction, modifier = modifier.fillMaxWidth(),
        color = if (focused) LibertyPanelSoft else LibertyPanel, contentColor = LibertyText,
        shape = RoundedCornerShape(8.dp), border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) LibertyGold else LibertyBorder)) {
        Column {
            Box {
                MediaArtwork(item, Modifier.fillMaxWidth().aspectRatio(if (live) 1.52f else 2f / 3f))
                FavoriteButton(favorite, onFavorite, Modifier.align(Alignment.TopEnd).padding(3.dp))
                if (item.contentType == ContentType.EPISODE && item.subtitle != null) {
                    Text(item.subtitle, Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = .8f))
                        .padding(horizontal = 5.dp, vertical = 3.dp), fontSize = 10.sp, color = Color.White)
                }
            }
            Text(item.name, Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 7.dp),
                fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium,
                minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MediaRow(item: StreamItem, favorite: Boolean, onOpen: () -> Unit, onFavorite: () -> Unit,
    onFocus: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    LaunchedEffect(focused) { if (focused) onFocus() }
    Surface(onClick = onOpen, interactionSource = interaction, modifier = modifier.fillMaxWidth(),
        color = if (focused) LibertyPanelSoft else LibertyPanel, shape = RoundedCornerShape(7.dp),
        border = BorderStroke(1.dp, if (focused) LibertyGold else LibertyBorder)) {
        Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MediaArtwork(item, Modifier.size(if (item.usesStationArtwork) 70.dp else 36.dp, 52.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.name, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(item.subtitle ?: item.categoryName, fontSize = 11.sp, color = LibertyMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            FavoriteButton(favorite, onFavorite)
            Icon(Icons.Default.ChevronRight, null, Modifier.size(20.dp), tint = LibertyMuted)
        }
    }
}

@Composable
private fun FavoriteButton(favorite: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    Surface(onClick = onClick, interactionSource = interaction, modifier = modifier.size(32.dp),
        color = if (focused) LibertySelected else Color(0xC9080D15), shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (focused) LibertyGold else Color.Transparent)) {
        Box(contentAlignment = Alignment.Center) {
            Icon(if (favorite) Icons.Default.Star else Icons.Default.StarOutline,
                if (favorite) pickLanguage("Retirer des favoris", "Remove from favorites", "إزالة من المفضلة") else pickLanguage("Ajouter aux favoris", "Add to favorites", "إضافة للمفضلة"), Modifier.size(18.dp),
                tint = if (favorite) LibertyGold else LibertyMuted)
        }
    }
}

package com.libertyvue.player.data

import java.net.URI
import java.security.MessageDigest

class M3uParser {
    fun parse(document: String, sourceUrl: String? = null): List<StreamItem> =
        parse(document.lineSequence(), sourceUrl)

    fun parse(
        lines: Sequence<String>,
        sourceUrl: String? = null,
    ): List<StreamItem> {
        val items = mutableListOf<StreamItem>()
        var pendingMetadata: String? = null
        var pendingGroup: String? = null
        var firstLine = true

        for (rawLine in lines) {
            val line = if (firstLine) {
                firstLine = false
                rawLine.removePrefix("\uFEFF").trim()
            } else {
                rawLine.trim()
            }

            if (sourceUrl != null && HLS_MARKERS.any { line.startsWith(it, ignoreCase = true) }) {
                return singleHlsStream(sourceUrl)
            }

            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingMetadata = line
                    pendingGroup = null
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                    pendingGroup = line.substringAfter(':').trim().takeIf(String::isNotBlank)
                }
                line.isBlank() || line.startsWith("#") -> Unit
                pendingMetadata != null -> {
                    val metadata = pendingMetadata.orEmpty()
                    val resolvedUrl = resolveUrl(sourceUrl, cleanLocation(line))
                    val displayName = metadata.substringAfterLast(',').trim()
                        .ifBlank { attribute(metadata, "tvg-name") ?: "Untitled" }
                    val group = attribute(metadata, "group-title")
                        .orEmpty()
                        .ifBlank { pendingGroup ?: "Other" }
                    val explicitId = attribute(metadata, "tvg-id").orEmpty()
                    val type = inferContentType(group, displayName, resolvedUrl,
                        attribute(metadata, "radio"), attribute(metadata, "tvg-type"))
                    items += StreamItem(
                        id = explicitId.ifBlank { stableId(resolvedUrl) },
                        name = displayName,
                        streamUrl = resolvedUrl,
                        logoUrl = artworkUrl(attribute(metadata, "tvg-logo"), sourceUrl),
                        epgChannelId = explicitId.takeIf(String::isNotBlank),
                        categoryName = group,
                        contentType = type,
                    )
                    pendingMetadata = null
                    pendingGroup = null
                }
                looksLikeStreamLocation(line) -> {
                    val resolvedUrl = resolveUrl(sourceUrl, cleanLocation(line))
                    val displayName = resolvedUrl.substringBefore('|')
                        .substringAfterLast('/')
                        .substringBefore('?')
                        .ifBlank { "Stream ${items.size + 1}" }
                    items += StreamItem(
                        id = stableId(resolvedUrl),
                        name = displayName,
                        streamUrl = resolvedUrl,
                        categoryName = pendingGroup ?: "Live TV",
                        contentType = inferContentType(pendingGroup.orEmpty(), displayName, resolvedUrl),
                    )
                    pendingGroup = null
                }
            }
        }
        return items.distinctBy { it.browseKey }
    }

    private fun singleHlsStream(sourceUrl: String): List<StreamItem> = listOf(
        StreamItem(
            id = stableId(sourceUrl),
            name = sourceUrl.substringAfterLast('/').substringBefore('?').ifBlank { "Live stream" },
            streamUrl = sourceUrl,
            categoryName = "Live TV",
            contentType = ContentType.LIVE,
        ),
    )

    private fun attribute(line: String, name: String): String? {
        val expression = Regex(
            "(?:^|\\s)${Regex.escape(name)}\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s,]+))",
            RegexOption.IGNORE_CASE,
        )
        val match = expression.find(line) ?: return null
        return match.groupValues.drop(1).firstOrNull(String::isNotBlank)?.trim()
    }

    private fun cleanLocation(value: String): String = value.trim().removeSurrounding("\"")

    private fun looksLikeStreamLocation(value: String): Boolean {
        val candidate = cleanLocation(value).substringBefore('|').lowercase()
        return candidate.startsWith("http://") ||
            candidate.startsWith("https://") ||
            Regex("\\.(m3u8?|ts|mp4|mkv|avi|mov|webm|mp3|aac|m4a|ogg|oga|opus|flac|wav)(\\?|$)").containsMatchIn(candidate)
    }

    private fun resolveUrl(sourceUrl: String?, value: String): String {
        if (sourceUrl.isNullOrBlank()) return value
        return runCatching { URI(sourceUrl).resolve(value).toString() }.getOrDefault(value)
    }

    private fun inferContentType(group: String, name: String, url: String,
        radioFlag: String? = null, declaredType: String? = null): ContentType {
        if (RadioClassifier.declaredRadio(radioFlag, declaredType) == true) return ContentType.RADIO
        if (RadioClassifier.isRadio(group, "", radioFlag = radioFlag)) return ContentType.RADIO
        val haystack = "$group $name $url".lowercase()
        return when {
            listOf("series", "episode", "season", "série", "serie", "tv show", "مسلسل", "مسلسلات").any(haystack::contains) -> ContentType.EPISODE
            listOf("movie", "vod", "film", "cinema", "película", "filme", "فيلم", "أفلام").any(haystack::contains) ||
                Regex("\\.(mp4|mkv|avi|mov|webm)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> ContentType.MOVIE
            RadioClassifier.isRadio(group, name, url, radioFlag, declaredType) -> ContentType.RADIO
            else -> ContentType.LIVE
        }
    }

    private fun stableId(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .take(10)
        .joinToString("") { "%02x".format(it) }

    private companion object {
        val HLS_MARKERS = listOf(
            "#EXT-X-TARGETDURATION",
            "#EXT-X-MEDIA-SEQUENCE",
            "#EXT-X-STREAM-INF",
        )
    }
}

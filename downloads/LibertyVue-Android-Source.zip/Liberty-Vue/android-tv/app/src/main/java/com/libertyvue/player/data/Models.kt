package com.libertyvue.player.data

import java.util.UUID

enum class PlaylistType {
    M3U,
    XTREAM,
}

enum class PlaylistOrigin {
    LOCAL,
    REMOTE,
}

enum class ContentType {
    LIVE,
    RADIO,
    MOVIE,
    SERIES,
    EPISODE,
}

val StreamItem.usesStationArtwork: Boolean
    get() = contentType == ContentType.LIVE || contentType == ContentType.RADIO

data class PlaylistConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: PlaylistType,
    val url: String,
    val username: String = "",
    val password: String = "",
    val origin: PlaylistOrigin = PlaylistOrigin.LOCAL,
    val epgUrl: String = "",
)

data class StreamItem(
    val id: String,
    val name: String,
    val streamUrl: String?,
    val logoUrl: String? = null,
    val categoryId: String? = null,
    val categoryName: String = "Other",
    val contentType: ContentType = ContentType.LIVE,
    val seriesId: Int? = null,
    val subtitle: String? = null,
    val epgChannelId: String? = null,
    val providerStreamId: String? = null,
)

data class LibraryPayload(
    val items: List<StreamItem>,
    val accountMessage: String? = null,
    val epgUrl: String? = null,
    val maxConnections: Int? = null,
    val accountExpiresAt: Long? = null,
    /** True when every section arrived at once (plain M3U parse). */
    val fullCatalog: Boolean = false,
)

data class EpgProgram(
    val title: String,
    val description: String = "",
    val startMillis: Long,
    val endMillis: Long,
) {
    fun isOnAir(now: Long): Boolean = now >= startMillis && now < endMillis
}

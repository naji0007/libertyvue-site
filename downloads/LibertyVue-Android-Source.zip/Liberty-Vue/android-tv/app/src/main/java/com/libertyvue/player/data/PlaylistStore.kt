package com.libertyvue.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PlaylistStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
    private val vault = CredentialVault()

    fun load(): List<PlaylistConfig> {
        val encrypted = preferences.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(vault.decrypt(encrypted))
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        PlaylistConfig(
                            id = item.getString("id"),
                            name = item.getString("name"),
                            type = PlaylistType.valueOf(item.getString("type")),
                            url = item.getString("url"),
                            username = item.optString("username"),
                            password = item.optString("password"),
                            epgUrl = item.optString("epgUrl"),
                            origin = runCatching {
                                PlaylistOrigin.valueOf(item.optString("origin", PlaylistOrigin.LOCAL.name))
                            }.getOrDefault(PlaylistOrigin.LOCAL),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(playlists: List<PlaylistConfig>) {
        val array = JSONArray()
        playlists.forEach { playlist ->
            array.put(
                JSONObject()
                    .put("id", playlist.id)
                    .put("name", playlist.name)
                    .put("type", playlist.type.name)
                    .put("url", playlist.url)
                    .put("username", playlist.username)
                    .put("password", playlist.password)
                    .put("epgUrl", playlist.epgUrl)
                    .put("origin", playlist.origin.name),
            )
        }
        if (!preferences.edit()
                .putString(KEY_PLAYLISTS, vault.encrypt(array.toString()))
                .commit()
        ) {
            throw AppError.PersistFailed
        }
    }

    companion object {
        private const val PREFERENCES = "libertyvue.secure.playlists"
        private const val KEY_PLAYLISTS = "playlists"
    }
}

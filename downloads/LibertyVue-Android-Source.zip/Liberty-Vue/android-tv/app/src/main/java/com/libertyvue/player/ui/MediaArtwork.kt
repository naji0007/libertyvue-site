package com.libertyvue.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.artworkCandidates
import com.libertyvue.player.data.usesStationArtwork

@Composable
internal fun MediaArtwork(item: StreamItem, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val urls = remember(item.logoUrl) { artworkCandidates(item.logoUrl) }
    var attempt by remember(item.logoUrl) { mutableIntStateOf(0) }
    val url = urls.getOrNull(attempt)
    var loaded by remember(item.logoUrl) { mutableStateOf(false) }
    val isLive = item.usesStationArtwork
    val request = remember(url, context) { ImageRequest.Builder(context).data(url).crossfade(120).build() }
    Box(modifier.background(Brush.linearGradient(listOf(LibertyPanelSoft, Color(0xFF0E141E)))),
        contentAlignment = Alignment.Center) {
        if (!loaded) {
            val initial = item.name.trim().firstOrNull()?.uppercase() ?: "?"
            if (isLive) Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(42.dp).background(LibertyGold, CircleShape), contentAlignment = Alignment.Center) {
                    Text(initial, color = LibertyNavy, fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
                Text(item.name, color = LibertyText, fontSize = 11.sp, lineHeight = 14.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center)
            } else Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(54.dp)
                    .background(LibertyPanelSoft, RoundedCornerShape(14.dp))
                    .border(BorderStroke(1.dp, LibertyGold.copy(alpha = .55f)), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center) {
                    Text(initial, color = LibertyGold, fontWeight = FontWeight.Black, fontSize = 24.sp)
                }
                Text(item.name, color = LibertyText, fontSize = 12.sp, lineHeight = 16.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 3,
                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }
        if (url != null) AsyncImage(model = request, contentDescription = null,
            contentScale = if (isLive) ContentScale.Fit else ContentScale.Crop,
            modifier = Modifier.fillMaxSize().padding(if (isLive) 6.dp else 0.dp),
            onSuccess = { loaded = true }, onError = {
                if (attempt + 1 < urls.size) attempt++ else loaded = false
            })
    }
}

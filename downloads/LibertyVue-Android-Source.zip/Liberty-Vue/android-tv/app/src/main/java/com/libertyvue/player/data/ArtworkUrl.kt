package com.libertyvue.player.data

import java.net.URI

fun artworkUrl(value: String?, baseUrl: String? = null): String? {
    var cleaned = value?.trim()?.replace("&amp;", "&")?.takeIf { it.isNotBlank() && it != "null" } ?: return null
    // Some providers publish protocol-relative logos ("//host/logo.png").
    if (cleaned.startsWith("//")) cleaned = "https:$cleaned"
    // Raw spaces are illegal in URIs and make providers' logos unparseable.
    cleaned = cleaned.replace(" ", "%20")
    return runCatching {
        val uri = if (baseUrl.isNullOrBlank()) URI(cleaned) else URI(baseUrl).resolve(cleaned)
        uri.takeIf { it.scheme?.lowercase() in setOf("http", "https") && !it.host.isNullOrBlank() }?.toString()
    }.getOrNull()
}

/** Returns the provider artwork plus a scheme fallback for servers with a bad TLS certificate. */
fun artworkCandidates(value: String?, baseUrl: String? = null): List<String> {
    val primary = artworkUrl(value, baseUrl) ?: return emptyList()
    val alternate = when {
        primary.startsWith("https://", ignoreCase = true) -> "http://${primary.substring(8)}"
        primary.startsWith("http://", ignoreCase = true) -> "https://${primary.substring(7)}"
        else -> null
    }
    return listOfNotNull(primary, alternate).distinct()
}

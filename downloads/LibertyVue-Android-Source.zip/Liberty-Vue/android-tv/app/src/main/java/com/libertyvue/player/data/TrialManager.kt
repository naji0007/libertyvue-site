package com.libertyvue.player.data

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

data class TrialState(
    val deviceId: String,
    val deviceKey: String,
    val daysRemaining: Int,
    val isActive: Boolean,
    val isLicensed: Boolean = false,
    val licenseType: String? = null,
    val licenseExpiresAt: Long? = null,
    val licenseDaysRemaining: Int? = null,
)

class TrialManager(private val context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    fun current(): TrialState {
        val now = System.currentTimeMillis()
        val startedAt = preferences.getLong(KEY_STARTED_AT, 0L).let { saved ->
            if (saved > 0L) saved else now.also {
                preferences.edit().putLong(KEY_STARTED_AT, it).apply()
            }
        }
        val remainingMs = TRIAL_DURATION_MS - (now - startedAt).coerceAtLeast(0L)
        val daysRemaining = if (remainingMs <= 0L) {
            0
        } else {
            ceil(remainingMs.toDouble() / TimeUnit.DAYS.toMillis(1)).toInt()
        }
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID,
        ).orEmpty().ifBlank { "libertyvue-device" }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(androidId.toByteArray())
            .joinToString("") { "%02X".format(it) }

        return TrialState(
            deviceId = "LV-${digest.take(10).chunked(5).joinToString("-")}",
            deviceKey = digest.drop(10).take(8).chunked(4).joinToString("-"),
            daysRemaining = daysRemaining,
            isActive = remainingMs > 0L,
        )
    }

    private companion object {
        const val PREFERENCES = "libertyvue.trial"
        const val KEY_STARTED_AT = "started_at"
        val TRIAL_DURATION_MS: Long = TimeUnit.DAYS.toMillis(7)
    }
}

package com.libertyvue.player.data

import java.net.URI

/** Provider metadata wins; category/name detection is only a fallback for live entries. */
object RadioClassifier {
    private val radioWords = Regex("(?:^|[^\\p{L}\\p{N}])(?:radios?|rádios?|راديو|إذاعة|اذاعة|إذاعات|اذاعات)(?:$|[^\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)
    private val audioExtension = Regex("\\.(mp3|aac|m4a|ogg|oga|opus|flac|wav)$", RegexOption.IGNORE_CASE)

    fun declaredRadio(radioFlag: String?, declaredType: String?): Boolean? = when {
        radioFlag?.trim().equals("true", true) || radioFlag?.trim() == "1" -> true
        radioFlag?.trim().equals("false", true) || radioFlag?.trim() == "0" -> false
        declaredType?.trim().equals("radio", true) || declaredType?.trim().equals("audio", true) -> true
        else -> null
    }

    fun isRadio(category: String, name: String, url: String = "", radioFlag: String? = null,
        declaredType: String? = null): Boolean {
        declaredRadio(radioFlag, declaredType)?.let { return it }
        // Never inspect credentials, query parameters or host names for radio keywords.
        val path = runCatching { URI(url.substringBefore('|')).path }.getOrNull().orEmpty()
        return radioWords.containsMatchIn(category) || radioWords.containsMatchIn(name) || audioExtension.containsMatchIn(path)
    }
}

package com.libertyvue.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class RemoteDeviceSnapshot(
    val revision: Int,
    val playlists: List<PlaylistConfig>,
    val license: RemoteLicenseSnapshot,
)

data class RemoteLicenseSnapshot(
    val status: String,
    val type: String?,
    val expiresAt: Long?,
    val daysRemaining: Int?,
)

class RemoteDeviceClient {
    suspend fun sync(deviceId: String, deviceKey: String): RemoteDeviceSnapshot =
        withContext(Dispatchers.IO) {
            val connection = (URL(SupabaseConfig.RPC_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                setRequestProperty("Authorization", "Bearer ${SupabaseConfig.PUBLISHABLE_KEY}")
                setRequestProperty("User-Agent", "LibertyVuePlayer/0.6 (Android TV)")
            }

            try {
                val requestBody = JSONObject()
                    .put("p_device_id", deviceId)
                    .put("p_device_key", deviceKey)
                    .toString()
                    .toByteArray(Charsets.UTF_8)
                connection.outputStream.use { it.write(requestBody) }

                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.let { input ->
                    BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                        val output = StringBuilder()
                        val buffer = CharArray(4_096)
                        while (true) {
                            val read = reader.read(buffer)
                            if (read < 0) break
                            if (output.length + read > MAX_RESPONSE_CHARACTERS) {
                                throw AppError.ResponseTooLarge
                            }
                            output.append(buffer, 0, read)
                        }
                        output.toString()
                    }
                }.orEmpty()

                if (status !in 200..299) {
                    throw AppError.HttpStatus(status)
                }

                val payload = JSONObject(response)
                if (payload.optString("error") == "forbidden") throw AppError.DeviceForbidden
                val licensePayload = payload.optJSONObject("license")
                RemoteDeviceSnapshot(
                    revision = payload.optInt("revision", 0),
                    playlists = parsePlaylists(payload.optJSONArray("playlists") ?: JSONArray()),
                    license = RemoteLicenseSnapshot(
                        status = licensePayload?.optString("status", "trial") ?: "trial",
                        type = licensePayload?.optString("type")?.takeUnless { it.isBlank() || it == "null" },
                        expiresAt = licensePayload?.let { if (it.isNull("expiresAt")) null else it.optLong("expiresAt") },
                        daysRemaining = licensePayload?.let { if (it.isNull("daysRemaining")) null else it.optInt("daysRemaining") },
                    ),
                )
            } finally {
                connection.disconnect()
            }
        }

    private fun parsePlaylists(array: JSONArray): List<PlaylistConfig> = buildList {
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val type = when (item.optString("type").uppercase()) {
                "M3U", "M3U8" -> PlaylistType.M3U
                "XTREAM", "XTREAM CODES" -> PlaylistType.XTREAM
                else -> continue
            }
            val url = item.optString("url")
            if (url.isBlank()) continue
            val origin = when (item.optString("origin").uppercase()) {
                "LOCAL" -> PlaylistOrigin.LOCAL
                else -> PlaylistOrigin.REMOTE
            }
            add(
                PlaylistConfig(
                    id = item.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                    name = item.optString("name").ifBlank { type.name },
                    type = type,
                    url = url,
                    username = item.optString("username"),
                    password = item.optString("password"),
                    origin = origin,
                    epgUrl = item.optString("epgUrl").ifBlank { item.optString("epg_url") },
                ),
            )
        }
    }

    private companion object {
        const val MAX_RESPONSE_CHARACTERS = 1_000_000
    }
}

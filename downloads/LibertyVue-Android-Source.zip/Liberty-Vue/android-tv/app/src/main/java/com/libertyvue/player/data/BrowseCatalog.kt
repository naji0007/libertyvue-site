package com.libertyvue.player.data

import java.util.Locale

enum class BrowseScope { ALL, FAVORITES, HISTORY }
enum class BrowseSort {
    PROVIDER, NAME_ASC, NAME_DESC;

    fun label(): String = when (this) {
        PROVIDER -> pickLanguage("Ordre de la liste", "Provider order", "ترتيب القائمة")
        NAME_ASC -> pickLanguage("Nom : A → Z", "Name: A → Z", "الاسم: أ ← ي")
        NAME_DESC -> pickLanguage("Nom : Z → A", "Name: Z → A", "الاسم: ي ← أ")
    }
}

// In-memory identity. BrowseStore encrypts this because stream URLs can contain credentials.
// Radio used to be in LIVE: keep those saved favorites and recent entries after upgrading.
val StreamItem.browseKey: String get() = "${if (contentType == ContentType.RADIO) "LIVE" else contentType.name}:$id:${streamUrl.orEmpty()}"

class BrowseCatalog(val items: List<StreamItem>) {
    val categories: Map<String, Int> = items.groupingBy { it.categoryName }.eachCount()
    val byKey: Map<String, StreamItem> = items.associateBy { it.browseKey }

    fun select(category: String?, query: String, scope: BrowseScope, sort: BrowseSort,
        favorites: Set<String>, history: List<String>): List<StreamItem> {
        val source = when (scope) {
            BrowseScope.ALL -> items
            BrowseScope.FAVORITES -> items.filter { it.browseKey in favorites }
            BrowseScope.HISTORY -> history.mapNotNull(byKey::get)
        }
        val words = query.trim().split(Regex("\\s+")).filter(String::isNotEmpty)
        val filtered = source.filter { item ->
            (category == null || item.categoryName == category) && words.all { item.name.contains(it, ignoreCase = true) }
        }
        return when (sort) {
            BrowseSort.PROVIDER -> filtered
            BrowseSort.NAME_ASC -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
            BrowseSort.NAME_DESC -> filtered.sortedByDescending { it.name.lowercase(Locale.ROOT) }
        }
    }
}

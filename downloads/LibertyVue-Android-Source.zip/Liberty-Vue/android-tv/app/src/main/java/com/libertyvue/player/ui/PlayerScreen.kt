package com.libertyvue.player.ui

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.widget.Toast
import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import coil3.compose.AsyncImage
import com.libertyvue.player.AppScreen
import com.libertyvue.player.AppUiState
import com.libertyvue.player.MainActivity
import com.libertyvue.player.data.*
import kotlinx.coroutines.delay
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal data class PlaybackRequest(val url: String, val headers: Map<String, String>)

@Composable
fun PlayerScreen(state: AppUiState, onSelect: (StreamItem) -> Unit,
    onGuide: (StreamItem) -> Unit, onFavorite: (StreamItem) -> Unit, onBack: () -> Unit) {
    val item = state.playingItem ?: return
    val live = item.contentType.supportsChannelNavigation
    val activity = LocalContext.current.playerActivity()
    val catalog = remember(state.catalogItems, item.contentType) {
        BrowseCatalog(channelItems(state.catalogItems, item.contentType))
    }
    // Freeze history order on entering the player: visiting a channel must not reshuffle zapping.
    val history = remember { state.browseMemory.history }
    val fromLibrary = state.playerReturnScreen == AppScreen.LIBRARY
    var category by remember { mutableStateOf(if (fromLibrary) state.category else null) }
    var scope by remember { mutableStateOf(if (fromLibrary) state.browseScope else BrowseScope.ALL) }
    var query by remember { mutableStateOf(if (fromLibrary) state.search else "") }
    val channels = remember(catalog, category, scope, query, state.browseSort, state.browseMemory.favorites) {
        catalog.select(category, query, scope, state.browseSort, state.browseMemory.favorites, history)
    }
    var browser by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(true) }
    var infoGeneration by remember { mutableIntStateOf(0) }
    var lastZap by remember { mutableLongStateOf(0L) }
    var player by remember { mutableStateOf<Player?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var playbackError by remember { mutableStateOf(false) }
    var audioTracks by remember { mutableStateOf<List<Tracks.Group>>(emptyList()) }
    var audioDialog by remember { mutableStateOf(false) }
    val fullFocus = remember { FocusRequester() }
    val selectedFocus = remember { FocusRequester() }
    val channelScroll = rememberLazyListState()
    val currentIndex = channels.indexOfFirst { it.browseKey == item.browseKey }
    val focusIndex = currentIndex.coerceAtLeast(0)

    fun revealInfo() { showInfo = true; infoGeneration++ }
    fun zap(direction: Int) {
        adjacentChannel(channels, item.browseKey, direction)?.let(onSelect)
        revealInfo()
    }
    fun togglePlayback() {
        player?.let {
            if (it.playerError != null) { it.prepare(); it.play() }
            else if (it.playWhenReady) it.pause() else it.play()
        }
        revealInfo()
    }
    // Hand the stream to an external app (VLC/MX) for codecs this device
    // cannot decode itself (MP2, AC3…).
    fun openExternally() {
        val act = activity
        val url = parsePlaybackRequest(item.streamUrl.orEmpty()).url.trim()
        if (act == null || url.isBlank()) return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "video/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { act.startActivity(intent) }.onFailure {
            Toast.makeText(
                act,
                pickLanguage(
                    "Aucune application pour lire ce flux. Installez VLC.",
                    "No app can play this stream. Please install VLC.",
                    "لا يوجد تطبيق لتشغيل هذا البث. ثبّت VLC.",
                ),
                Toast.LENGTH_LONG,
            ).show()
        }
        revealInfo()
    }

    BackHandler { if (browser) { browser = false; revealInfo() } else onBack() }
    LaunchedEffect(item.browseKey) {
        revealInfo()
        if (item.contentType == ContentType.LIVE) onGuide(item)
    }
    LaunchedEffect(infoGeneration, browser) {
        if (!browser) { delay(5_000); showInfo = false }
    }
    LaunchedEffect(browser, category, scope, item.browseKey) {
        if (live) {
            if (browser && channels.isNotEmpty()) {
                channelScroll.scrollToItem(focusIndex)
                withFrameNanos { }
                selectedFocus.requestFocus()
            } else if (!browser) fullFocus.requestFocus()
        }
    }
    DisposableEffect(player) {
        val active = player
        fun refreshAudioTracks() {
            audioTracks = active?.currentTracks?.groups
                ?.filter { group -> group.type == C.TRACK_TYPE_AUDIO }
                .orEmpty()
        }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(value: Boolean) { isPlaying = value }
            override fun onPlayerError(error: PlaybackException) { playbackError = true }
            override fun onPlaybackStateChanged(value: Int) {
                if (value == Player.STATE_BUFFERING || value == Player.STATE_READY) playbackError = false
            }
            override fun onTracksChanged(tracks: Tracks) { refreshAudioTracks() }
        }
        active?.addListener(listener)
        isPlaying = active?.isPlaying == true
        playbackError = active?.playerError != null
        refreshAudioTracks()
        onDispose { active?.removeListener(listener) }
    }
    val remoteHandler by rememberUpdatedState(newValue = { event: KeyEvent ->
        val code = event.keyCode
        val next = code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
            (!browser && code == KeyEvent.KEYCODE_DPAD_UP)
        val previous = code == KeyEvent.KEYCODE_CHANNEL_DOWN || code == KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
            (!browser && code == KeyEvent.KEYCODE_DPAD_DOWN)
        val open = !browser && code in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MENU)
        val info = !browser && code in listOf(KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO)
        val pause = code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY ||
            code == KeyEvent.KEYCODE_MEDIA_PAUSE
        val handled = live && (next || previous || open || info || pause)
        if (handled && event.action == KeyEvent.ACTION_DOWN) {
            when {
                next || previous -> {
                    val now = SystemClock.uptimeMillis()
                    if (event.repeatCount == 0 || now - lastZap >= 200) {
                        lastZap = now
                        zap(if (next) 1 else -1)
                    }
                }
                event.repeatCount == 0 -> when {
                    open -> browser = true
                    info -> revealInfo()
                    code == KeyEvent.KEYCODE_MEDIA_PLAY -> player?.play()
                    code == KeyEvent.KEYCODE_MEDIA_PAUSE -> player?.pause()
                    pause -> togglePlayback()
                }
            }
        }
        handled
    })
    DisposableEffect(activity, live) {
        val handler: (KeyEvent) -> Boolean = { remoteHandler(it) }
        if (live) activity?.playerKeyHandler = handler
        onDispose { if (activity?.playerKeyHandler === handler) activity?.playerKeyHandler = null }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(if (browser) LibertyNavy else Color.Black)) {
        val previewWidth = (maxWidth * 0.40f) - 20.dp
        val previewHeight = previewWidth * 9f / 16f
        // Keep this single VideoPane in the composition when opening/closing the channel browser.
        val videoModifier = if (browser) Modifier.align(Alignment.TopEnd).padding(top = 60.dp, end = 16.dp)
            .width(previewWidth).height(previewHeight)
        else Modifier.fillMaxSize()
        VideoPane(item, videoModifier, controls = !live, onPlayerChanged = { player = it })

        if (!live) {
            Surface(color = Color(0xBA07111F), modifier = Modifier.align(Alignment.TopStart)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, pickLanguage("Retour", "Back", "رجوع")) }
                    Text(item.name, maxLines = 1, fontSize = 16.sp)
                }
            }
        } else if (browser) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { browser = false; revealInfo() }) { Icon(Icons.Default.ArrowBack, pickLanguage("Plein écran", "Fullscreen", "ملء الشاشة")) }
                Text("LibertyVue", color = LibertyGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.width(18.dp))
                Text(if (item.contentType == ContentType.RADIO) "RADIO" else pickLanguage("TV EN DIRECT", "LIVE TV", "البث المباشر"), fontSize = 14.sp,
                    modifier = Modifier.weight(1f), color = LibertyMuted)
                TextButton(onClick = { browser = false; revealInfo() }) {
                    Icon(Icons.Default.Fullscreen, null); Spacer(Modifier.width(6.dp)); Text(pickLanguage("Plein écran", "Fullscreen", "ملء الشاشة"))
                }
            }
            Row(Modifier.fillMaxHeight().fillMaxWidth(0.60f).padding(top = 60.dp, bottom = 36.dp, start = 12.dp, end = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyColumn(Modifier.weight(0.42f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    item { Text(pickLanguage("CATÉGORIES", "CATEGORIES", "الفئات"), Modifier.padding(8.dp), color = LibertyMuted, fontSize = 11.sp) }
                    item {
                        ChannelMenuRow(pickLanguage("Toutes", "All", "الكل"), catalog.items.size.toString(), category == null && scope == BrowseScope.ALL,
                            onClick = { category = null; scope = BrowseScope.ALL; query = "" })
                    }
                    item {
                        ChannelMenuRow(pickLanguage("Favoris", "Favorites", "المفضلة"), null, scope == BrowseScope.FAVORITES,
                            onClick = { category = null; scope = BrowseScope.FAVORITES; query = "" })
                    }
                    item {
                        ChannelMenuRow(pickLanguage("Historique", "History", "السجل"), null, scope == BrowseScope.HISTORY,
                            onClick = { category = null; scope = BrowseScope.HISTORY; query = "" })
                    }
                    items(catalog.categories.entries.toList(), key = { it.key }) { entry ->
                        ChannelMenuRow(entry.key, entry.value.toString(), scope == BrowseScope.ALL && category == entry.key,
                            onClick = { category = entry.key; scope = BrowseScope.ALL; query = "" })
                    }
                }
                Column(Modifier.weight(0.58f).fillMaxHeight()) {
                    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text(pickLanguage("Rechercher", "Search", "بحث"), fontSize = 13.sp) },
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                    Text("${channels.size} ${if (item.contentType == ContentType.RADIO) pickLanguage("stations", "stations", "محطة") else pickLanguage("chaînes", "channels", "قناة")}",
                        Modifier.padding(vertical = 6.dp), fontSize = 11.sp, color = LibertyMuted)
                    if (channels.isEmpty()) Text(pickLanguage("Aucune chaîne dans cette liste", "No channel in this list", "لا توجد قنوات في هذه القائمة"), fontSize = 13.sp, color = LibertyMuted)
                    LazyColumn(Modifier.fillMaxSize(), state = channelScroll, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(channels.size, key = { channels[it].browseKey }) { index ->
                            val channel = channels[index]
                            val selected = channel.browseKey == item.browseKey
                            ChannelMenuRow(channel.name, if (selected) "▶" else "${index + 1}", selected,
                                modifier = if (index == focusIndex) Modifier.focusRequester(selectedFocus) else Modifier,
                                logoUrl = channel.logoUrl, onClick = {
                                    if (selected) {
                                        if (playbackError) togglePlayback()
                                        browser = false; revealInfo()
                                    } else onSelect(channel)
                                })
                        }
                    }
                }
            }
            Column(Modifier.align(Alignment.TopEnd).padding(top = 68.dp + previewHeight, end = 16.dp)
                .width(previewWidth)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.name, Modifier.weight(1f), fontSize = 16.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { onFavorite(item) }) {
                        Icon(if (item.browseKey in state.browseMemory.favorites) Icons.Default.Star else Icons.Default.StarBorder,
                            pickLanguage("Ajouter ou retirer des favoris", "Add or remove favorite", "إضافة أو إزالة من المفضلة"), tint = LibertyGold)
                    }
                }
                Text(item.categoryName, fontSize = 12.sp, color = LibertyGold)
                Spacer(Modifier.height(8.dp))
                PlayerGuide(state, item)
            }
            Text(pickLanguage("CH + / − : changer   •   OK sur la chaîne en cours : plein écran   •   Retour : fermer la liste", "CH + / - : change   •   OK on current channel: fullscreen   •   Back: close the list", "CH +/- : تغيير   •   OK على القناة الحالية: ملء الشاشة   •   رجوع: إغلاق القائمة"),
                Modifier.align(Alignment.BottomCenter).padding(10.dp), fontSize = 11.sp, color = LibertyMuted)
        } else {
            Box(Modifier.fillMaxSize().focusRequester(fullFocus).focusable().then(
                if (item.contentType == ContentType.LIVE && !playbackError)
                    Modifier.pointerInput(Unit) { detectTapGestures(onTap = { browser = true }) }
                else Modifier))
            if (showInfo || playbackError || item.contentType == ContentType.RADIO) Surface(color = Color(0xEA080D15), modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, pickLanguage("Retour", "Back", "رجوع")) }
                    if (!item.logoUrl.isNullOrBlank()) AsyncImage(item.logoUrl, null, Modifier.size(44.dp), contentScale = ContentScale.Fit)
                    Column(Modifier.weight(1f)) {
                        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
                            fontWeight = FontWeight.Bold, color = LibertyGoldSoft)
                        PlayerGuide(state, item, compact = true)
                        Text(pickLanguage("▲ / ▼ ou CH + / − : zapper   •   OK : liste des chaînes", "▲ / ▼ or CH + / - : zap   •   OK: channel list", "▲ / ▼ أو CH +/- : تنقل   •   OK: قائمة القنوات"), color = LibertyMuted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { zap(-1) }, enabled = channels.isNotEmpty()) { Icon(Icons.Default.SkipPrevious, pickLanguage("Chaîne précédente", "Previous channel", "القناة السابقة")) }
                    IconButton(onClick = ::togglePlayback) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, pickLanguage("Lecture / pause", "Play / pause", "تشغيل / إيقاف")) }
                    IconButton(onClick = { zap(1) }, enabled = channels.isNotEmpty()) { Icon(Icons.Default.SkipNext, pickLanguage("Chaîne suivante", "Next channel", "القناة التالية")) }
                    if (audioTracks.isNotEmpty()) IconButton(onClick = { audioDialog = true }) { Icon(Icons.Default.VolumeUp, pickLanguage("Piste audio", "Audio track", "المسار الصوتي")) }
                    IconButton(onClick = ::openExternally) { Icon(Icons.Default.OpenInNew, pickLanguage("Lecteur externe (VLC)", "External player (VLC)", "مشغل خارجي (VLC)")) }
                    IconButton(onClick = { browser = true }) { Icon(Icons.Default.List, pickLanguage("Liste des chaînes", "Channel list", "قائمة القنوات")) }
                }
            }
        }
        if (audioDialog) {
            val options: List<AudioOption> =
                audioTracks.mapIndexed { index, group ->
                    AudioOption(index, audioTrackLabel(group), group.isSelected, group.isSupported)
                }
            AudioTrackDialog(
                options = options,
                onChoose = { id ->
                    player?.let { p ->
                        val group = audioTracks.getOrNull(id) ?: return@let
                        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                            .setOverrideForType(
                                TrackSelectionOverride(
                                    group.mediaTrackGroup,
                                    (0 until group.length).toList(),
                                )
                            ).build()
                    }
                    audioDialog = false
                    revealInfo()
                },
                onDismiss = { audioDialog = false },
            )
        }
    }
}

internal data class AudioOption(val id: Int, val label: String, val selected: Boolean, val supported: Boolean = true)

@Composable
private fun AudioTrackDialog(options: List<AudioOption>, onChoose: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(pickLanguage("Piste audio", "Audio track", "المسار الصوتي")) },
        text = {
            LazyColumn {
                items(options, key = { it.id }) { option ->
                    AudioTrackRow(
                        label = option.label,
                        selected = option.selected,
                        supported = option.supported,
                        onClick = { onChoose(option.id) },
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(pickLanguage("Fermer", "Close", "إغلاق")) } })
}

@Composable
private fun AudioTrackRow(label: String, selected: Boolean, supported: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (selected) Icon(Icons.Default.Check, null, tint = LibertyGold, modifier = Modifier.size(18.dp))
            else Spacer(Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (selected) LibertyGoldSoft else LibertyText)
                if (!supported) Text(
                    pickLanguage("Non supporté par cet appareil", "Unsupported on this device", "غير مدعوم على هذا الجهاز"),
                    fontSize = 11.sp, color = LibertyDanger, maxLines = 1)
            }
        }
    }
}

private fun audioTrackLabel(group: Tracks.Group): String {
    val formats = (0 until group.length).map { group.getTrackFormat(it) }
    val language = formats.firstNotNullOfOrNull { it.language?.takeIf(String::isNotBlank) }
        ?.let { runCatching { Locale(it).getDisplayLanguage(Locale.getDefault()) }.getOrNull() }
    val codec = formats.firstNotNullOfOrNull { it.sampleMimeType?.substringAfter('/')?.uppercase() }
    val label = formats.firstNotNullOfOrNull { it.label?.takeIf(String::isNotBlank) }
    return listOfNotNull(label ?: language, codec).joinToString(" · ").ifBlank { "Audio" }
}

@Composable
private fun ChannelMenuRow(label: String, detail: String?, selected: Boolean,
    modifier: Modifier = Modifier, logoUrl: String? = null, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = modifier.fillMaxWidth().onFocusChanged { focused = it.hasFocus },
        color = if (selected) LibertySelected else LibertyPanel,
        shape = RoundedCornerShape(6.dp), border = BorderStroke(if (focused) 2.dp else 1.dp,
            if (focused) LibertyGold else if (selected) LibertyGoldDeep else LibertyBorder)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 10.dp).heightIn(min = 24.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            if (!logoUrl.isNullOrBlank()) AsyncImage(logoUrl, null, Modifier.size(28.dp), contentScale = ContentScale.Fit)
            Text(label, Modifier.weight(1f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                color = if (selected || focused) LibertyGoldSoft else LibertyText)
            detail?.let { Text(it, fontSize = 11.sp, color = LibertyMuted) }
        }
    }
}

@Composable
private fun PlayerGuide(state: AppUiState, item: StreamItem, compact: Boolean = false) {
    if (item.contentType == ContentType.RADIO) {
        Text(pickLanguage("Radio en direct", "Live radio", "راديو مباشر"), fontSize = 12.sp, color = LibertyMuted)
        return
    }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(30_000) } }
    val programs = if (state.guideChannel?.browseKey == item.browseKey) state.guidePrograms else emptyList()
    val current = programs.firstOrNull { it.isOnAir(now) }
    val next = programs.firstOrNull { it.startMillis > now }
    val time = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Text(current?.let { "${time.format(Date(it.startMillis))} – ${time.format(Date(it.endMillis))}  ${it.title}" }
        ?: if (state.guideLoading && state.guideChannel?.browseKey == item.browseKey) pickLanguage("Chargement du guide…", "Loading guide…", "جارٍ تحميل الدليل…")
        else pickLanguage("Aucune information EPG", "No EPG info", "لا توجد معلومات EPG"), maxLines = if (compact) 1 else 2, overflow = TextOverflow.Ellipsis,
        fontSize = 12.sp, color = LibertyText)
    if (!compact && next != null) Text("${pickLanguage("À suivre", "Up next", "التالي")} · ${time.format(Date(next.startMillis))}  ${next.title}",
        Modifier.padding(top = 6.dp), maxLines = 2, fontSize = 12.sp, color = LibertyMuted, overflow = TextOverflow.Ellipsis)
}

private tailrec fun Context.playerActivity(): MainActivity? = when (this) {
    is MainActivity -> this
    is ContextWrapper -> baseContext.playerActivity()
    else -> null
}

internal fun parsePlaybackRequest(value: String): PlaybackRequest {
    val parts = value.split('|', limit = 2)
    if (parts.size == 1) return PlaybackRequest(parts.first(), emptyMap())
    val headers = parts[1].split('&').mapNotNull { pair ->
        val separator = pair.indexOf('=')
        if (separator <= 0) return@mapNotNull null
        val key = decode(pair.substring(0, separator)).trim()
        val content = decode(pair.substring(separator + 1)).trim()
        if (key.isBlank() || content.isBlank() || key.contains('\n') || content.contains('\n') ||
            key.contains('\r') || content.contains('\r')) null else key to content
    }.toMap()
    return PlaybackRequest(parts.first(), headers)
}
private fun decode(value: String): String = runCatching {
    URLDecoder.decode(value, Charsets.UTF_8.name())
}.getOrDefault(value)

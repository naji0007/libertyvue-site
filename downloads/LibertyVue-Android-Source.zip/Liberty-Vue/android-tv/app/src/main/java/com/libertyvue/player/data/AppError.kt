package com.libertyvue.player.data

import java.util.Locale

/** Errors that can be shown to the user, localizable in French, English and Arabic. */
sealed class AppError(message: String) : Exception(message) {
    // Transport
    class HttpStatus(val status: Int) : AppError("Server returned HTTP $status")
    data object ResponseTooLarge : AppError("Response is too large")
    data object PlaylistTooLarge : AppError("Playlist is larger than the supported limit")

    // Invalid input
    class BadUrl(val label: UrlLabel) : AppError("Invalid URL")
    data object UsernameRequired : AppError("Username is required")
    data object PasswordRequired : AppError("Password is required")

    // Playlist content
    class WrongContent(val kind: WrongContentKind) : AppError("Invalid playlist content")
    data object SeriesRequiresXtream : AppError("Series need Xtream")
    data object NoEpisodes : AppError("No episodes")
    data object NoPlayableUrl : AppError("No playable URL")

    // Portal
    data object PortalNoAccount : AppError("Portal login failed")
    data object PortalBadCredentials : AppError("Portal rejected credentials")
    class PortalStatus(val status: String) : AppError("Portal status: $status")
    data object PortalBadList : AppError("Portal returned an invalid list")

    // Guide
    data object GuideLoad : AppError("Guide unavailable")
    data object EpgNoTvgId : AppError("No tvg-id to match programs")
    data object EpgNoSource : AppError("No XMLTV source")
    data object EpgNoStreamId : AppError("No EPG id for this channel")

    // Storage
    data object PersistFailed : AppError("Could not save")
    data object CorruptedStorage : AppError("Stored data is corrupted")

    // Operation fallbacks used by the ViewModel
    data object LoadPlaylist : AppError("Could not load")
    data object LoadTimeout : AppError("Load timed out")
    data object NoConnection : AppError("No connection")
    class EmptySection(val section: String) : AppError("Empty section")
    data object LoadEpisodes : AppError("Could not load episodes")
    data object SyncWebsite : AppError("Could not sync")
    data object DeviceForbidden : AppError("Device not recognized")
    data object RemovePlaylist : AppError("Could not remove")
    data object LicenseExpired : AppError("Licence expired")
    data object TrialEnded : AppError("Trial ended")

    enum class UrlLabel { M3U, SERVER, XMLTV }
    enum class WrongContentKind { WEB_PAGE, JSON, EMPTY }
}

/** In-app language override set from Settings ("system", "fr", "en" or "ar"). */
object AppLanguage {
    var override: String? = null
}

/** Picks the string matching the selected language (Arabic, English, French by default). */
fun pickLanguage(french: String, english: String, arabic: String): String {
    when (AppLanguage.override?.lowercase()) {
        "ar" -> return arabic
        "en" -> return english
        "fr" -> return french
    }
    return when (Locale.getDefault().language?.lowercase()) {
        "ar" -> arabic
        "en" -> english
        else -> french
    }
}

/** Thousands-grouped count for progress display (107 112). */
fun formatCount(value: Int): String = String.format(Locale.FRENCH, "%,d", value)

fun AppError.localized(): String = when (this) {
    is AppError.HttpStatus -> pickLanguage(
        "Le serveur a répondu HTTP $status",
        "Server returned HTTP $status",
        "الخادم رد بالخطأ HTTP $status",
    )
    AppError.ResponseTooLarge -> pickLanguage(
        "Réponse du service trop volumineuse",
        "Device response is too large",
        "استجابة الخدمة كبيرة جداً",
    )
    AppError.PlaylistTooLarge -> pickLanguage(
        "Liste trop volumineuse (limite dépassée)",
        "Playlist is larger than the supported limit",
        "القائمة أكبر من الحد المسموح",
    )
    is AppError.BadUrl -> when (label) {
        AppError.UrlLabel.M3U -> pickLanguage(
            "L’URL M3U doit commencer par http:// ou https://",
            "M3U URL must start with http:// or https://",
            "رابط M3U يجب أن يبدأ بـ http:// أو https://",
        )
        AppError.UrlLabel.SERVER -> pickLanguage(
            "L’URL du serveur doit commencer par http:// ou https://",
            "Server URL must start with http:// or https://",
            "رابط السيرفر يجب أن يبدأ بـ http:// أو https://",
        )
        AppError.UrlLabel.XMLTV -> pickLanguage(
            "L’URL XMLTV doit commencer par http:// ou https://",
            "XMLTV URL must start with http:// or https://",
            "رابط XMLTV يجب أن يبدأ بـ http:// أو https://",
        )
    }
    AppError.UsernameRequired -> pickLanguage(
        "Identifiant requis",
        "Username is required",
        "اسم المستخدم مطلوب",
    )
    AppError.PasswordRequired -> pickLanguage(
        "Mot de passe requis",
        "Password is required",
        "كلمة المرور مطلوبة",
    )
    is AppError.WrongContent -> {
        val what = when (kind) {
            AppError.WrongContentKind.WEB_PAGE -> Triple("une page web", "a web page", "صفحة ويب")
            AppError.WrongContentKind.JSON -> Triple("des données JSON", "JSON", "بيانات JSON")
            AppError.WrongContentKind.EMPTY -> Triple("aucune entrée lisible", "no playable M3U entries", "لا توجد عناصر قابلة للتشغيل")
        }
        pickLanguage(
            "Le lien a renvoyé ${what.first} au lieu d’une playlist M3U. Vérifiez l’URL complète et le statut du compte.",
            "The link returned ${what.second} instead of an M3U playlist. Check the complete M3U URL and account status.",
            "الرابط أعاد ${what.third} بدل قائمة M3U. تحقق من الرابط الكامل وحالة الحساب.",
        )
    }
    AppError.SeriesRequiresXtream -> pickLanguage(
        "Les dossiers de séries nécessitent un lien M3U compatible Xtream",
        "Series folders require an Xtream-compatible M3U link",
        "مجلدات المسلسلات تحتاج رابط M3U متوافق مع Xtream",
    )
    AppError.NoEpisodes -> pickLanguage(
        "Aucun épisode renvoyé pour cette série",
        "No episodes were returned for this series",
        "لا توجد حلقات لهذا المسلسل",
    )
    AppError.NoPlayableUrl -> pickLanguage(
        "Cet élément ne contient pas d’URL lisible",
        "This item does not include a playable stream URL",
        "هذا العنصر لا يحتوي على رابط قابل للتشغيل",
    )
    AppError.PortalNoAccount -> pickLanguage(
        "Le portail n’a pas renvoyé les informations du compte",
        "Portal login did not return account information",
        "البوابة لم ترجع معلومات الحساب",
    )
    AppError.PortalBadCredentials -> pickLanguage(
        "Le portail a rejeté l’identifiant ou le mot de passe",
        "Portal rejected the username or password",
        "البوابة رفضت اسم المستخدم أو كلمة المرور",
    )
    is AppError.PortalStatus -> pickLanguage(
        "Statut du compte : $status",
        "Portal account status is $status",
        "حالة الحساب: $status",
    )
    AppError.PortalBadList -> pickLanguage(
        "Le portail a renvoyé une liste invalide",
        "Portal returned an invalid stream list",
        "البوابة أعادت قائمة غير صالحة",
    )
    AppError.GuideLoad -> pickLanguage(
        "Guide EPG indisponible",
        "EPG guide unavailable",
        "دليل EPG غير متوفر",
    )
    AppError.EpgNoTvgId -> pickLanguage(
        "La liste M3U ne contient pas de tvg-id pour associer les programmes.",
        "The M3U list has no tvg-id to match programs.",
        "قائمة M3U لا تحتوي على tvg-id لربط البرامج.",
    )
    AppError.EpgNoSource -> pickLanguage(
        "Ajoutez l’URL XMLTV fournie par votre fournisseur avec le bouton Source EPG.",
        "Add the XMLTV URL from your provider with the EPG Source button.",
        "أضف رابط XMLTV من مزود الخدمة بزر مصدر EPG.",
    )
    AppError.EpgNoStreamId -> pickLanguage(
        "Identifiant EPG indisponible pour cette chaîne.",
        "EPG id unavailable for this channel.",
        "معرف EPG غير متوفر لهذه القناة.",
    )
    AppError.PersistFailed -> pickLanguage(
        "Impossible d’enregistrer sur cet appareil",
        "Could not save on this device",
        "تعذر الحفظ على هذا الجهاز",
    )
    AppError.CorruptedStorage -> pickLanguage(
        "Données enregistrées illisibles",
        "Saved data is unreadable",
        "البيانات المحفوظة غير مقروءة",
    )
    AppError.LoadPlaylist -> pickLanguage(
        "Impossible de charger cette liste",
        "Could not load this playlist",
        "تعذر تحميل هذه القائمة",
    )
    AppError.LoadTimeout -> pickLanguage(
        "La connexion met trop de temps à répondre. Vérifiez votre connexion et réessayez.",
        "The connection is taking too long to respond. Check your connection and retry.",
        "الاتصال يستغرق وقتاً طويلاً. تحقق من الاتصال وحاول مجدداً.",
    )
    AppError.NoConnection -> pickLanguage(
        "Serveur injoignable. Vérifiez votre connexion internet.",
        "Server unreachable. Check your internet connection.",
        "تعذر الوصول للسيرفر. تحقق من اتصال الإنترنت.",
    )
    is AppError.EmptySection -> pickLanguage(
        "Le fournisseur n’a renvoyé aucun contenu pour « $section ».",
        "The provider returned no content for “$section”.",
        "لم يرجع المزود أي محتوى لـ «$section».",
    )
    AppError.LoadEpisodes -> pickLanguage(
        "Impossible de charger les épisodes",
        "Could not load the episodes",
        "تعذر تحميل الحلقات",
    )
    AppError.SyncWebsite -> pickLanguage(
        "Impossible de se synchroniser avec le site LibertyVue",
        "Could not sync with the LibertyVue website",
        "تعذر المزامنة مع موقع LibertyVue",
    )
    AppError.DeviceForbidden -> pickLanguage(
        "Appareil non reconnu. Vérifiez l’ID et la clé.",
        "Device not recognized. Check the ID and key.",
        "الجهاز غير معروف. تحقق من المعرف والمفتاح.",
    )
    AppError.RemovePlaylist -> pickLanguage(
        "Impossible de supprimer cette connexion",
        "Could not remove this playlist",
        "تعذر حذف هذا الاتصال",
    )
    AppError.LicenseExpired -> pickLanguage(
        "Abonnement expiré. Veuillez renouveler pour continuer à regarder.",
        "Subscription expired. Please renew to continue watching.",
        "انتهى الاشتراك. يرجى التجديد للمتابعة.",
    )
    AppError.TrialEnded -> pickLanguage(
        "L’essai de 7 jours est terminé. Activez cet appareil pour continuer.",
        "The 7-day trial has ended. Activate this device to continue.",
        "انتهت الفترة التجريبية (7 أيام). فعّل هذا الجهاز للمتابعة.",
    )
}

fun infoConnectionSaved(): String = pickLanguage(
    "Connexion enregistrée. Choisissez-la ci-dessous pour l’ouvrir.",
    "Connection saved. Choose it below to open.",
    "تم حفظ الاتصال. اختره بالأسفل لفتحه.",
)

fun infoNoWebsiteYet(): String = pickLanguage(
    "Aucune connexion web pour le moment. Les connexions locales restent enregistrées.",
    "No website connection yet. Local connections stay saved.",
    "لا يوجد اتصال ويب بعد. الاتصالات المحلية تبقى محفوظة.",
)

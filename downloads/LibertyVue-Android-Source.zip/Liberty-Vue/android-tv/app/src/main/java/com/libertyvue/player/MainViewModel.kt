package com.libertyvue.player

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.libertyvue.player.data.AppError
import com.libertyvue.player.data.AppLanguage
import com.libertyvue.player.data.AppProtection
import com.libertyvue.player.data.CrashReporter
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.infoConnectionSaved
import com.libertyvue.player.data.infoNoWebsiteYet
import com.libertyvue.player.data.localized
import com.libertyvue.player.data.pickLanguage
import com.libertyvue.player.data.BrowseMemory
import com.libertyvue.player.data.BrowseScope
import com.libertyvue.player.data.BrowseSort
import com.libertyvue.player.data.BrowseStore
import com.libertyvue.player.data.browseKey
import com.libertyvue.player.data.supportsChannelNavigation
import com.libertyvue.player.data.EpgProgram
import com.libertyvue.player.data.EpgRepository
import com.libertyvue.player.data.PlaylistConfig
import com.libertyvue.player.data.PlaylistOrigin
import com.libertyvue.player.data.PlaylistRepository
import com.libertyvue.player.data.PlaylistStore
import com.libertyvue.player.data.PlaylistType
import com.libertyvue.player.data.RemoteDeviceClient
import com.libertyvue.player.data.SettingsStore
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.TrialManager
import com.libertyvue.player.data.TrialState
import com.libertyvue.player.data.XtreamClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

enum class AppScreen {
    HOME,
    ADD_PLAYLIST,
    PLAYLIST_TYPE,
    GUIDE,
    MULTI_SCREEN,
    SECTIONS,
    LIBRARY,
    EPISODES,
    PLAYER,
    SETTINGS,
}

enum class LibraryFilter {
    ALL, LIVE, RADIO, MOVIES, SERIES;

    fun title(): String = when (this) {
        ALL -> pickLanguage("Tous", "All", "الكل")
        LIVE -> pickLanguage("TV en direct", "Live TV", "البث المباشر")
        RADIO -> pickLanguage("Radio", "Radio", "الراديو")
        MOVIES -> pickLanguage("Films", "Movies", "الأفلام")
        SERIES -> pickLanguage("Séries", "Series", "المسلسلات")
    }
}

data class AppUiState(
    val screen: AppScreen = AppScreen.HOME,
    val playlists: List<PlaylistConfig> = emptyList(),
    val activePlaylist: PlaylistConfig? = null,
    val items: List<StreamItem> = emptyList(),
    val catalogItems: List<StreamItem> = emptyList(),
    val sectionTitle: String = "Library",
    val filter: LibraryFilter = LibraryFilter.ALL,
    val category: String? = null,
    val search: String = "",
    val browseMemory: BrowseMemory = BrowseMemory(),
    val browseScope: BrowseScope = BrowseScope.ALL,
    val browseSort: BrowseSort = BrowseSort.PROVIDER,
    val browseAsList: Boolean = false,
    val lastBrowsedKey: String? = null,
    val playingItem: StreamItem? = null,
    val playerReturnScreen: AppScreen = AppScreen.LIBRARY,
    val loading: Boolean = false,
    val syncing: Boolean = false,
    val error: String? = null,
    val syncMessage: String? = null,
    val accountMessage: String? = null,
    val newPlaylistType: PlaylistType = PlaylistType.M3U,
    val epgUrl: String? = null,
    val guideChannel: StreamItem? = null,
    val guidePrograms: List<EpgProgram> = emptyList(),
    val guideLoading: Boolean = false,
    val guideError: String? = null,
    val maxConnections: Int? = null,
    val accountExpiresAt: Long? = null,
    /** Content types already loaded (live/radio at entry, movies/series on demand). */
    val sectionsLoaded: Set<ContentType> = emptySet(),
    /** Sections currently loading in the background (movies, series…). */
    val sectionLoading: Set<LibraryFilter> = emptySet(),
    /** Items loaded so far by the ongoing load (progress numbers). */
    val loadingCount: Int = 0,
    val language: String = SettingsStore.LANGUAGE_SYSTEM,
    val crashReport: String? = null,
    /** Non-null when the installed build is rejected (repackaged clone). */
    val blockedMessage: String? = null,
    /** Dismissible warning shown on rooted devices. */
    val rootWarning: String? = null,
    val lastUpdated: Long? = null,
    val multiSize: Int = 2,
    val multiSlots: List<StreamItem?> = List(4) { null },
    val audioSlot: Int = 0,
    val trial: TrialState,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val store = PlaylistStore(application)
    private val browseStore = BrowseStore(application)
    private var seriesReturn: AppUiState? = null
    private val repository = PlaylistRepository()
    private val epgRepository = EpgRepository()
    private var guideJob: Job? = null
    private var loadJob: Job? = null
    private var watchdogJob: Job? = null
    private var loadGeneration = 0
    private val sectionJobs = mutableMapOf<LibraryFilter, Job>()
    private val remoteDeviceClient = RemoteDeviceClient()
    private val trialManager = TrialManager(application)
    private val settingsStore = SettingsStore(application)

    private val _uiState = MutableStateFlow(
        AppUiState(
            // Storage can be corrupted (reinstalls, full disk): never crash startup.
            playlists = runCatching { store.load() }.getOrDefault(emptyList()),
            trial = runCatching { trialManager.current() }
                .getOrElse { TrialState(deviceId = "LV-UNKNOWN", deviceKey = "UNKNOWN", daysRemaining = 0, isActive = false) },
            language = settingsStore.language().also { AppLanguage.override = it },
            crashReport = runCatching { CrashReporter.consume(application) }.getOrNull(),
            blockedMessage = runCatching {
                if (!AppProtection.isGenuine(application)) AppProtection.tamperMessage() else null
            }.getOrNull(),
            rootWarning = runCatching {
                if (AppProtection.isRooted()) AppProtection.rootWarning() else null
            }.getOrNull(),
        ),
    )
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    init {
        syncDevice(showResult = false)
        viewModelScope.launch {
            while (isActive) {
                delay(60_000)
                syncDevice(showResult = false)
            }
        }
    }

    fun showHome() = _uiState.update {
        it.copy(screen = AppScreen.HOME, error = null, playingItem = null)
    }

    fun showAddPlaylist() = _uiState.update {
        it.copy(screen = AppScreen.PLAYLIST_TYPE, error = null)
    }

    fun choosePlaylistType(type: PlaylistType) = _uiState.update {
        it.copy(screen = AppScreen.ADD_PLAYLIST, newPlaylistType = type, error = null)
    }

    fun showSettings() = _uiState.update {
        it.copy(screen = AppScreen.SETTINGS, error = null)
    }

    fun addM3u(name: String, url: String, epgUrl: String) {
        val config = PlaylistConfig(
            name = name.trim().ifBlank { pickLanguage("Ma liste", "My playlist", "قائمتي") },
            type = PlaylistType.M3U,
            url = url.trim(),
            epgUrl = epgUrl.trim(),
        )
        saveConnection(config)
    }

    fun addXtream(name: String, serverUrl: String, username: String, password: String) {
        val config = PlaylistConfig(
            name = name.trim().ifBlank { pickLanguage("Mon portail", "My portal", "بوابتي") },
            type = PlaylistType.XTREAM,
            url = serverUrl.trim(),
            username = username.trim(),
            password = password,
        )
        saveConnection(config)
    }

    private fun saveConnection(config: PlaylistConfig) {
        val validationError = validate(config)
        if (validationError != null) {
            _uiState.update { it.copy(error = validationError.localized()) }
            return
        }
        val updated = _uiState.value.playlists.filterNot { it.id == config.id } + config
        runCatching { store.save(updated) }
            .onFailure {
                _uiState.update { state ->
                    state.copy(error = AppError.PersistFailed.localized())
                }
                return
            }
        _uiState.update {
            it.copy(
                screen = AppScreen.HOME,
                playlists = updated,
                activePlaylist = null,
                items = emptyList(),
                catalogItems = emptyList(),
                syncMessage = infoConnectionSaved(),
                error = null,
            )
        }
    }

    private fun isLicenceExpired(trial: TrialState): Boolean {
        if (!trial.isLicensed) return false
        if (trial.licenseType == "lifetime") return false
        val now = System.currentTimeMillis()
        if (trial.licenseExpiresAt != null && trial.licenseExpiresAt < now) return true
        if (trial.licenseDaysRemaining != null && trial.licenseDaysRemaining <= 0) return true
        return false
    }

    fun openPlaylist(config: PlaylistConfig) = loadPlaylist(config, force = false)

    private fun loadPlaylist(config: PlaylistConfig, force: Boolean) {
        if (!_uiState.value.trial.isActive && !_uiState.value.trial.isLicensed) {
            _uiState.update { it.copy(error = AppError.TrialEnded.localized()) }
            return
        }
        if (isLicenceExpired(_uiState.value.trial)) {
            _uiState.update { it.copy(error = AppError.LicenseExpired.localized()) }
            return
        }
        if (!force && _uiState.value.activePlaylist == config && _uiState.value.catalogItems.isNotEmpty()) {
            showSections()
            return
        }
        loadJob?.cancel()
        guideJob?.cancel()
        watchdogJob?.cancel()
        sectionJobs.values.forEach { it.cancel() }
        sectionJobs.clear()
        seriesReturn = null
        _uiState.update {
            it.copy(
                screen = AppScreen.SECTIONS,
                activePlaylist = config,
                items = emptyList(),
                catalogItems = emptyList(),
                sectionTitle = config.name,
                filter = LibraryFilter.ALL,
                category = null,
                search = "",
                browseMemory = browseStore.load(config.id),
                browseScope = BrowseScope.ALL,
                lastBrowsedKey = null,
                loading = true,
                error = null,
                accountMessage = null,
                epgUrl = null,
                maxConnections = null,
                accountExpiresAt = null,
                sectionsLoaded = emptySet(),
                sectionLoading = emptySet(),
                loadingCount = 0,
                lastUpdated = null,
                guideChannel = null,
                guidePrograms = emptyList(),
                multiSlots = List(4) { null },
                playingItem = null,
            )
        }
        loadJob = viewModelScope.launch {
            val myself = coroutineContext[Job]
            // Entry load is live channels only (fast); movies and series
            // load on demand when their section opens. Huge providers keep
            // reporting live progress chunk by chunk.
            runCatching {
                repository.loadLive(config) { partial ->
                    if (loadJob != myself) return@loadLive
                    // Belt and braces: duplicate provider entries must never
                    // reach lazy lists (they crash on non-unique keys).
                    val clean = partial.items.distinctBy { it.browseKey }
                    _uiState.update {
                        it.copy(
                            items = clean,
                            catalogItems = clean,
                            loading = false,
                            accountMessage = partial.accountMessage,
                            epgUrl = partial.epgUrl,
                            maxConnections = partial.maxConnections,
                            accountExpiresAt = partial.accountExpiresAt,
                            loadingCount = partial.items.size,
                            sectionsLoaded = if (partial.fullCatalog) {
                                setOf(ContentType.LIVE, ContentType.RADIO, ContentType.MOVIE, ContentType.SERIES, ContentType.EPISODE)
                            } else {
                                setOf(ContentType.LIVE, ContentType.RADIO)
                            },
                            lastUpdated = System.currentTimeMillis(),
                        )
                    }
                }
            }
                .onSuccess { payload ->
                    val clean = payload.items.distinctBy { it.browseKey }
                    _uiState.update {
                        it.copy(
                            items = clean,
                            catalogItems = clean,
                            loading = false,
                            accountMessage = payload.accountMessage,
                            epgUrl = payload.epgUrl,
                            maxConnections = payload.maxConnections,
                            accountExpiresAt = payload.accountExpiresAt,
                            sectionsLoaded = if (payload.fullCatalog) {
                                setOf(ContentType.LIVE, ContentType.RADIO, ContentType.MOVIE, ContentType.SERIES, ContentType.EPISODE)
                            } else {
                                it.sectionsLoaded + setOf(ContentType.LIVE, ContentType.RADIO)
                            },
                            loadingCount = 0,
                            lastUpdated = System.currentTimeMillis(),
                        )
                    }
                    // Live is ready: automatically chain movies then series
                    // in the background (serialized inside ensureSection).
                    if (!payload.fullCatalog) {
                        ensureSection(LibraryFilter.MOVIES)
                        ensureSection(LibraryFilter.SERIES)
                    }
                }
                .onFailure { failure ->
                    if (failure is CancellationException) throw failure
                    _uiState.update {
                        it.copy(
                            loading = false,
                            loadingCount = 0,
                            error = failure.userMessage(AppError.LoadPlaylist),
                        )
                    }
                }
        }
        // Watchdog: a load must never hang forever. After the timeout the
        // stuck load is cancelled and the user gets a clear message.
        val generation = ++loadGeneration
        val currentLoad = loadJob
        watchdogJob = viewModelScope.launch {
            delay(LOAD_TIMEOUT_MS)
            if (generation == loadGeneration && currentLoad?.isActive == true && _uiState.value.loading) {
                currentLoad.cancel(CancellationException("Playlist load timed out"))
                _uiState.update { it.copy(loading = false, error = AppError.LoadTimeout.localized()) }
            }
        }
    }

    fun showSections() = _uiState.update { state ->
        if (state.activePlaylist == null) {
            state.copy(screen = AppScreen.HOME, error = null)
        } else {
            state.copy(
                screen = AppScreen.SECTIONS,
                items = state.catalogItems,
                sectionTitle = state.activePlaylist.name,
                filter = LibraryFilter.ALL,
                category = null,
                search = "",
                error = null,
            )
        }
    }

    fun openSection(filter: LibraryFilter) {
        if (filter == LibraryFilter.ALL) return
        _uiState.update { state ->
            val playlist = state.activePlaylist ?: return@update state.copy(screen = AppScreen.HOME)
            state.copy(
                screen = AppScreen.LIBRARY,
                items = state.catalogItems,
                sectionTitle = "${playlist.name} · ${filter.title()}",
                filter = filter,
                category = null,
                search = "",
                browseScope = BrowseScope.ALL,
                lastBrowsedKey = null,
                error = null,
            )
        }
        ensureSection(filter)
    }

    /** Loads movies/series on first open, with a small loading message.
        Sections load one after another (never in parallel): some portals
        hang when the same account opens several API calls at once. */
    private fun ensureSection(filter: LibraryFilter) {
        val needed = when (filter) {
            LibraryFilter.MOVIES -> ContentType.MOVIE
            LibraryFilter.SERIES -> ContentType.SERIES
            else -> return
        }
        val state = _uiState.value
        if (needed in state.sectionsLoaded) return
        val config = state.activePlaylist ?: return
        if (sectionJobs[filter]?.isActive == true) return
        _uiState.update { it.copy(sectionLoading = it.sectionLoading + filter, loadingCount = 0, error = null) }
        sectionJobs[filter] = viewModelScope.launch {
            // Wait for any other section to finish first.
            while (sectionJobs.entries.any { it.key != filter && it.value.isActive }) delay(250)
            val current = _uiState.value
            if (current.activePlaylist?.id != config.id || needed in current.sectionsLoaded) {
                sectionJobs.remove(filter)
                _uiState.update {
                    it.copy(sectionLoading = it.sectionLoading - filter)
                }
                return@launch
            }
            val section = if (filter == LibraryFilter.MOVIES) {
                XtreamClient.XtreamSection.MOVIES
            } else {
                XtreamClient.XtreamSection.SERIES
            }
            runCatching {
                withTimeout(SECTION_TIMEOUT_MS) {
                    repository.loadSection(config, section) { count ->
                        if (_uiState.value.activePlaylist?.id == config.id) {
                            _uiState.update { it.copy(loadingCount = count) }
                        }
                    }
                }
            }
                .onSuccess { items ->
                    sectionJobs.remove(filter)
                    _uiState.update { current ->
                        if (current.activePlaylist?.id != config.id) current
                        else current.copy(
                            items = (current.items + items).distinctBy { it.browseKey },
                            catalogItems = (current.catalogItems + items).distinctBy { it.browseKey },
                            sectionsLoaded = current.sectionsLoaded + needed,
                            sectionLoading = current.sectionLoading - filter,
                            loadingCount = 0,
                            error = if (items.isEmpty()) {
                                AppError.EmptySection(filter.title()).localized()
                            } else {
                                current.error
                            },
                        )
                    }
                }
                .onFailure { failure ->
                    if (failure is CancellationException && failure !is TimeoutCancellationException) throw failure
                    sectionJobs.remove(filter)
                    _uiState.update {
                        it.copy(
                            sectionLoading = it.sectionLoading - filter,
                            loadingCount = 0,
                            error = if (failure is TimeoutCancellationException) {
                                AppError.LoadTimeout.localized()
                            } else {
                                failure.userMessage(AppError.LoadPlaylist)
                            },
                        )
                    }
                }
        }
    }

    fun refresh() {
        val state = _uiState.value
        val destination = state.screen
        val selectedFilter = state.filter
        val config = state.activePlaylist ?: return
        val wantedExtras = state.sectionsLoaded - setOf(ContentType.LIVE, ContentType.RADIO)
        loadPlaylist(config, force = true)
        viewModelScope.launch {
            while (_uiState.value.loading) delay(50)
            val current = _uiState.value
            if (current.activePlaylist?.id != config.id || current.error != null) return@launch
            if (ContentType.MOVIE in wantedExtras) ensureSection(LibraryFilter.MOVIES)
            if (ContentType.SERIES in wantedExtras) ensureSection(LibraryFilter.SERIES)
            if (destination == AppScreen.LIBRARY && selectedFilter != LibraryFilter.ALL &&
                current.screen == AppScreen.SECTIONS
            ) {
                openSection(selectedFilter)
            }
        }
    }

    fun syncDevice(showResult: Boolean = true) {
        if (_uiState.value.syncing) return
        val trial = _uiState.value.trial
        _uiState.update {
            it.copy(
                syncing = true,
                error = if (showResult) null else it.error,
                syncMessage = if (showResult) pickLanguage("Synchronisation…", "Syncing…", "جارٍ المزامنة…") else it.syncMessage,
            )
        }
        viewModelScope.launch {
            runCatching { remoteDeviceClient.sync(trial.deviceId, trial.deviceKey) }
                .onSuccess { remote ->
                    val currentPlaylists = _uiState.value.playlists
                    val mergedPlaylists = mergePlaylists(
                        current = currentPlaylists,
                        remote = remote.playlists,
                        remoteRevision = remote.revision,
                    )
                    val saveFailure = runCatching { store.save(mergedPlaylists) }.exceptionOrNull()
                    if (saveFailure != null) {
                        _uiState.update {
                            it.copy(
                                syncing = false,
                                error = AppError.PersistFailed.localized(),
                            )
                        }
                        return@onSuccess
                    }
                    _uiState.update { state ->
                        val active = state.activePlaylist?.let { current ->
                            mergedPlaylists.firstOrNull { it.id == current.id }
                                ?: mergedPlaylists.firstOrNull { connectionKey(it) == connectionKey(current) }
                        }
                        val remoteLicense = remote.license
                        val licensed = remoteLicense.status == "active"
                        state.copy(
                            trial = state.trial.copy(
                                isLicensed = licensed,
                                licenseType = remoteLicense.type,
                                licenseExpiresAt = remoteLicense.expiresAt,
                                licenseDaysRemaining = remoteLicense.daysRemaining,
                            ),
                            playlists = mergedPlaylists,
                            activePlaylist = active,
                            syncing = false,
                            syncMessage = if (remote.revision == 0 && remote.playlists.isEmpty()) {
                                infoNoWebsiteYet()
                            } else {
                                "${pickLanguage("Enregistrées", "Saved", "تم الحفظ")} ${mergedPlaylists.size} ${pickLanguage("connexion(s) sur cet appareil.", "connection(s) on this device.", "اتصال على هذا الجهاز.")}"
                            },
                        )
                    }
                }
                .onFailure { failure ->
                    _uiState.update {
                        it.copy(
                            syncing = false,
                            error = if (showResult) {
                                failure.userMessage(AppError.SyncWebsite)
                            } else {
                                it.error
                            },
                            syncMessage = if (showResult) null else it.syncMessage,
                        )
                    }
                }
        }
    }

    fun setFilter(filter: LibraryFilter) = _uiState.update {
        it.copy(filter = filter, category = null)
    }

    fun setCategory(category: String?) = _uiState.update {
        it.copy(category = category, browseScope = BrowseScope.ALL, lastBrowsedKey = null)
    }

    fun setBrowseScope(scope: BrowseScope) = _uiState.update {
        it.copy(category = null, browseScope = scope, lastBrowsedKey = null)
    }

    fun setBrowseSort(sort: BrowseSort) = _uiState.update { it.copy(browseSort = sort) }
    fun toggleBrowseLayout() = _uiState.update { it.copy(browseAsList = !it.browseAsList) }

    fun toggleFavorite(item: StreamItem) = saveBrowseMemory(_uiState.value.browseMemory.toggled(item.browseKey))

    private fun rememberOpened(item: StreamItem) {
        saveBrowseMemory(_uiState.value.browseMemory.visited(item.browseKey))
        _uiState.update { it.copy(lastBrowsedKey = item.browseKey) }
    }

    private fun saveBrowseMemory(memory: BrowseMemory) {
        val id = _uiState.value.activePlaylist?.id ?: return
        runCatching { browseStore.save(id, memory) }.onSuccess {
            _uiState.update { it.copy(browseMemory = memory) }
        }.onFailure {
            _uiState.update { it.copy(error = pickLanguage("Impossible d’enregistrer les favoris et les éléments récents.", "Could not save favorites and recent items.", "تعذر حفظ المفضلة والعناصر الأخيرة.")) }
        }
    }

    fun setSearch(value: String) = _uiState.update {
        it.copy(search = value)
    }

    fun showGuide() {
        val state = _uiState.value
        val channel = state.guideChannel ?: state.catalogItems.firstOrNull { it.contentType == ContentType.LIVE }
        _uiState.update { it.copy(screen = AppScreen.GUIDE, search = "", error = null) }
        channel?.let(::selectGuideChannel)
    }

    fun selectGuideChannel(channel: StreamItem) {
        val state = _uiState.value
        val config = state.activePlaylist ?: return
        guideJob?.cancel()
        _uiState.update { it.copy(guideChannel = channel, guidePrograms = emptyList(), guideLoading = true, guideError = null) }
        guideJob = viewModelScope.launch {
            delay(200)
            try {
                val programs = epgRepository.load(config, repository.xtreamConfig(config), channel,
                    state.epgUrl, state.catalogItems.filter { it.contentType == ContentType.LIVE })
                _uiState.update { current ->
                    if (current.activePlaylist?.id != config.id || current.guideChannel != channel) current
                    else current.copy(guidePrograms = programs, guideLoading = false)
                }
            } catch (failure: Exception) {
                if (failure is CancellationException) throw failure
                _uiState.update { it.copy(guideLoading = false, guideError = failure.userMessage(AppError.GuideLoad)) }
            }
        }
    }

    fun refreshGuide() {
        viewModelScope.launch {
            epgRepository.invalidate()
            _uiState.value.guideChannel?.let(::selectGuideChannel)
        }
    }

    fun saveEpgSource(url: String) {
        val config = _uiState.value.activePlaylist ?: return
        val source = url.trim()
        if (source.isNotEmpty()) {
            runCatching { PlaylistRepository.validateHttpUrl(source, AppError.UrlLabel.XMLTV) }.onFailure { failure ->
                _uiState.update { state ->
                    state.copy(error = (failure as? AppError)?.localized()
                        ?: "L’URL XMLTV doit commencer par http:// ou https://")
                }
                return
            }
        }
        val updated = config.copy(epgUrl = source)
        val playlists = _uiState.value.playlists.map { if (it.id == config.id) updated else it }
        runCatching { store.save(playlists) }.onFailure {
            _uiState.update { state -> state.copy(error = pickLanguage("Impossible d’enregistrer la source EPG", "Could not save the EPG source", "تعذر حفظ مصدر EPG")) }
            return
        }
        _uiState.update { it.copy(activePlaylist = updated, playlists = playlists) }
        refreshGuide()
    }

    fun showMultiScreen() {
        val state = _uiState.value
        if (state.maxConnections == 1) {
            _uiState.update { it.copy(error = pickLanguage("Ce compte autorise une seule connexion. Le multi-écrans nécessite au moins deux connexions chez le fournisseur.", "This account allows a single connection. Multi-screen needs at least two connections from the provider.", "هذا الحساب يسمح باتصال واحد. الشاشات المتعددة تحتاج اتصالين على الأقل من المزود.")) }
            return
        }
        _uiState.update {
            val size = if (it.maxConnections != null && it.maxConnections < 4) 2 else it.multiSize
            it.copy(screen = AppScreen.MULTI_SCREEN, playingItem = null, error = null, multiSize = size,
                audioSlot = it.audioSlot.coerceAtMost(size - 1),
                multiSlots = it.multiSlots.mapIndexed { index, item -> if (index < size) item else null })
        }
    }

    fun setMultiSize(size: Int) {
        if (size !in listOf(2, 4)) return
        val max = _uiState.value.maxConnections
        if (max != null && size > max) {
            _uiState.update { it.copy(error = "${pickLanguage("Ce compte autorise", "This account allows", "هذا الحساب يسمح بـ")} $max ${pickLanguage("connexions simultanées.", "simultaneous connections.", "اتصالات متزامنة.")}") }
            return
        }
        _uiState.update { it.copy(multiSize = size, audioSlot = it.audioSlot.coerceAtMost(size - 1),
            multiSlots = it.multiSlots.mapIndexed { index, item -> if (index < size) item else null }) }
    }

    fun setMultiChannel(slot: Int, channel: StreamItem?) {
        if (slot !in 0 until _uiState.value.multiSize) return
        _uiState.update { state ->
            val slots = state.multiSlots.mapIndexed { index, item -> if (index == slot) channel else item }
            if (state.maxConnections != null && slots.count { it != null } > state.maxConnections) {
                state.copy(error = pickLanguage("Nombre de connexions autorisées atteint.", "Allowed connections limit reached.", "تم بلوغ حد الاتصالات المسموحة."))
            } else {
                val audio = if (slots[state.audioSlot] != null) state.audioSlot else slots.indexOfFirst { it != null }.coerceAtLeast(0)
                state.copy(multiSlots = slots, audioSlot = audio)
            }
        }
    }

    fun setAudioSlot(slot: Int) {
        if (slot in 0 until _uiState.value.multiSize) _uiState.update { it.copy(audioSlot = slot) }
    }

    fun openItem(item: StreamItem) {
        if (item.contentType == ContentType.SERIES) {
            rememberOpened(item)
            openSeries(item)
            return
        }
        if (item.streamUrl.isNullOrBlank()) {
            _uiState.update { it.copy(error = AppError.NoPlayableUrl.localized()) }
            return
        }
        rememberOpened(item)
        _uiState.update {
            it.copy(
                screen = AppScreen.PLAYER,
                playingItem = item,
                playerReturnScreen = if (it.screen == AppScreen.PLAYER) it.playerReturnScreen else it.screen,
                error = null,
            )
        }
    }

    fun switchChannel(item: StreamItem) {
        val state = _uiState.value
        val current = state.playingItem ?: return
        if (state.screen != AppScreen.PLAYER || !current.contentType.supportsChannelNavigation ||
            item.contentType != current.contentType || item.streamUrl.isNullOrBlank()) return
        if (state.catalogItems.none { it.id == item.id && it.contentType == item.contentType && it.streamUrl == item.streamUrl }) return
        rememberOpened(item)
        // Keep the original library/guide destination when zapping repeatedly.
        _uiState.update { it.copy(playingItem = item, error = null) }
    }

    private fun openSeries(series: StreamItem) {
        val config = _uiState.value.activePlaylist ?: return
        val seriesId = series.seriesId ?: return
        seriesReturn = _uiState.value
        _uiState.update {
            it.copy(
                screen = AppScreen.EPISODES,
                sectionTitle = series.name,
                items = emptyList(),
                category = null,
                search = "",
                browseScope = BrowseScope.ALL,
                lastBrowsedKey = null,
                filter = LibraryFilter.ALL,
                loading = true,
                error = null,
            )
        }
        viewModelScope.launch {
            runCatching { repository.loadEpisodes(config, seriesId) }
                .onSuccess { episodes ->
                    _uiState.update { it.copy(items = episodes, loading = false) }
                }
                .onFailure { failure ->
                    _uiState.update {
                        it.copy(
                            loading = false,
                            error = failure.userMessage(AppError.LoadEpisodes),
                        )
                    }
                }
        }
    }

    fun closePlayer() = _uiState.update {
        it.copy(screen = it.playerReturnScreen, playingItem = null, error = null)
    }

    fun backFromEpisodes() {
        _uiState.update { state ->
            val playlist = state.activePlaylist ?: return@update state.copy(screen = AppScreen.HOME)
            state.copy(
                screen = AppScreen.LIBRARY,
                items = state.catalogItems,
                sectionTitle = "${playlist.name} · ${LibraryFilter.SERIES.title()}",
                filter = LibraryFilter.SERIES,
                category = seriesReturn?.category,
                search = seriesReturn?.search.orEmpty(),
                browseScope = seriesReturn?.browseScope ?: BrowseScope.ALL,
                lastBrowsedKey = seriesReturn?.lastBrowsedKey,
                loading = false,
                error = null,
            )
        }
    }

    fun removePlaylist(config: PlaylistConfig) {
        val updated = _uiState.value.playlists.filterNot { it.id == config.id }
        runCatching { store.save(updated) }
            .onFailure {
                _uiState.update { state ->                 state.copy(error = AppError.RemovePlaylist.localized()) }
                return
            }
        browseStore.remove(config.id)
        _uiState.update {
            it.copy(
                playlists = updated,
                activePlaylist = it.activePlaylist?.takeUnless { active -> active.id == config.id },
                screen = AppScreen.SETTINGS,
                error = null,
            )
        }
    }

    fun clearError() = _uiState.update { it.copy(error = null) }

    fun clearCrashReport() = _uiState.update { it.copy(crashReport = null) }

    fun dismissRootWarning() = _uiState.update { it.copy(rootWarning = null) }

    fun setLanguage(language: String) {
        val normalized = language.lowercase().takeIf { it in SettingsStore.ALL } ?: SettingsStore.LANGUAGE_SYSTEM
        settingsStore.setLanguage(normalized)
        AppLanguage.override = normalized
        _uiState.update { it.copy(language = normalized) }
    }

    private fun mergePlaylists(
        current: List<PlaylistConfig>,
        remote: List<PlaylistConfig>,
        remoteRevision: Int,
    ): List<PlaylistConfig> {
        if (remoteRevision == 0 && remote.isEmpty()) return current

        val remoteKeys = remote.map(::connectionKey).toSet()
        val localOnly = current.filter { playlist ->
            playlist.origin == PlaylistOrigin.LOCAL && connectionKey(playlist) !in remoteKeys
        }
        val remoteWithEpg = remote.map { playlist ->
            val previous = current.firstOrNull { connectionKey(it) == connectionKey(playlist) }
            playlist.copy(epgUrl = previous?.epgUrl ?: playlist.epgUrl)
        }
        return (remoteWithEpg + localOnly).distinctBy(::connectionKey)
    }

    private fun connectionKey(config: PlaylistConfig): String = buildString {
        append(config.type.name)
        append('|')
        append(config.url.trim().trimEnd('/').lowercase())
        append('|')
        append(config.username.trim().lowercase())
    }

    private fun validate(config: PlaylistConfig): AppError? = try {
        PlaylistRepository.validateHttpUrl(
            config.url,
            if (config.type == PlaylistType.M3U) AppError.UrlLabel.M3U else AppError.UrlLabel.SERVER,
        )
        if (config.epgUrl.isNotBlank()) PlaylistRepository.validateHttpUrl(config.epgUrl, AppError.UrlLabel.XMLTV)
        if (config.type == PlaylistType.XTREAM) {
            if (config.username.isBlank()) throw AppError.UsernameRequired
            if (config.password.isBlank()) throw AppError.PasswordRequired
        }
        null
    } catch (error: AppError) {
        error
    }

    private fun Throwable.userMessage(fallback: AppError): String {
        if (this is AppError) return localized()
        // Android's HTTP stack reports timeouts as a bare "timeout".
        if (this is java.net.SocketTimeoutException) return AppError.LoadTimeout.localized()
        if (this is java.net.UnknownHostException || this is java.net.ConnectException) {
            return AppError.NoConnection.localized()
        }
        val safe = message.orEmpty()
            .replace(Regex("https?://\\S+", RegexOption.IGNORE_CASE), "the server")
            .take(180)
        return safe.ifBlank { fallback.localized() }
    }

    private companion object {
        const val LOAD_TIMEOUT_MS = 75_000L
        const val SECTION_TIMEOUT_MS = 120_000L
    }
}

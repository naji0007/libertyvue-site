package com.libertyvue.player.data

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Saves uncaught exceptions so the next launch can show what crashed. */
object CrashReporter {
    private const val PREFERENCES = "libertyvue.crash"
    private const val KEY_REPORT = "report"
    private const val MAX_LENGTH = 8_000

    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val stamp = SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRENCH).format(Date())
                val trace = Log.getStackTraceString(error).take(MAX_LENGTH)
                context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_REPORT, "$stamp\n${error::class.java.name}: ${error.message}\n$trace")
                    .commit()
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Reads and clears the saved report, if any. */
    fun consume(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        val report = prefs.getString(KEY_REPORT, null)
        if (report != null) {
            prefs.edit().remove(KEY_REPORT).apply()
        }
        return report
    }
}

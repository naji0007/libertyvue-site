package com.libertyvue.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.libertyvue.player.AppUiState
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.pickLanguage
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GuideScreen(state: AppUiState, onBack: () -> Unit, onSelect: (StreamItem) -> Unit,
    onPlay: (StreamItem) -> Unit, onRefresh: () -> Unit, onSaveSource: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var sourceDialog by remember { mutableStateOf(false) }
    val channels = remember(state.catalogItems) { state.catalogItems.filter { it.contentType == ContentType.LIVE } }
    val visible = remember(channels, query) { channels.filter { it.name.contains(query, true) || it.categoryName.contains(query, true) } }
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    // Quand on revient du lecteur, on replace la liste sur la chaîne regardée.
    LaunchedEffect(visible, state.guideChannel) {
        val channel = state.guideChannel ?: return@LaunchedEffect
        val index = visible.indexOfFirst { "${it.id}:${it.streamUrl}" == "${channel.id}:${channel.streamUrl}" }
        if (index < 0) return@LaunchedEffect
        withFrameNanos { }
        if (listState.layoutInfo.visibleItemsInfo.none { it.index == index }) listState.scrollToItem(index)
        withFrameNanos { }
        runCatching { focusRequester.requestFocus() }
    }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(30_000) } }
    val formatter = remember { SimpleDateFormat("EEE HH:mm", Locale.FRENCH) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val narrow = maxWidth < 640.dp
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp)) {
        TvTopBar(pickLanguage("Live avec EPG", "Live with guide", "مباشر مع الدليل"), onBack) {
            OutlinedButton(onClick = { sourceDialog = true }) { Text(pickLanguage("Source EPG", "EPG source", "مصدر EPG")) }
            OutlinedButton(onClick = onRefresh, enabled = !state.guideLoading) { Icon(Icons.Default.Refresh, pickLanguage("Actualiser", "Refresh", "تحديث")) }
        }
            Spacer(Modifier.height(10.dp))
            if (narrow) {
                // Téléphone : recherche, chaînes, aperçu puis programmes, empilés.
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                    label = { Text(pickLanguage("Chaîne ou groupe", "Channel or group", "قناة أو مجموعة")) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                GuideChannelList(visible, listState, focusRequester, state.guideChannel, onSelect,
                    Modifier.fillMaxWidth().height(264.dp))
                Spacer(Modifier.height(10.dp))
                GuideDetailPane(state, now, formatter, onPlay, Modifier.fillMaxWidth().weight(1f))
            } else {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                            label = { Text(pickLanguage("Chaîne ou groupe", "Channel or group", "قناة أو مجموعة")) }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        GuideChannelList(visible, listState, focusRequester, state.guideChannel, onSelect,
                            Modifier.weight(1f))
                    }
                    GuideDetailPane(state, now, formatter, onPlay, Modifier.weight(2.1f))
                }
            }
        }
    }
    if (sourceDialog) {
        var url by remember { mutableStateOf(state.activePlaylist?.epgUrl.orEmpty()) }
        AlertDialog(onDismissRequest = { sourceDialog = false }, title = { Text(pickLanguage("Source EPG / XMLTV", "EPG / XMLTV source", "مصدر EPG / XMLTV")) },
            text = { Column {
                Text(pickLanguage("Laissez vide pour la source automatique de votre connexion.", "Leave empty for your connection's automatic source.", "اتركه فارغاً للمصدر التلقائي لاتصالك."), color = LibertyMuted)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(url, { url = it }, label = { Text(pickLanguage("URL XMLTV ou XMLTV.gz", "XMLTV or XMLTV.gz URL", "رابط XMLTV أو XMLTV.gz")) }, singleLine = true)
            } }, confirmButton = { TextButton(onClick = { onSaveSource(url); sourceDialog = false }) { Text(pickLanguage("Enregistrer", "Save", "حفظ")) } },
            dismissButton = { TextButton(onClick = { sourceDialog = false }) { Text(pickLanguage("Annuler", "Cancel", "إلغاء")) } })
    }
}

@Composable
private fun GuideChannelList(visible: List<StreamItem>, listState: LazyListState,
    focusRequester: FocusRequester, selected: StreamItem?, onSelect: (StreamItem) -> Unit,
    modifier: Modifier = Modifier) {
    LazyColumn(state = listState, modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(visible, key = { "${it.id}:${it.streamUrl}" }) { channel ->
            val isSelected = channel == selected
            Surface(onClick = { onSelect(channel) },
                modifier = Modifier.fillMaxWidth()
                    .then(if (isSelected) Modifier.focusRequester(focusRequester) else Modifier),
                color = if (isSelected) LibertyPanelSoft else LibertyPanel,
                border = BorderStroke(1.dp, if (isSelected) LibertyGold else LibertyPanelSoft),
                shape = RoundedCornerShape(10.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text(channel.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(channel.categoryName, fontSize = 12.sp, color = LibertyMuted, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun GuideDetailPane(state: AppUiState, now: Long, formatter: SimpleDateFormat,
    onPlay: (StreamItem) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val channel = state.guideChannel
                if (channel == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(pickLanguage("Aucune chaîne en direct dans cette liste.", "No live channel in this list.", "لا توجد قنوات مباشرة في هذه القائمة.")) }
        } else {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(Modifier.weight(1.25f).fillMaxHeight(), color = LibertyPanel, shape = RoundedCornerShape(12.dp)) {
                    VideoPane(channel, Modifier.fillMaxSize(), compact = true)
                }
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                    Text(channel.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(state.guidePrograms.firstOrNull { it.isOnAir(now) }?.title ?: pickLanguage("TV en direct", "Live TV", "بث مباشر"),
                        color = LibertyMuted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Button(onClick = { onPlay(channel) }) { Icon(Icons.Default.Fullscreen, null); Text(pickLanguage("Regarder", "Watch", "مشاهدة")) }
                }
            }
            Surface(Modifier.weight(1.25f).fillMaxWidth(), color = LibertyPanel, shape = RoundedCornerShape(12.dp)) {
                when {
                    state.guideLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(28.dp)) }
                    state.guideError != null -> Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(state.guideError, color = LibertyMuted, fontSize = 14.sp)
                    }
                            state.guidePrograms.isEmpty() -> Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                                Text(pickLanguage("Aucun programme fourni pour cette chaîne. Le direct reste disponible.", "No guide data for this channel. Live is still available.", "لا توجد بيانات دليل لهذه القناة. البث المباشر متوفر."), color = LibertyMuted, fontSize = 14.sp)
                            }
                    else -> LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.guidePrograms, key = { "${it.startMillis}:${it.title}" }) { program ->
                            Column(Modifier.fillMaxWidth().padding(6.dp)) {
                                        Text((if (program.isOnAir(now)) pickLanguage("EN COURS · ", "NOW · ", "الآن · ") else "") +
                                    "${formatter.format(Date(program.startMillis))} – ${SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(program.endMillis))}",
                                    color = LibertyGold, fontSize = 12.sp)
                                Text(program.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                if (program.description.isNotBlank()) Text(program.description, color = LibertyMuted,
                                    fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

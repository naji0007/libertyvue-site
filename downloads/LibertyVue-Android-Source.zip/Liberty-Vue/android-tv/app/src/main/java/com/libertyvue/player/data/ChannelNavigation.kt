package com.libertyvue.player.data

val ContentType.supportsChannelNavigation: Boolean
    get() = this == ContentType.LIVE || this == ContentType.RADIO

/** Keep TV and radio separate, preserve provider order, and ignore entries without a stream. */
fun channelItems(items: List<StreamItem>, type: ContentType): List<StreamItem> =
    if (!type.supportsChannelNavigation) emptyList()
    else items.filter { it.contentType == type && !it.streamUrl.isNullOrBlank() }.distinctBy { it.browseKey }

/** The visible, sorted category/favorites list is also the zapping order. */
fun adjacentChannel(items: List<StreamItem>, currentKey: String, direction: Int): StreamItem? {
    if (items.isEmpty()) return null
    val index = items.indexOfFirst { it.browseKey == currentKey }
    if (index < 0) return if (direction < 0) items.last() else items.first()
    val step = if (direction < 0) -1 else 1
    return items[(index + step + items.size) % items.size]
}

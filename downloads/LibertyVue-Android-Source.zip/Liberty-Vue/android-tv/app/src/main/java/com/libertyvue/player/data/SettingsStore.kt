package com.libertyvue.player.data

import android.content.Context

/** Tiny settings store (app language). */
class SettingsStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    fun language(): String = preferences.getString(KEY_LANGUAGE, LANGUAGE_SYSTEM) ?: LANGUAGE_SYSTEM

    fun setLanguage(language: String) {
        preferences.edit().putString(KEY_LANGUAGE, language).apply()
    }

    companion object {
        const val LANGUAGE_SYSTEM = "system"
        const val LANGUAGE_FRENCH = "fr"
        const val LANGUAGE_ENGLISH = "en"
        const val LANGUAGE_ARABIC = "ar"
        val ALL = listOf(LANGUAGE_SYSTEM, LANGUAGE_FRENCH, LANGUAGE_ENGLISH, LANGUAGE_ARABIC)
        private const val PREFERENCES = "libertyvue.settings"
        private const val KEY_LANGUAGE = "language"
    }
}

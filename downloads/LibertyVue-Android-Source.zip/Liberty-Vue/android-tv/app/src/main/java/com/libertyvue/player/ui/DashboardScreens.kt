package com.libertyvue.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.libertyvue.player.AppUiState
import com.libertyvue.player.LibraryFilter
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.PlaylistConfig
import com.libertyvue.player.data.PlaylistType
import com.libertyvue.player.data.pickLanguage
import com.libertyvue.player.data.formatCount
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val GoldTileColors = listOf(LibertyGoldSoft, LibertyGold, LibertyGoldDeep)
private val NavyTileColors = listOf(LibertyPanelSoft, LibertyPanel)

internal fun licenseExpiryDate(expiresAt: Long?): String? {
    val timestamp = expiresAt?.takeIf { it > 0L } ?: return null
    // The device API uses milliseconds; accepting seconds keeps older licences readable.
    val millis = if (timestamp < 100_000_000_000L) timestamp * 1_000L else timestamp
    return SimpleDateFormat("dd/MM/yyyy", Locale.FRENCH).format(Date(millis))
}

@Composable
internal fun TvBrand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Surface(color = LibertyGold, shape = RoundedCornerShape(10.dp)) {
            Text("LV", Modifier.padding(9.dp), color = LibertyNavy, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Column {
            Text("LibertyVue", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("PLAYER", color = LibertyGold, fontSize = 11.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
internal fun TvHeroBrand(compact: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(color = LibertyGold, shape = RoundedCornerShape(if (compact) 14.dp else 18.dp)) {
            Text("LV", Modifier.padding(horizontal = if (compact) 16.dp else 22.dp, vertical = if (compact) 9.dp else 14.dp),
                color = LibertyNavy, fontWeight = FontWeight.Black, fontSize = if (compact) 28.sp else 40.sp)
        }
        Spacer(Modifier.height(if (compact) 6.dp else 10.dp))
        Text("LibertyVue", fontWeight = FontWeight.Bold, fontSize = if (compact) 28.sp else 38.sp)
        Text("PLAYER", color = LibertyGold, fontSize = if (compact) 12.sp else 15.sp, letterSpacing = 6.sp)
    }
}

@Composable
internal fun TvTopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onBack, contentPadding = PaddingValues(10.dp)) {
            Icon(Icons.Default.ArrowBack, pickLanguage("Retour", "Back", "رجوع"), Modifier.size(20.dp))
        }
        Text(title, Modifier.weight(1f), fontSize = 23.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
internal fun TvTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    colors: List<Color> = NavyTileColors,
    large: Boolean = false,
    enabled: Boolean = true,
    highlighted: Boolean = false,
) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val foreground = if (highlighted) LibertyGoldInk else LibertyText
    val iconColor = if (highlighted) LibertyGoldInk else LibertyGold
    Surface(onClick = onClick, enabled = enabled, interactionSource = interaction,
        color = Color.Transparent, contentColor = foreground,
        border = BorderStroke(if (focused) 3.dp else 1.dp, if (focused) LibertyGoldSoft else LibertyGold.copy(alpha = .28f)),
        shape = RoundedCornerShape(16.dp), modifier = modifier) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Brush.linearGradient(colors))) {
            val shortTile = maxHeight < 180.dp
            if (maxHeight < 110.dp) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(icon, null, Modifier.size(26.dp), tint = iconColor)
                    Column(Modifier.weight(1f)) {
                        Text(title, fontSize = 15.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(subtitle, color = foreground.copy(alpha = .8f), fontSize = 12.sp, lineHeight = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else {
            Column(Modifier.fillMaxSize().padding(if (shortTile) 12.dp else if (large) 20.dp else 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Icon(icon, null, Modifier.size(if (shortTile) 32.dp else if (large) 54.dp else 40.dp), tint = iconColor)
                Spacer(Modifier.height(if (large && !shortTile) 12.dp else 6.dp))
                Text(title, fontSize = if (shortTile) 20.sp else if (large) 24.sp else 22.sp,
                    lineHeight = if (shortTile) 24.sp else 28.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(subtitle, color = foreground.copy(alpha = .8f), fontSize = 13.sp, lineHeight = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            }
        }
    }
}

@Composable
fun TvHomeScreen(state: AppUiState, onAdd: () -> Unit, onSync: () -> Unit,
    onOpen: (PlaylistConfig) -> Unit, onSettings: () -> Unit, onManage: () -> Unit) {
    val connections = state.playlists
    val licenseText = when {
        state.trial.isLicensed && state.trial.licenseType == "lifetime" -> pickLanguage("Lifetime actif", "Lifetime active", "مدى الحياة مفعّل")
        state.trial.isLicensed -> "${pickLanguage("Licence annuelle", "Annual license", "ترخيص سنوي")}${licenseExpiryDate(state.trial.licenseExpiresAt)?.let { " · ${pickLanguage("jusqu’au", "until", "حتى")} $it" }.orEmpty()} · ${state.trial.licenseDaysRemaining ?: 0} ${pickLanguage("j", "d", "يوم")}"
        state.trial.isActive -> "${pickLanguage("Essai", "Trial", "تجربة")} · ${state.trial.daysRemaining} ${pickLanguage("j", "d", "يوم")}"
        else -> pickLanguage("Essai terminé", "Trial ended", "انتهت التجربة")
    }
    val firstTileFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstTileFocus.requestFocus() } }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Sur téléphone (écran étroit ou bas), on empile et on fait défiler ;
        // sur TV on garde la présentation large.
        val sideBySide = maxWidth >= 640.dp
        val compact = maxHeight < 520.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).heightIn(min = maxHeight)
                .padding(horizontal = if (sideBySide) 22.dp else 14.dp, vertical = 14.dp)
        ) {
        // Barre du haut : statut + actions sur le côté.
        if (sideBySide) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(licenseText, color = LibertyGold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                HomeActions(state, onSync, onManage, onAdd, onSettings)
            }
        } else {
            Text(licenseText, color = LibertyGold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HomeActions(state, onSync, onManage, onAdd, onSettings)
            }
        }
        Spacer(Modifier.height(if (compact) 8.dp else 10.dp))
        // Grand logo centré.
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { TvHeroBrand(compact) }
        Spacer(Modifier.height(if (compact) 10.dp else 14.dp))
        // Les connexions enregistrées, affichées au milieu. Écran vide
        // avec un grand bouton d'ajout quand il n'y en a aucune.
        // Hauteur fixe sur TV, libre sur téléphone (plusieurs connexions).
        val connectionsModifier = if (connections.isEmpty() || sideBySide) {
            Modifier.height(if (connections.isEmpty()) 180.dp else 132.dp)
        } else {
            Modifier.heightIn(min = 132.dp)
        }
        Box(Modifier.fillMaxWidth().then(connectionsModifier), contentAlignment = Alignment.Center) {
            if (connections.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = onAdd, modifier = Modifier.height(64.dp).focusRequester(firstTileFocus)) {
                        Icon(Icons.Default.Add, null, Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(pickLanguage("Ajouter une connexion", "Add a connection", "إضافة اتصال"), fontSize = 17.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("M3U / M3U8 ou Xtream Codes", color = LibertyMuted, fontSize = 14.sp)
                }
            } else if (sideBySide) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)) {
                    items(connections, key = { it.id }) { config ->
                        TvTile(config.name, if (config.type == PlaylistType.M3U) "M3U / M3U8" else "Xtream Codes",
                            Icons.Default.AccountCircle, { onOpen(config) },
                            (if (config.id == connections.firstOrNull()?.id) Modifier.focusRequester(firstTileFocus) else Modifier)
                                .width(280.dp).height(122.dp))
                    }
                }
            } else {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    connections.forEach { config ->
                        TvTile(config.name, if (config.type == PlaylistType.M3U) "M3U / M3U8" else "Xtream Codes",
                            Icons.Default.AccountCircle, { onOpen(config) },
                            Modifier.fillMaxWidth().height(92.dp))
                    }
                }
            }
        }
            Spacer(Modifier.height(6.dp))
            Text("ID ${state.trial.deviceId}   ·   ${pickLanguage("Clé", "Key", "المفتاح")} ${state.trial.deviceKey}${licenseExpiryDate(state.accountExpiresAt)?.let { "   ·   ${pickLanguage("Expire le", "Expires", "تنتهي في")} $it" }.orEmpty()}",
                color = LibertyMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HomeActions(state: AppUiState, onSync: () -> Unit, onManage: () -> Unit,
    onAdd: () -> Unit, onSettings: () -> Unit) {
    OutlinedButton(onClick = onSync, enabled = !state.syncing) {
        Icon(Icons.Default.Refresh, null, Modifier.size(18.dp)); Spacer(Modifier.width(5.dp))
        Text(if (state.syncing) pickLanguage("Synchro…", "Syncing…", "جارٍ المزامنة…") else "Sync")
    }
    OutlinedButton(onClick = onManage) { Text(pickLanguage("Site web", "Website", "الموقع")) }
    Button(onClick = onAdd) { Icon(Icons.Default.Add, null, Modifier.size(18.dp)) }
    OutlinedButton(onClick = onSettings) { Icon(Icons.Default.Settings, pickLanguage("Réglages", "Settings", "الإعدادات"), Modifier.size(20.dp)) }
}

@Composable
fun PlaylistTypeScreen(onBack: () -> Unit, onChoose: (PlaylistType) -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(LibertyPanel, LibertyNavy)))
        .padding(24.dp)) {
        TvTopBar(pickLanguage("Choisir le type de connexion", "Choose connection type", "اختر نوع الاتصال"), onBack)
        Spacer(Modifier.height(20.dp))
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            TvTile("M3U / M3U8", pickLanguage("Lien de votre playlist", "Your playlist link", "رابط قائمتك"), Icons.Default.PlaylistPlay,
                { onChoose(PlaylistType.M3U) }, Modifier.weight(1f).fillMaxHeight(), large = true)
            TvTile("XTREAM CODES", pickLanguage("Serveur, identifiant et mot de passe", "Server, username and password", "السيرفر والمعرف وكلمة المرور"), Icons.Default.Dns,
                { onChoose(PlaylistType.XTREAM) }, Modifier.weight(1f).fillMaxHeight(), large = true)
        }
        Spacer(Modifier.height(14.dp))
        Text(pickLanguage("Les connexions sont enregistrées et chiffrées sur cet appareil.", "Connections are stored encrypted on this device.", "الاتصالات محفوظة ومشفرة على هذا الجهاز."), color = LibertyMuted, fontSize = 14.sp)
    }
}

@Composable
fun TvDashboardScreen(state: AppUiState, onBack: () -> Unit, onRefresh: () -> Unit,
    onOpenSection: (LibraryFilter) -> Unit, onGuide: () -> Unit, onMulti: () -> Unit, onSettings: () -> Unit) {
    val counts = remember(state.catalogItems) { state.catalogItems.groupingBy { it.contentType }.eachCount() }
    val clock by produceState(initialValue = System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(30_000) }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val contentHeight = maxHeight.coerceAtLeast(310.dp)
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).height(contentHeight)
            .padding(horizontal = 22.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvBrand()
                Text(SimpleDateFormat("HH:mm · dd MMM", Locale.FRENCH).format(Date(clock)),
                    modifier = Modifier.weight(1f), color = LibertyMuted, fontSize = 13.sp)
                OutlinedButton(onClick = onBack) { Icon(Icons.Default.SwitchAccount, pickLanguage("Connexions", "Connections", "الاتصالات"), Modifier.size(20.dp)) }
                OutlinedButton(onClick = onRefresh, enabled = !state.loading) { Icon(Icons.Default.Refresh, pickLanguage("Actualiser", "Refresh", "تحديث"), Modifier.size(20.dp)) }
                OutlinedButton(onClick = onSettings) { Icon(Icons.Default.Settings, pickLanguage("Réglages", "Settings", "الإعدادات"), Modifier.size(20.dp)) }
            }
            Spacer(Modifier.height(16.dp))
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvTile(pickLanguage("TV EN DIRECT", "LIVE TV", "البث المباشر"), "${counts[ContentType.LIVE] ?: 0} ${pickLanguage("chaînes", "channels", "قناة")}", Icons.Default.LiveTv,
                        { onOpenSection(LibraryFilter.LIVE) }, Modifier.weight(1f).fillMaxHeight(), GoldTileColors,
                        large = true, enabled = !state.loading, highlighted = true)
                    TvTile(pickLanguage("FILMS", "MOVIES", "أفلام"), when {
                        ContentType.MOVIE in state.sectionsLoaded -> "${formatCount(counts[ContentType.MOVIE] ?: 0)} ${pickLanguage("films", "movies", "فيلم")}"
                        LibraryFilter.MOVIES in state.sectionLoading -> "${formatCount(state.loadingCount)} ${pickLanguage("films", "movies", "فيلم")}…"
                        else -> pickLanguage("Cliquez pour charger", "Click to load", "انقر للتحميل")
                    }, Icons.Default.Movie,
                        { onOpenSection(LibraryFilter.MOVIES) }, Modifier.weight(1f).fillMaxHeight(), enabled = !state.loading)
                    TvTile(pickLanguage("SÉRIES", "SERIES", "مسلسلات"), when {
                        ContentType.SERIES in state.sectionsLoaded -> "${formatCount((counts[ContentType.SERIES] ?: 0) + (counts[ContentType.EPISODE] ?: 0))} ${pickLanguage("éléments", "items", "عنصر")}"
                        LibraryFilter.SERIES in state.sectionLoading -> "${formatCount(state.loadingCount)}…"
                        else -> pickLanguage("Cliquez pour charger", "Click to load", "انقر للتحميل")
                    }, Icons.Default.VideoLibrary,
                        { onOpenSection(LibraryFilter.SERIES) }, Modifier.weight(1f).fillMaxHeight(), enabled = !state.loading)
                }
                Row(Modifier.height(82.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvTile(pickLanguage("RADIO", "RADIO", "راديو"), "${counts[ContentType.RADIO] ?: 0} ${pickLanguage("stations", "stations", "محطة")}", Icons.Default.Radio,
                        { onOpenSection(LibraryFilter.RADIO) }, Modifier.weight(1f).fillMaxHeight(), enabled = !state.loading)
                    TvTile(pickLanguage("LIVE AVEC EPG", "LIVE WITH GUIDE", "مباشر مع الدليل"), pickLanguage("Guide des programmes", "Program guide", "دليل البرامج"), Icons.Default.MenuBook,
                        onGuide, Modifier.weight(1f).fillMaxHeight(), enabled = !state.loading)
                    TvTile(pickLanguage("MULTI-ÉCRANS", "MULTI-SCREEN", "شاشات متعددة"), pickLanguage("2 ou 4 chaînes", "2 or 4 channels", "2 أو 4 قنوات"), Icons.Default.GridView,
                        onMulti, Modifier.weight(1f).fillMaxHeight(), enabled = !state.loading)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(state.lastUpdated?.let { "${pickLanguage("Mis à jour à", "Updated at", "آخر تحديث")} ${SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(it))}" }
                    ?: pickLanguage("Aucune mise à jour", "Never updated", "لا يوجد تحديث"), color = LibertyMuted, fontSize = 12.sp)
                Text("${pickLanguage("Connecté :", "Connected:", "متصل:")} ${state.activePlaylist?.name.orEmpty()}${licenseExpiryDate(state.accountExpiresAt)?.let { " · ${pickLanguage("expire le", "expires", "تنتهي في")} $it" }.orEmpty()}", color = LibertyGold, fontSize = 13.sp, maxLines = 1)
            }
        }
        if (state.loading) {
            Box(Modifier.fillMaxSize().background(Color(0xDA07111F)), contentAlignment = Alignment.Center) {
                Surface(color = LibertyPanel, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = LibertyGold)
                        Spacer(Modifier.height(12.dp))
                        Text(pickLanguage("Chargement de votre connexion…", "Loading your connection…", "جارٍ تحميل اتصالك…"), fontWeight = FontWeight.Bold)
                        Text(pickLanguage("Les grandes listes peuvent prendre un moment.", "Large lists may take a moment.", "القوائم الكبيرة قد تستغرق وقتاً."), color = LibertyMuted, fontSize = 13.sp)
                        TextButton(onClick = onBack) { Text(pickLanguage("Retour aux connexions", "Back to connections", "رجوع للاتصالات")) }
                    }
                }
            }
        }
    }
}

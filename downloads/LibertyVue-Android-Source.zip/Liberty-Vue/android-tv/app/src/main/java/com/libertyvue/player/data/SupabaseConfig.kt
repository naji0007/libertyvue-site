package com.libertyvue.player.data

/** Supabase backend owned by LibertyVue (sync RPC). */
object SupabaseConfig {
    const val PROJECT_URL = "https://zioesbhpkkcqfivtqlqt.supabase.co"
    const val RPC_URL = "$PROJECT_URL/rest/v1/rpc/sync_device"
    const val PUBLISHABLE_KEY = "sb_publishable_cVKOB24p11DwVfQ2uRJOLw_WwIjoyUF"
}

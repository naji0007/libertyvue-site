package com.libertyvue.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val LibertyNavy = Color(0xFF080D15)
val LibertyPanel = Color(0xFF121B28)
val LibertyPanelSoft = Color(0xFF1B293B)
val LibertySelected = Color(0xFF49391D)
val LibertyBorder = Color(0xFF293443)
val LibertyGold = Color(0xFFE8B64A)
val LibertyGoldSoft = Color(0xFFFFD980)
val LibertyGoldDeep = Color(0xFFD9A337)
val LibertyGoldInk = Color(0xFF191508)
val LibertyText = Color(0xFFF6F7FA)
val LibertyMuted = Color(0xFFAAB8C8)
val LibertyDanger = Color(0xFFFF7D7D)

private val colors = darkColorScheme(
    primary = LibertyGold,
    onPrimary = LibertyGoldInk,
    primaryContainer = Color(0xFF4B3912),
    onPrimaryContainer = LibertyGoldSoft,
    secondary = LibertyGoldSoft,
    onSecondary = LibertyGoldInk,
    secondaryContainer = LibertySelected,
    onSecondaryContainer = LibertyGoldSoft,
    tertiary = LibertyGold,
    onTertiary = LibertyGoldInk,
    tertiaryContainer = LibertySelected,
    onTertiaryContainer = LibertyGoldSoft,
    outline = LibertyBorder,
    outlineVariant = LibertyBorder,
    surfaceTint = LibertyGold,
    background = LibertyNavy,
    onBackground = LibertyText,
    surface = LibertyPanel,
    onSurface = LibertyText,
    surfaceVariant = LibertyPanelSoft,
    onSurfaceVariant = LibertyMuted,
    error = LibertyDanger,
)

@Composable
fun LibertyVueTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography.copy(
            displayLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 54.sp,
                lineHeight = 60.sp,
            ),
            headlineLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 34.sp,
                lineHeight = 40.sp,
            ),
            headlineMedium = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.SemiBold,
                fontSize = 26.sp,
                lineHeight = 32.sp,
            ),
            titleLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.SemiBold,
                fontSize = 20.sp,
            ),
            bodyLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontSize = 18.sp,
                lineHeight = 26.sp,
            ),
        ),
        content = content,
    )
}

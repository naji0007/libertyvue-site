package com.libertyvue.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class BrowseMemory(val favorites: Set<String> = emptySet(), val history: List<String> = emptyList()) {
    fun visited(key: String) = copy(history = (listOf(key) + history.filterNot { it == key }).take(100))
    fun toggled(key: String) = copy(favorites = if (key in favorites) favorites - key else favorites + key)
}

class BrowseStore(context: Context) {
    private val preferences = context.getSharedPreferences("libertyvue.browse", Context.MODE_PRIVATE)
    private val vault = CredentialVault()

    fun load(playlistId: String): BrowseMemory = runCatching {
        val raw = preferences.getString(playlistId, null) ?: return BrowseMemory()
        val value = JSONObject(vault.decrypt(raw))
        fun strings(name: String): List<String> {
            val array = value.optJSONArray(name) ?: return emptyList()
            return (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
        }
        BrowseMemory(strings("favorites").toSet(), strings("history").distinct().take(100))
    }.getOrDefault(BrowseMemory())

    fun save(playlistId: String, memory: BrowseMemory) {
        val value = JSONObject().put("favorites", JSONArray(memory.favorites.toList()))
            .put("history", JSONArray(memory.history))
        check(preferences.edit().putString(playlistId, vault.encrypt(value.toString())).commit())
    }

    fun remove(playlistId: String) { preferences.edit().remove(playlistId).apply() }
}

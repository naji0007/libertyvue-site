package com.libertyvue.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URI
import java.net.URLDecoder

class PlaylistRepository(
    private val http: HttpTextClient = HttpTextClient(),
    private val m3uParser: M3uParser = M3uParser(),
    private val xtreamClient: XtreamClient = XtreamClient(http),
) {
    /** Entry load: live channels fast (Xtream) or the whole list (plain M3U). */
    suspend fun loadLive(
        config: PlaylistConfig,
        onPartial: ((LibraryPayload) -> Unit)? = null,
    ): LibraryPayload = withContext(Dispatchers.IO) {
        when (config.type) {
            PlaylistType.M3U -> {
                validateHttpUrl(config.url, AppError.UrlLabel.M3U)
                val inferredXtream = inferXtreamConfig(config)
                if (inferredXtream != null) {
                    val inferred = try {
                        xtreamClient.loadLive(inferredXtream, onPartial)
                    } catch (_: Exception) {
                        null
                    }?.takeIf { it.items.isNotEmpty() }
                    inferred?.let { return@withContext it }
                }

                var firstContentLine: String? = null
                var epgUrl: String? = null
                val items = http.withReader(config.url, MAX_M3U_CHARACTERS) { reader ->
                    val lines = reader.lineSequence().map { line ->
                        if (line.removePrefix("\uFEFF").startsWith("#EXTM3U", ignoreCase = true)) {
                            epgUrl = Regex("(?:url-tvg|x-tvg-url)=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                                .find(line)?.groupValues?.get(1)?.substringBefore(',')
                                ?.let { runCatching { URI(config.url).resolve(it.trim()).toString() }.getOrNull() }
                        }
                        if (firstContentLine == null) {
                            line.trim().takeIf(String::isNotBlank)?.let { firstContentLine = it }
                        }
                        line
                    }
                    m3uParser.parse(lines, config.url)
                }
                if (items.isEmpty()) {
                    val kind = when {
                        firstContentLine.orEmpty().startsWith("<") -> AppError.WrongContentKind.WEB_PAGE
                        firstContentLine.orEmpty().startsWith("{") || firstContentLine.orEmpty().startsWith("[") -> AppError.WrongContentKind.JSON
                        else -> AppError.WrongContentKind.EMPTY
                    }
                    throw AppError.WrongContent(kind)
                }
                LibraryPayload(items = items, epgUrl = epgUrl, fullCatalog = true)
            }
            PlaylistType.XTREAM -> xtreamClient.loadLive(config, onPartial)
        }
    }

    /** On-demand movies/series load for Xtream-compatible connections. */
    suspend fun loadSection(
        config: PlaylistConfig,
        section: XtreamClient.XtreamSection,
        onProgress: ((Int) -> Unit)? = null,
    ): List<StreamItem> = withContext(Dispatchers.IO) {
        val xtream = if (config.type == PlaylistType.XTREAM) config else inferXtreamConfig(config)
            ?: throw AppError.SeriesRequiresXtream
        xtreamClient.loadSection(xtream, section, onProgress)
    }

    suspend fun loadEpisodes(
        config: PlaylistConfig,
        seriesId: Int,
    ): List<StreamItem> = withContext(Dispatchers.IO) {
        val xtreamConfig = when (config.type) {
            PlaylistType.XTREAM -> config
            PlaylistType.M3U -> inferXtreamConfig(config)
                ?: throw AppError.SeriesRequiresXtream
        }
        xtreamClient.loadEpisodes(xtreamConfig, seriesId).also {
            if (it.isEmpty()) throw AppError.NoEpisodes
        }
    }

    companion object {
        private const val MAX_M3U_CHARACTERS = 128 * 1024 * 1024

        fun validateHttpUrl(value: String, label: AppError.UrlLabel = AppError.UrlLabel.M3U) {
            val candidate = value.trim()
            if (!(candidate.startsWith("http://") || candidate.startsWith("https://"))) {
                throw AppError.BadUrl(label)
            }
        }
    }

    fun xtreamConfig(config: PlaylistConfig): PlaylistConfig? =
        if (config.type == PlaylistType.XTREAM) config else inferXtreamConfig(config)

    private fun inferXtreamConfig(config: PlaylistConfig): PlaylistConfig? = runCatching {
        val uri = URI(config.url.trim())
        if (!uri.path.orEmpty().endsWith("/get.php", ignoreCase = true)) return@runCatching null
        val query = uri.rawQuery.orEmpty().split('&').mapNotNull { part ->
            val separator = part.indexOf('=')
            if (separator <= 0) return@mapNotNull null
            decode(part.substring(0, separator)).lowercase() to decode(part.substring(separator + 1))
        }.toMap()
        val username = query["username"].orEmpty()
        val password = query["password"].orEmpty()
        if (username.isBlank() || password.isBlank()) return@runCatching null
        val prefix = uri.path.substringBeforeLast("/get.php").trimEnd('/')
        PlaylistConfig(
            id = config.id,
            name = config.name,
            type = PlaylistType.XTREAM,
            url = "${uri.scheme}://${uri.rawAuthority}$prefix",
            username = username,
            password = password,
            origin = config.origin,
        )
    }.getOrNull()

    private fun decode(value: String): String = URLDecoder.decode(value, Charsets.UTF_8.name())
}

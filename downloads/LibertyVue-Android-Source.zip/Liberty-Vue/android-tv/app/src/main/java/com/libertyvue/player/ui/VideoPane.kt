package com.libertyvue.player.ui

import android.content.Context
import android.view.LayoutInflater
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.libertyvue.player.BuildConfig
import com.libertyvue.player.R
import com.libertyvue.player.data.StreamItem
import com.libertyvue.player.data.ContentType
import com.libertyvue.player.data.pickLanguage

/** Releases decoders, audio and network connections on background or screen exit. */
@Composable
internal fun VideoPane(item: StreamItem, modifier: Modifier = Modifier, audible: Boolean = true,
    controls: Boolean = false, compact: Boolean = false, onPlayerChanged: (Player?) -> Unit = {}) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var generation by remember(lifecycle) { mutableIntStateOf(0) }
    var foreground by remember(lifecycle) { mutableStateOf(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                // Mark the pane inactive before releasing ExoPlayer.  The old
                // implementation incremented the key while the lifecycle was
                // still paused, which could briefly create a second decoder on
                // TV devices and make the activity jump back to the launcher.
                Lifecycle.Event.ON_PAUSE -> {
                    foreground = false
                    generation++
                }
                Lifecycle.Event.ON_RESUME -> foreground = true
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        if (foreground) key(generation) { ActiveVideo(item, audible, controls, compact, onPlayerChanged) }
    }
}

@Composable
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
private fun ActiveVideo(item: StreamItem, audible: Boolean, controls: Boolean, compact: Boolean,
    onPlayerChanged: (Player?) -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val streamUrls = remember(item.streamUrl) { playbackCandidates(item.streamUrl.orEmpty()) }
    var retry by remember { mutableIntStateOf(0) }
    var sourceIndex by remember(item.streamUrl, item.contentType) { mutableIntStateOf(0) }
    var qualityFallback by remember(item.streamUrl, item.contentType) { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    // Some TV chipsets cannot initialise a 4K decoder even when the provider also
    // exposes an adaptive HD rendition. Try the compatible rendition once before
    // showing the final error. A direct, non-adaptive 4K URL still cannot be
    // converted locally, so the UI reports that limitation instead of looping.
    var fallbackActive by remember(item.streamUrl, item.contentType) { mutableStateOf(false) }
    val playerChanged by rememberUpdatedState(onPlayerChanged)
    val releaseScope = remember { CoroutineScope(Dispatchers.Default) }
    val data = remember(compact, retry) {
        DefaultHttpDataSource.Factory().setUserAgent("LibertyVuePlayer/${BuildConfig.VERSION_NAME} (Android TV)")
            .setAllowCrossProtocolRedirects(true)
    }
    val renderersFactory = remember(context) {
        DefaultRenderersFactory(context).setEnableDecoderFallback(true)
    }
    // A channel change replaces the media source on this player, avoiding overlapping decoders.
    val player = remember(data) {
        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(data))
            .apply {
                if (compact) setLoadControl(DefaultLoadControl.Builder()
                    .setBufferDurationsMs(3_000, 12_000, 1_000, 2_000)
                    .setTargetBufferBytes(8 * 1024 * 1024).setPrioritizeTimeOverSizeThresholds(false).build())
            }.build().apply {
                if (compact) trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setMaxVideoSize(1280, 720).build()
            }
    }
    DisposableEffect(player, lifecycle) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
                if (playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_READY) error = null
            }
            override fun onPlayerError(playbackError: PlaybackException) {
                buffering = false
                if (item.contentType != ContentType.RADIO && !compact && sourceIndex + 1 < streamUrls.size) {
                    sourceIndex += 1
                    fallbackActive = true
                    error = pickLanguage("Tentative avec un autre format du flux…", "Trying another stream format…", "جارٍ تجربة صيغة أخرى للبث…")
                } else if (item.contentType != ContentType.RADIO && !compact && qualityFallback < 2) {
                    // Do not call prepare() from inside onPlayerError.  Several
                    // TV MediaCodec implementations are still tearing down the
                    // failed decoder at that point; restarting through the
                    // Compose effect gives the player a clean source lifecycle.
                    qualityFallback += 1
                    fallbackActive = true
                    sourceIndex = 0
                    error = if (qualityFallback == 1) {
                        pickLanguage("Flux UHD non compatible — bascule automatique en HD…", "Incompatible UHD stream — switching to HD…", "بث UHD غير متوافق — التحويل إلى HD…")
                    } else {
                        pickLanguage("Flux UHD non compatible — bascule automatique en 720p…", "Incompatible UHD stream — switching to 720p…", "بث UHD غير متوافق — التحويل إلى 720p…")
                    }
                } else {
                    error = if (fallbackActive) {
                        pickLanguage("Ce flux UHD n’a pas de version HD/HLS compatible sur cet appareil", "This UHD stream has no compatible HD/HLS version on this device", "هذا البث UHD ليس له نسخة HD/HLS متوافقة على هذا الجهاز")
                    } else {
                        playbackError.errorCodeName.removePrefix("ERROR_CODE_").replace('_', ' ')
                    }
                }
            }
        }
        var released = false
        fun releasePlayer() {
            if (!released) {
                released = true
                player.removeListener(listener)
                playerChanged(null)
                // Off the main thread: with a stalled provider the internal
                // threads can take seconds to join (ANR otherwise).
                releaseScope.launch { runCatching { player.release() } }
            }
        }
        // Release immediately: a stopped activity may no longer receive Compose frames.
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_DESTROY) releasePlayer()
        }
        lifecycle.addObserver(observer)
        player.addListener(listener)
        playerChanged(player)
        onDispose { lifecycle.removeObserver(observer); releasePlayer() }
    }
    LaunchedEffect(player, item.streamUrl, item.contentType, sourceIndex, qualityFallback) {
        runCatching {
            player.stop()
            player.clearMediaItems()
            error = null
            buffering = true
            val playbackUrl = streamUrls.getOrElse(sourceIndex) { item.streamUrl.orEmpty() }
            val request = parsePlaybackRequest(playbackUrl)
            data.setDefaultRequestProperties(request.headers)
            val selection = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, item.contentType == ContentType.RADIO)
            // Keep TV and phone playback inside the broadly supported HD
            // envelope.  Adaptive HLS/DASH sources can still provide the best
            // rendition below this cap; a later retry lowers it to 720p. This
            // prevents a single-device 2160p decoder failure from taking down
            // the whole Android TV activity.
            if (!compact) {
                if (qualityFallback >= 2) {
                    selection.setMaxVideoSize(1280, 720).setMaxVideoBitrate(8_000_000)
                } else {
                    selection.setMaxVideoSize(1920, 1080).setMaxVideoBitrate(12_000_000)
                }
            }
            player.trackSelectionParameters = selection.build()
            player.setAudioAttributes(AudioAttributes.DEFAULT, audible)
            player.setMediaItem(MediaItem.fromUri(request.url))
            player.prepare()
            player.playWhenReady = true
        }.onFailure {
            buffering = false
            error = pickLanguage("Impossible d’ouvrir ce flux. Essayez une version HD ou HLS.", "Could not open this stream. Try an HD or HLS version.", "تعذر فتح هذا البث. جرّب نسخة HD أو HLS.")
        }
    }
    LaunchedEffect(player, audible) {
        player.volume = if (audible) 1f else 0f
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, !audible).build()
    }
    if (item.contentType == ContentType.RADIO) RadioPlayerFace(item, player, buffering)
    else AndroidView(factory = { viewContext ->
        (LayoutInflater.from(viewContext).inflate(R.layout.liberty_video_view, null) as PlayerView).apply {
            this.player = player
            useController = controls
            controllerShowTimeoutMs = 4_000
            isFocusable = controls
            isFocusableInTouchMode = controls
            if (controls) requestFocus()
        }
    }, update = { it.player = player; it.useController = controls }, modifier = Modifier.fillMaxSize(),
        onRelease = { it.player = null })
    if (buffering && item.contentType != ContentType.RADIO) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(Modifier.size(28.dp), color = LibertyGold, strokeWidth = 2.dp)
    }
    error?.let {
        Column(Modifier.fillMaxSize().background(Color(0xDC0B1223)).padding(10.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(pickLanguage("Lecture indisponible", "Playback unavailable", "التشغيل غير متوفر"), fontSize = 14.sp)
            if (!compact) Text(it, fontSize = 12.sp, color = LibertyMuted)
            TextButton(onClick = { qualityFallback = 0; fallbackActive = false; sourceIndex = 0; retry++ }) { Text(pickLanguage("Réessayer", "Retry", "إعادة المحاولة")) }
        }
    }
}

private fun playbackCandidates(value: String): List<String> {
    val primary = value.trim()
    if (primary.isBlank()) return listOf(primary)
    val separator = primary.indexOf('|')
    val mediaUrl = if (separator >= 0) primary.substring(0, separator) else primary
    val suffix = if (separator >= 0) primary.substring(separator) else ""
    val queryStart = mediaUrl.indexOf('?')
    val path = if (queryStart >= 0) mediaUrl.substring(0, queryStart) else mediaUrl
    val query = if (queryStart >= 0) mediaUrl.substring(queryStart) else ""
    val alternatePaths = when {
        path.endsWith(".ts", ignoreCase = true) -> listOf(path.dropLast(3) + ".m3u8")
        path.endsWith(".m3u8", ignoreCase = true) -> listOf(
            path.dropLast(5) + ".ts",
            path.dropLast(5) + ".mp4",
        )
        // Xtream VOD/series endpoints are commonly exposed as a direct MP4
        // file even when the same provider also has an adaptive HLS rendition.
        // Trying the HLS sibling is what lets phones and weaker TV chipsets
        // select 1080p/720p instead of attempting the single 2160p file.
        path.endsWith(".mp4", ignoreCase = true) ||
            path.endsWith(".mkv", ignoreCase = true) ||
            path.endsWith(".avi", ignoreCase = true) ||
            path.endsWith(".mov", ignoreCase = true) ||
            path.endsWith(".webm", ignoreCase = true) -> listOf(
            path.substringBeforeLast('.') + ".m3u8",
        )
        else -> emptyList()
    }
    return (listOf(primary) + alternatePaths.map { it + query + suffix }).distinct()
}

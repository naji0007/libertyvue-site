export const CONFIG = {
  APP_ID: __APP_ID__ as string,
  APP_NAME: 'LibertyVue Player',
  VERSION: __APP_VERSION__ as string,

  STORAGE_PREFIX: 'iptv_',

  // Versioned channel customization record (order, display, grouping, and EPG overrides).
  // Bump when its shape changes so an older payload is ignored, not misapplied.
  CHANNEL_CUSTOMIZATION_VERSION: 1,

  // Bundled webOS JS service (see bundled-service/src/lan) for phone setup and uploads.
  SERVICE_ID: __SERVICE_ID__,
  SERVICE_HOST: '127.0.0.1',

  PLAYLIST_REFRESH_INTERVAL: 6 * 60 * 60 * 1000,
  WORKER_IDLE_TERMINATION_MS: 1000,
  PLAYLIST_CACHE_WRITE_DELAY_MS: 1200,
  EPG_REFRESH_INTERVAL: 6 * 60 * 60 * 1000,
  REMINDER_SCAN_INTERVAL: 30 * 1000,
  CHANNEL_SCROLLBAR_HIDE_MS: 900,
  PLAYER: {
    LIVE_PREVIEW_UPCOMING_COUNT: 4,
    LIVE_PREVIEW_REFRESH_MS: 1000,
    OSD_TIMEOUT: 5000,
    BUFFER_LENGTH: 30,
    MANIFEST_TIMEOUT: 5000,
    MANIFEST_MAX_BYTES: 256 * 1024,
    // Long live SegmentTimelines need a larger budget so the parser receives
    // complete MPD XML.
    MPD_MAX_BYTES: 1024 * 1024,
    // mediaOption selects the native MPEG-DASH transport deterministically;
    // bare delegates selection to URI typefinding for provider compatibility.
    DASH_SOURCE: 'mediaOption' as 'mediaOption' | 'bare',
    STREAM_MIME_CACHE_TTL: 7 * 24 * 60 * 60 * 1000,
    // Long enough to type a second or third digit, short enough that a
    // full-width number does not feel stalled once it can no longer grow.
    CHANNEL_NUMBER_TIMEOUT: 1200,
    CHANNEL_NUMBER_MAX_DIGITS: 4,  // fallback cap until the channel count is known
    SEEK_STEP: 30,              // seconds per Left/Right press while seeking catch-up or live DVR
    HLS_MAX_RECOVERIES: 3,      // bounded hls.js fatal-error retries before giving up → next channel
    STALL_POLL_MS: 2000,        // native stall watchdog: currentTime poll interval
    STALL_FREEZE_TICKS: 5,      // ~10s frozen before the first in-place reload
    STALL_MAX_RELOADS: 2,       // in-place reloads before escalating to the next channel
    STARTUP_POLL_MS: 500,       // startup watchdog: readyState/networkState poll interval
    STARTUP_TIMEOUT: 15000,     // ms a stream may load without a frame before it counts as failed
    DVR_MIN_WINDOW: 10,         // live DVR: a seekable window must exceed this (s) to offer timeshift
    DVR_LIVE_EDGE: 10,          // within this many seconds of the window end counts as "at live"
    DVR_GO_LIVE_PAD: 3,         // Go-to-Live seeks to seekable.end minus this (s), avoiding a stall at the edge
    DVR_OLDEST_PAD: 3,          // Rewind stays inside the sliding window so its next refresh cannot strand playback
    RESYNC_SEEK_BACK: 0.5,      // manual A/V resync: seconds to seek back to force a native-pipeline flush
    RESYNC_TIMEOUT: 8000,       // ms safety cap to clear the "Resyncing…" message if `playing` never fires
    SUBTITLE_OFFSET_STEP: 0.25, // seconds per Left/Right press in the subtitle-sync adjuster
    SUBTITLE_OFFSET_MAX: 60,    // max |offset| the adjuster allows (seconds)
    SUBTITLE_SEARCH_TIMEOUT: 8000, // ms one online provider may take before the merged search gives up on it
    UP_NEXT_COUNTDOWN: 10,      // seconds before the queued episode/movie starts automatically
  },

  EPG: {
    VISIBLE_HOURS: 6,
    PIXELS_PER_MINUTE: (1920 - 200) / (6 * 60),
    TIME_SLOT_MINUTES: 30,
    OFFSET_STEP_MINUTES: 15,
    OFFSET_MAX_MINUTES: 12 * 60,
    // Retention ceiling for one XMLTV parse. A five-figure channel count
    // otherwise retains hundreds of MB, which a 1 GB TV cannot survive.
    MAX_RETAINED_PROGRAMMES: 120_000,
    // Visibility and mapping edits arrive one per keypress; coalesce them.
    CHANNEL_CHANGE_RELOAD_DELAY: 2000,
  },

  // Xtream Movies/Series catalog + resume tuning.
  XTREAM: {
    CATALOG_TTL_MS: 6 * 60 * 60 * 1000,  // catalog cache freshness before a re-fetch
    ACCOUNT_MAX_BYTES: 1024 * 1024,      // account/server metadata response budget
    CATEGORY_MAX_BYTES: 2 * 1024 * 1024, // category-list response budget
    CATALOG_MAX_BYTES: 32 * 1024 * 1024, // full or per-category stream-list budget
    DETAIL_MAX_BYTES: 8 * 1024 * 1024,   // VOD/series detail and episode response budget
    RAIL_CATEGORIES: 6,                  // categories preloaded as rails in the browse view
    RAIL_ITEMS: 20,                      // posters shown per rail before the "all categories" drill-in
    RESUME_MIN_SECS: 15,                 // below this, treat as "start over" (don't store a resume point)
    RESUME_FINISH_PAD: 30,               // within this of the end = finished (clear the resume point)
    SEARCH_INITIAL_RESULTS: 200,         // first ranked results published per Search group
    SEARCH_EXPANSION_FACTOR: 5,          // grow retained results near a virtual window boundary
    SEARCH_RESULT_CAP: 50_000,           // final per-group cap after progressive expansion
    ARCHIVE_TTL_MS: 10 * 60 * 1000,      // per-channel get_simple_data_table freshness
    WATCHLIST_MAX_ITEMS: 200,            // per account and content type
  },

  // Catch-up (time-shift) resume and history store tuning.
  CATCHUP: {
    RESUME_MIN_SECS: 15,                // below this, treat as "start over" (don't store a resume point)
    FINISH_PAD: 30,                     // within this of the end = finished; caller sets completed: true
    FALLBACK_RETENTION_DAYS: 7,         // retention when the channel's catchupDays is 0 or absent
    CHECKPOINT_INTERVAL: 30 * 1000,     // how often the player should call setCatchupProgress
  },

  RECENTLY_WATCHED: {
    LIVE_CONFIRM_MS: 5 * 1000,
    MAX_LIVE_ENTRIES: 30,
    MAX_VISIBLE_ITEMS: 50,
  },

  CHANNEL_HEALTH: {
    CONCURRENCY: 4,
    TIMEOUT_MS: 8000,
    MAX_PROBE_BYTES: 128 * 1024,
    MAX_MANIFEST_DEPTH: 2,
    FAILURES_UNTIL_UNAVAILABLE: 2,
  },

  // Max characters shown for a reminder's programme title and channel name
  // before an ellipsis, so long names don't overflow the toast/alert/in-app prompt.
  REMINDER: {
    TITLE_MAX: 40,
    CHANNEL_MAX: 24,
  },

  KEYS: {
    UP: 38,
    DOWN: 40,
    LEFT: 37,
    RIGHT: 39,
    ENTER: 13,
    BACK: 461,
    ESC: 27, // Escape key for desktop, maps to Back
    RED: 403,
    GREEN: 404,
    YELLOW: 405,
    BLUE: 406,
    CH_UP: 33,
    CH_DOWN: 34,
    PLAY: 415,
    PAUSE: 19,
    STOP: 413,
    REWIND: 412,
    FORWARD: 417,
    NUM_0: 48,
    NUM_9: 57,
  },
} as const;

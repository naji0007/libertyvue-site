import { StorageService } from './storage-service';
import { isBareXtreamGetPhpUrl, withM3uTypeParams } from '../utils/xtream-url';
import { genPlaylistId } from '../utils/playlist';
import type { PlaylistEntry } from '../types';
import { createLogger } from '../utils/logger';

const log = createLogger('LibertyVueSync');

const SUPABASE_URL = 'https://zioesbhpkkcqfivtqlqt.supabase.co';
const SUPABASE_KEY = 'sb_publishable_cVKOB24p11DwVfQ2uRJOLw_WwIjoyUF';
const DEVICE_STORAGE_KEY = 'iptv_lv_device';
const TRIAL_STORAGE_KEY = 'iptv_lv_trial_start';
const LICENSE_STORAGE_KEY = 'iptv_lv_license';
const TRIAL_DAYS = 7;

export interface LibertyVueDevice {
  id: string;
  key: string;
}

interface RemotePlaylist {
  id?: string;
  name: string;
  type: string;
  url: string;
  username?: string;
  password?: string;
  origin?: string;
  epgUrl?: string;
}

interface SyncResponse {
  revision?: number;
  playlists?: RemotePlaylist[];
  license?: { status: string; type?: string | null; expiresAt?: number | null; daysRemaining?: number | null };
  error?: string;
}

function randomHex(len: number): string {
  let out = '';
  const chars = '0123456789ABCDEF';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * 16)];
  return out;
}

/** Stable per-TV credentials shown on screen; the reseller enters them on the
 *  LibertyVue website to attach playlists to this TV. */
export function getDeviceCredentials(): LibertyVueDevice {
  try {
    const raw = localStorage.getItem(DEVICE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as LibertyVueDevice;
      if (parsed && parsed.id && parsed.key) return parsed;
    }
  } catch { /* fall through and mint new credentials */ }
  const h = randomHex(10);
  const k = randomHex(8);
  const device: LibertyVueDevice = {
    id: 'LV-' + h.slice(0, 5) + '-' + h.slice(5, 10),
    key: k.slice(0, 4) + '-' + k.slice(4, 8),
  };
  try {
    localStorage.setItem(DEVICE_STORAGE_KEY, JSON.stringify(device));
  } catch { /* storage unavailable; credentials stay in-memory */ }
  return device;
}

export interface LibertyVueLicense {
  status: string;
  type?: string | null;
  expiresAt?: number | null;
  daysRemaining?: number | null;
}

/** Local 7-day trial counted from first launch. */
export function getLocalTrialDaysLeft(now = Date.now()): number {
  let start = 0;
  try {
    const raw = localStorage.getItem(TRIAL_STORAGE_KEY);
    if (raw) start = parseInt(raw, 10) || 0;
  } catch { /* ignore */ }
  if (!start) {
    start = now;
    try {
      localStorage.setItem(TRIAL_STORAGE_KEY, String(start));
    } catch { /* ignore */ }
  }
  const elapsed = Math.floor((now - start) / (24 * 3600 * 1000));
  return Math.max(0, TRIAL_DAYS - elapsed);
}

export function getStoredLicense(): LibertyVueLicense | null {
  try {
    const raw = localStorage.getItem(LICENSE_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as LibertyVueLicense) : null;
  } catch {
    return null;
  }
}

/** Effective licence: server licence when synced, otherwise the local trial. */
export function getEffectiveLicense(): { label: 'trial' | 'active' | 'expired'; daysLeft: number | null; type?: string | null } {
  const server = getStoredLicense();
  if (server) {
    if (server.status === 'active') {
      return { label: 'active', daysLeft: server.daysRemaining ?? null, type: server.type ?? null };
    }
    if (typeof server.daysRemaining === 'number') {
      return server.daysRemaining > 0
        ? { label: 'trial', daysLeft: server.daysRemaining }
        : { label: 'expired', daysLeft: 0 };
    }
  }
  const left = getLocalTrialDaysLeft();
  return left > 0 ? { label: 'trial', daysLeft: left } : { label: 'expired', daysLeft: 0 };
}

function toEntry(pl: RemotePlaylist): PlaylistEntry | null {
  const type = (pl.type || '').toUpperCase();
  if (type === 'XTREAM') {
    if (!pl.url) return null;
    return {
      id: genPlaylistId(),
      name: pl.name || 'Xtream',
      url: pl.url.replace(/\/$/, ''),
      source: 'xtream',
      xtream: { username: pl.username || '', password: pl.password || '' },
    };
  }
  if (!pl.url) return null;
  const url = isBareXtreamGetPhpUrl(pl.url) ? withM3uTypeParams(pl.url) : pl.url;
  return { id: genPlaylistId(), name: pl.name || 'Playlist', url, source: 'url' };
}

/** Pull playlists assigned to this TV on the LibertyVue website and merge
 *  them into the local sources. Returns counts for the status line. */
export async function syncFromWebsite(): Promise<{ added: number; total: number }> {
  const device = getDeviceCredentials();
  let res: Response;
  try {
    res = await fetch(SUPABASE_URL + '/rest/v1/rpc/sync_device', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: SUPABASE_KEY,
        Authorization: 'Bearer ' + SUPABASE_KEY,
      },
      body: JSON.stringify({ p_device_id: device.id, p_device_key: device.key }),
    });
  } catch (e) {
    log.warn('LibertyVue sync network failed', 'event=lv.sync.network');
    throw new Error('network');
  }
  if (!res.ok) throw new Error('http-' + res.status);
  const data = (await res.json()) as SyncResponse;
  if (!data || data.error) throw new Error(data && data.error ? data.error : 'forbidden');
  const remote = Array.isArray(data.playlists) ? data.playlists : [];
  const existing = StorageService.getPlaylists();
  const seen: Record<string, boolean> = {};
  for (const p of existing) seen[((p.source === 'xtream' ? 'XTREAM' : 'M3U') + '|' + p.url).toLowerCase()] = true;
  let added = 0;
  const merged = existing.slice();
  for (const pl of remote) {
    const key = ((pl.type || '').toUpperCase() + '|' + pl.url).toLowerCase();
    if (seen[key]) continue;
    const entry = toEntry(pl);
    if (!entry) continue;
    merged.push(entry);
    seen[key] = true;
    added++;
  }
  if (added > 0) StorageService.setPlaylists(merged);
  if (data.license) {
    try {
      localStorage.setItem(LICENSE_STORAGE_KEY, JSON.stringify(data.license));
    } catch { /* ignore */ }
  }
  log.info('LibertyVue sync done', 'event=lv.sync.done', 'added=' + added, 'total=' + remote.length);
  return { added, total: remote.length };
}

// @vitest-environment jsdom
import { describe, expect, it, vi, beforeEach } from 'vitest';
import { getDeviceCredentials, getEffectiveLicense, getLocalTrialDaysLeft, syncFromWebsite } from './libertyvue-sync';
import { StorageService } from './storage-service';

beforeEach(() => {
  localStorage.clear();
  vi.unstubAllGlobals();
});

describe('getDeviceCredentials', () => {
  it('mints a stable LV device id and key', () => {
    const first = getDeviceCredentials();
    expect(first.id).toMatch(/^LV-[0-9A-F]{5}-[0-9A-F]{5}$/);
    expect(first.key).toMatch(/^[0-9A-F]{4}-[0-9A-F]{4}$/);
    expect(getDeviceCredentials()).toEqual(first);
  });
});

describe('trial and licence', () => {
  it('starts a 7-day local trial on first run', () => {
    expect(getLocalTrialDaysLeft()).toBe(7);
    expect(getEffectiveLicense().label).toBe('trial');
  });

  it('expires the local trial after 7 days', () => {
    const eightDaysAgo = Date.now() - 8 * 24 * 3600 * 1000;
    localStorage.setItem('iptv_lv_trial_start', String(eightDaysAgo));
    expect(getLocalTrialDaysLeft()).toBe(0);
    expect(getEffectiveLicense().label).toBe('expired');
  });
});

describe('syncFromWebsite', () => {
  it('merges remote playlists and skips duplicates', async () => {
    StorageService.setPlaylists([
      { id: 'pl1', name: 'Existing', url: 'http://host/a/list.m3u', source: 'url' },
    ]);
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({
          playlists: [
            { name: 'Existing', type: 'M3U', url: 'http://host/a/list.m3u' },
            { name: 'Provider', type: 'XTREAM', url: 'http://host:8080', username: 'u', password: 'p' },
          ],
        }),
        { status: 200 },
      ),
    );
    vi.stubGlobal('fetch', fetchMock);
    const result = await syncFromWebsite();
    expect(result.added).toBe(1);
    expect(result.total).toBe(2);
    const all = StorageService.getPlaylists();
    expect(all.length).toBe(2);
    const xtream = all.find((p) => p.source === 'xtream');
    expect(xtream?.xtream?.username).toBe('u');
  });

  it('throws on forbidden', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'forbidden' }), { status: 200 })));
    await expect(syncFromWebsite()).rejects.toThrow('forbidden');
  });
});

// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, it, expect, vi } from 'vitest';
import type { Channel } from '../types';
import { CONFIG } from '../config';
import {
  clearAllCachedData,
  clearCachedPlaylist,
  clearCachedStreamMimes,
  clearCachedChannelHealth,
  flushCacheWrites,
  getCacheUsage,
  getCachedCatalog,
  getCachedEpg,
  getCachedPlaylist,
  getCachedStreamMime,
  getCachedChannelHealth,
  getCachedSubtitle,
  migrateLegacyStreamMimeCache,
  scheduleCachedPlaylist,
  setCachedCatalog,
  setCachedEpg,
  setCachedPlaylist,
  setCachedStreamMime,
  setCachedChannelHealth,
  setCachedSubtitle,
} from './idb-cache';
import {
  CACHE_META_STORE,
  CATALOG_STORE,
  CHANNEL_HEALTH_STORE,
  openPersistenceDb,
  requestResult,
  STREAM_MIME_STORE,
  SUBTITLE_STORE,
  transactionDone,
} from './idb-database';

const channel = (id: string): Channel => ({
  id,
  name: 'Alpha',
  logo: '',
  group: '',
  url: 'http://host/a',
  extras: null,
  playlistIds: ['p1'],
  catchup: '',
  catchupSource: '',
  catchupDays: 0,
});

describe('idb-cache', () => {
  beforeEach(async () => {
    localStorage.clear();
    await clearAllCachedData();
  });

  it('uses the next schema version after the published v3 database', async () => {
    const db = await openPersistenceDb();
    expect(db?.version).toBe(5);
    expect(db?.objectStoreNames.contains(STREAM_MIME_STORE)).toBe(true);
  });

  it('stores channel health records separately and accounts for them', async () => {
    await setCachedChannelHealth({
      ch1: { status: 'healthy' },
      ch2: { status: 'suspect' },
    });
    await setCachedChannelHealth({ ch1: { status: 'unavailable' } });

    expect(await getCachedChannelHealth()).toEqual({
      ch1: { status: 'unavailable' },
      ch2: { status: 'suspect' },
    });
    expect((await getCacheUsage()).categories.health.entries).toBe(2);

    await clearCachedChannelHealth();
    expect(await getCachedChannelHealth()).toEqual({});
    expect((await getCacheUsage()).categories.health.entries).toBe(0);
  });

  it('treats a channel health cache read failure as an empty cache', async () => {
    const transaction = IDBDatabase.prototype.transaction;
    const transactionSpy = vi.spyOn(IDBDatabase.prototype, 'transaction').mockImplementation(function (
      this: IDBDatabase,
      storeNames: string | string[],
      mode?: IDBTransactionMode,
    ) {
      if (storeNames === CHANNEL_HEALTH_STORE) throw new Error('read failed');
      return transaction.call(this, storeNames, mode);
    });

    try {
      expect(await getCachedChannelHealth()).toEqual({});
    } finally {
      transactionSpy.mockRestore();
    }
  });

  it('round-trips a cached subtitle', async () => {
    await setCachedSubtitle('subdl:1', 'WEBVTT\n\nhi');
    expect(await getCachedSubtitle('subdl:1')).toContain('hi');
    expect(await getCachedSubtitle('missing')).toBeNull();
  });

  it('stores stream MIME probes in their cache store and expires them', async () => {
    await setCachedStreamMime('http://host/live', 'video/mp2t');
    expect(await getCachedStreamMime('http://host/live')).toBe('video/mp2t');
    expect((await getCacheUsage()).categories.catalog.entries).toBe(1);

    const db = await openPersistenceDb();
    expect(db).not.toBeNull();
    const readTx = db!.transaction(STREAM_MIME_STORE, 'readonly');
    const record = await requestResult(
      readTx.objectStore(STREAM_MIME_STORE).get('http://host/live'),
    );
    const writeTx = db!.transaction(STREAM_MIME_STORE, 'readwrite');
    writeTx.objectStore(STREAM_MIME_STORE).put({ ...record, expiresAt: Date.now() - 1 });
    await transactionDone(writeTx);

    expect(await getCachedStreamMime('http://host/live')).toBeNull();
    expect((await getCacheUsage()).categories.catalog.entries).toBe(0);
  });

  it('migrates legacy stream MIME probes and removes their localStorage key', async () => {
    localStorage.setItem('iptv_stream_mimes', JSON.stringify({
      'http://host/live': { mime: 'video/mp2t', updatedAt: Date.now() },
      'http://host/expired': { mime: 'video/mp2t', updatedAt: 0 },
    }));

    await migrateLegacyStreamMimeCache();

    expect(localStorage.getItem('iptv_stream_mimes')).toBeNull();
    expect(await getCachedStreamMime('http://host/live')).toBe('video/mp2t');
    expect(await getCachedStreamMime('http://host/expired')).toBeNull();
  });

  it('clears stream MIME records without clearing catalog records', async () => {
    await setCachedCatalog('x1|vod_categories', ['a']);
    await setCachedStreamMime('http://host/live', 'video/mp2t');

    await clearCachedStreamMimes();

    expect(await getCachedStreamMime('http://host/live')).toBeNull();
    expect(await getCachedCatalog('x1|vod_categories')).not.toBeNull();
    expect((await getCacheUsage()).categories.catalog.entries).toBe(1);
  });

  it('includes stream MIME records in the shared cache eviction pass', async () => {
    await setCachedStreamMime('http://host/live', 'video/mp2t');
    const storageDescriptor = Object.getOwnPropertyDescriptor(navigator, 'storage');
    Object.defineProperty(navigator, 'storage', {
      configurable: true,
      value: { estimate: async () => ({ usage: 0, quota: 100 }) },
    });
    try {
      await setCachedCatalog('x1|vod_categories', ['a']);
    } finally {
      if (storageDescriptor) {
        Object.defineProperty(navigator, 'storage', storageDescriptor);
      } else {
        delete (navigator as Navigator & { storage?: StorageManager }).storage;
      }
    }

    expect(await getCachedStreamMime('http://host/live')).toBeNull();
    expect(await getCachedCatalog('x1|vod_categories')).not.toBeNull();
  });

  it('removes an expired subtitle instead of serving it', async () => {
    await setCachedSubtitle('subdl:expired', 'WEBVTT\n\nold');
    const db = await openPersistenceDb();
    expect(db).not.toBeNull();
    const readTx = db!.transaction(SUBTITLE_STORE, 'readonly');
    const record = await requestResult(readTx.objectStore(SUBTITLE_STORE).get('subdl:expired'));
    const writeTx = db!.transaction(SUBTITLE_STORE, 'readwrite');
    writeTx.objectStore(SUBTITLE_STORE).put({
      ...record,
      expiresAt: Date.now() - 1,
    });
    await transactionDone(writeTx);

    expect(await getCachedSubtitle('subdl:expired')).toBeNull();
    expect((await getCacheUsage()).categories.subtitle.entries).toBe(0);
  });

  it('clears every cache when resetting the app', async () => {
    await setCachedEpg('http://host/epg', { channels: {}, programmes: {} });
    await setCachedCatalog('x1|categories', ['a']);
    await setCachedSubtitle('subdl:2', 'WEBVTT\n\nhi');
    await setCachedChannelHealth({ ch1: { status: 'healthy' } });

    await clearAllCachedData();

    expect(await getCachedEpg('http://host/epg')).toBeNull();
    expect(await getCachedCatalog('x1|categories')).toBeNull();
    expect(await getCachedSubtitle('subdl:2')).toBeNull();
    expect(await getCachedChannelHealth()).toEqual({});
  });

  it('stores parsed playlists outside localStorage', async () => {
    const channels = [channel('ch1')];
    const sources = [{ url: 'http://host/epg', playlistIds: ['p1'], kind: 'm3u' as const }];

    expect(await setCachedPlaylist(channels, sources)).toBe(true);

    expect(await getCachedPlaylist()).toEqual({ channels, epgSources: sources });
    expect(localStorage.getItem('iptv_cached_playlist')).toBeNull();
  });

  it('defers playlist persistence until after worker idle termination', async () => {
    const frames: FrameRequestCallback[] = [];
    let delayedWrite: (() => void) | null = null;
    const originalRequest = globalThis.requestAnimationFrame;
    const originalCancel = globalThis.cancelAnimationFrame;
    const originalSetTimeout = globalThis.setTimeout;
    globalThis.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      frames.push(callback);
      return frames.length;
    });
    globalThis.cancelAnimationFrame = vi.fn();
    const timer = vi.spyOn(globalThis, 'setTimeout').mockImplementation(
      ((callback: TimerHandler, delay?: number, ...args: unknown[]) => {
        if (delay === CONFIG.PLAYLIST_CACHE_WRITE_DELAY_MS) {
          delayedWrite = () => {
            if (typeof callback === 'function') callback(...args);
          };
          return 1;
        }
        return originalSetTimeout(callback, delay, ...args);
      }) as typeof setTimeout,
    );
    try {
      scheduleCachedPlaylist([channel('ch1')]);
      expect(await getCachedPlaylist()).toBeNull();

      frames.shift()?.(0);
      expect(await getCachedPlaylist()).toBeNull();

      frames.shift()?.(16);
      expect(await getCachedPlaylist()).toBeNull();
      expect(timer).toHaveBeenCalledWith(
        expect.any(Function),
        CONFIG.PLAYLIST_CACHE_WRITE_DELAY_MS,
      );

      delayedWrite?.();
      await flushCacheWrites();
      expect(await getCachedPlaylist()).not.toBeNull();
    } finally {
      globalThis.requestAnimationFrame = originalRequest;
      globalThis.cancelAnimationFrame = originalCancel;
      timer.mockRestore();
    }
  });

  it('does not serve a parsed playlist after its source configuration changes', async () => {
    localStorage.setItem('iptv_playlists', JSON.stringify([
      { id: 'p1', name: 'Alpha', url: 'http://host/a' },
    ]));
    await setCachedPlaylist([channel('ch1')]);

    localStorage.setItem('iptv_playlists', JSON.stringify([
      { id: 'p2', name: 'Bravo', url: 'http://host/b' },
    ]));

    expect(await getCachedPlaylist()).toBeNull();
  });

  it('binds a delayed playlist write to the configuration that produced it', async () => {
    const frames: FrameRequestCallback[] = [];
    let delayedWrite: (() => void) | null = null;
    const originalRequest = globalThis.requestAnimationFrame;
    const originalCancel = globalThis.cancelAnimationFrame;
    const originalSetTimeout = globalThis.setTimeout;
    globalThis.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      frames.push(callback);
      return frames.length;
    });
    globalThis.cancelAnimationFrame = vi.fn();
    const timer = vi.spyOn(globalThis, 'setTimeout').mockImplementation(
      ((callback: TimerHandler, delay?: number, ...args: unknown[]) => {
        if (delay === CONFIG.PLAYLIST_CACHE_WRITE_DELAY_MS) {
          delayedWrite = () => {
            if (typeof callback === 'function') callback(...args);
          };
          return 1;
        }
        return originalSetTimeout(callback, delay, ...args);
      }) as typeof setTimeout,
    );
    try {
      localStorage.setItem('iptv_playlists', JSON.stringify([
        { id: 'p1', name: 'Alpha', url: 'http://host/a' },
      ]));
      scheduleCachedPlaylist([channel('ch1')]);
      frames.shift()?.(0);
      frames.shift()?.(16);

      localStorage.setItem('iptv_playlists', JSON.stringify([
        { id: 'p2', name: 'Bravo', url: 'http://host/b' },
      ]));
      delayedWrite?.();
      await flushCacheWrites();

      expect(await getCachedPlaylist()).toBeNull();
    } finally {
      globalThis.requestAnimationFrame = originalRequest;
      globalThis.cancelAnimationFrame = originalCancel;
      timer.mockRestore();
    }
  });

  it.each([
    ['playlist cache', clearCachedPlaylist],
    ['all caches', clearAllCachedData],
  ])('does not restore a scheduled playlist after clearing %s', async (_label, clear) => {
    const frames: FrameRequestCallback[] = [];
    let delayedWrite: (() => void) | null = null;
    const originalRequest = globalThis.requestAnimationFrame;
    const originalCancel = globalThis.cancelAnimationFrame;
    const originalSetTimeout = globalThis.setTimeout;
    globalThis.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      frames.push(callback);
      return frames.length;
    });
    globalThis.cancelAnimationFrame = vi.fn();
    const timer = vi.spyOn(globalThis, 'setTimeout').mockImplementation(
      ((callback: TimerHandler, delay?: number, ...args: unknown[]) => {
        if (delay === CONFIG.PLAYLIST_CACHE_WRITE_DELAY_MS) {
          delayedWrite = () => {
            if (typeof callback === 'function') callback(...args);
          };
          return 1;
        }
        return originalSetTimeout(callback, delay, ...args);
      }) as typeof setTimeout,
    );
    try {
      scheduleCachedPlaylist([channel('ch1')]);
      frames.shift()?.(0);
      frames.shift()?.(16);

      await clear();
      delayedWrite?.();
      await flushCacheWrites();

      expect(await getCachedPlaylist()).toBeNull();
    } finally {
      globalThis.requestAnimationFrame = originalRequest;
      globalThis.cancelAnimationFrame = originalCancel;
      timer.mockRestore();
    }
  });

  it('accounts for cache usage by category and resets it on clear', async () => {
    await Promise.all([
      setCachedPlaylist([channel('ch1')]),
      setCachedEpg('http://host/epg', { channels: {}, programmes: {} }),
      setCachedCatalog('x1|vod_categories', ['a']),
      setCachedSubtitle('subdl:3', 'WEBVTT\n\nhello'),
    ]);

    const usage = await getCacheUsage();
    expect(usage.total.bytes).toBeGreaterThan(0);
    expect(usage.total.entries).toBe(4);
    expect(usage.categories.playlist.entries).toBe(1);
    expect(usage.categories.epg.entries).toBe(1);
    expect(usage.categories.catalog.entries).toBe(1);
    expect(usage.categories.subtitle.entries).toBe(1);
    expect(usage.budgetBytes).toBe(384 * 1024 * 1024);

    await clearAllCachedData();
    expect((await getCacheUsage()).total).toEqual({ bytes: 0, entries: 0 });
  });

  it('accounts for serialized bytes without changing JSON sizing semantics', async () => {
    await setCachedCatalog('x1|sizing', {
      text: '\u0000"\\é😀',
      values: [true, false, null, undefined, 12.5, Number.NaN],
    });
    const db = await openPersistenceDb();
    expect(db).not.toBeNull();
    const tx = db!.transaction([CATALOG_STORE, CACHE_META_STORE], 'readonly');
    const record = await requestResult(tx.objectStore(CATALOG_STORE).get('x1|sizing')) as
      Record<string, unknown>;
    const meta = await requestResult(
      tx.objectStore(CACHE_META_STORE).get('entry:catalog-cache:x1|sizing'),
    ) as { byteSize: number };
    const expected = new TextEncoder().encode(JSON.stringify({
      ...record,
      byteSize: 0,
    })).byteLength;

    expect(meta.byteSize).toBe(expected);
  });

  it('updates cache accounting without reading the previous payload', async () => {
    await setCachedCatalog('x1|vod_all', Array.from({ length: 100 }, (_, index) => index));
    const transaction = IDBDatabase.prototype.transaction;
    const payloadReads: Array<{ stores: string | string[]; mode?: IDBTransactionMode }> = [];
    const transactionSpy = vi.spyOn(IDBDatabase.prototype, 'transaction').mockImplementation(
      function (
        this: IDBDatabase,
        storeNames: string | string[],
        mode?: IDBTransactionMode,
      ) {
        if (mode === 'readonly'
            && (storeNames === CATALOG_STORE
              || (Array.isArray(storeNames) && storeNames.includes(CATALOG_STORE)))) {
          payloadReads.push({ stores: storeNames, mode });
        }
        return transaction.call(this, storeNames, mode);
      },
    );

    try {
      await setCachedCatalog('x1|vod_all', Array.from({ length: 200 }, (_, index) => index));
    } finally {
      transactionSpy.mockRestore();
    }

    expect(payloadReads).toEqual([]);
    expect((await getCacheUsage()).categories.catalog.entries).toBe(1);
  });

  it('touches access metadata without rewriting a cached payload', async () => {
    await setCachedCatalog('x1|vod_all', Array.from({ length: 100 }, (_, index) => index));
    const db = await openPersistenceDb();
    expect(db).not.toBeNull();
    const beforeTx = db!.transaction(CATALOG_STORE, 'readonly');
    const before = await requestResult(beforeTx.objectStore(CATALOG_STORE).get('x1|vod_all'));

    expect(await getCachedCatalog('x1|vod_all')).not.toBeNull();
    await new Promise(resolve => setTimeout(resolve, 0));

    const afterTx = db!.transaction([CATALOG_STORE, CACHE_META_STORE], 'readonly');
    const after = await requestResult(afterTx.objectStore(CATALOG_STORE).get('x1|vod_all'));
    const access = await requestResult(
      afterTx.objectStore(CACHE_META_STORE).get('entry:catalog-cache:x1|vod_all'),
    );
    expect(after).toEqual(before);
    expect(access).toMatchObject({
      store: CATALOG_STORE,
      key: 'x1|vod_all',
    });
  });

  it('keeps accounting correct when pruning the record being updated', async () => {
    await setCachedSubtitle('subdl:4', 'WEBVTT\n\nold');
    const storageDescriptor = Object.getOwnPropertyDescriptor(navigator, 'storage');
    Object.defineProperty(navigator, 'storage', {
      configurable: true,
      value: { estimate: async () => ({ usage: 0, quota: 100 }) },
    });
    try {
      await setCachedSubtitle('subdl:4', 'WEBVTT\n\nreplacement');
    } finally {
      if (storageDescriptor) {
        Object.defineProperty(navigator, 'storage', storageDescriptor);
      } else {
        delete (navigator as Navigator & { storage?: StorageManager }).storage;
      }
    }

    const usage = await getCacheUsage();
    expect(usage.categories.subtitle.entries).toBe(1);
    expect(usage.total.entries).toBe(1);
  });
});

import {
  UNCATEGORIZED_GROUP,
  type Channel,
  type ChannelGroupId,
  type EpgSource,
  type ParsedPlaylist,
  type PlaylistTab,
} from '../types';
import { fetchAndParseM3U } from '../parsers/m3u-loader';
import type { M3ULoadProgress } from '../parsers/m3u-loader';
import {
  xtreamPlaylistUrl,
  xtreamEpgUrl,
  xtreamCatchupSource,
  xtreamLiveUrl,
  resolveXtreamLiveOutput,
  type XtreamCredentials,
  type XtreamLiveOutput,
} from '../utils/xtream-url';
import {
  channelKey,
  legacyChannelKey,
} from '../utils/channel';
import { createXtreamLiveStreamIdResolver } from '../utils/xtream-live-match';
import {
  prepareSearchItem,
  rankPreparedTopK,
  type PreparedSearchItem,
  type RankedSearchResult,
} from '../utils/channel-search';
import { createLogger } from '../utils/logger';
import { StorageService } from './storage-service';
import { ChannelCustomizationService, groupKeyOf } from './channel-customization';
import {
  createXtreamClient,
  type XtreamLiveCategory,
  type XtreamLiveStream,
} from './xtream-client';
import { getCachedPlaylist, scheduleCachedPlaylist } from './idb-cache';
import { isSourceEnabled } from '../utils/playlist';

const log = createLogger('Playlist');

export interface PlaylistLoadProgress {
  sourceNumber: number;
  sourceCount: number;
  inputBytes: number;
  channelsProcessed: number;
  channelsKept: number;
}

function usableDirectSource(value: string): string {
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:' ? value : '';
  } catch {
    return '';
  }
}

function xtreamLivePlaylist(
  credentials: XtreamCredentials,
  output: XtreamLiveOutput,
  categories: XtreamLiveCategory[],
  streams: XtreamLiveStream[],
): ParsedPlaylist {
  const categoryNames = new Map(categories.map(category => [category.id, category.name]));
  const channels: Channel[] = streams.map(stream => ({
    id: stream.epgChannelId || stream.streamId,
    name: stream.name || stream.streamId,
    logo: stream.icon,
    group: categoryNames.get(stream.categoryId) || UNCATEGORIZED_GROUP,
    url: usableDirectSource(stream.directSource)
      || xtreamLiveUrl(credentials, stream.streamId, output),
    extras: null,
    playlistIds: [],
    catchup: '',
    catchupSource: '',
    catchupDays: 0,
    catchupStreamId: stream.streamId,
  }));
  const groups = Array.from(new Set(channels.map(channel => channel.group)));
  return {
    channels,
    groups,
    epgUrl: '',
    epgUrls: [],
    headerAttributes: {},
    format: 'unknown',
    issues: [],
  };
}

class PlaylistServiceImpl {
  /** Every parsed channel, hidden ones included. Edit mode reads this. */
  allChannels: Channel[] = [];
  /** Visible channels in effective (customized) order. Everything else reads this. */
  channels: Channel[] = [];
  groups: string[] = [];
  groupsRevision = 0;
  playlistTabs: PlaylistTab[] = [];
  epgSources: EpgSource[] = [];
  private indexMap = new Map<Channel, number>(); // channel -> global index, O(1) indexOf
  private channelsByGroup = new Map<string, Channel[]>();
  private channelsByPlaylist = new Map<string, Channel[]>();
  private channelsByPlaylistGroup = new Map<string, Map<string, Channel[]>>();
  private groupsByPlaylist = new Map<string, string[]>();
  private groupKeyByDisplay = new Map<string, string>();
  private channelByKey = new Map<string, Channel>();
  private channelByLegacyKey = new Map<string, Channel | null>();
  private channelSearchIndex: PreparedSearchItem<Channel>[] = [];
  private channelSearchByPlaylist = new Map<string, PreparedSearchItem<Channel>[]>();
  private indexedChannels: Channel[] | null = null;
  private indexedChannelCount = -1;
  private searchIndexedChannels: Channel[] | null = null;
  private searchIndexedChannelCount = -1;
  private includeHidden = false;
  private failedSourceIds = new Set<string>();

  hasFailedSource(playlistIds: readonly string[]): boolean {
    return playlistIds.some(id => this.failedSourceIds.has(id));
  }

  get allSourcesDisabled(): boolean {
    const sources = StorageService.getPlaylists();
    return sources.length > 0 && !sources.some(isSourceEnabled);
  }

  /**
   * Clear all in-memory state. Called when the user removes every configured
   * playlist so stale channels do not survive navigation back to the channel
   * list view.
   */
  reset(): void {
    this.failedSourceIds.clear();
    this.allChannels = [];
    this.channels = [];
    this.groups = [];
    this.groupsRevision++;
    this.playlistTabs = [];
    this.epgSources = [];
    this.indexMap = new Map();
    this.channelsByGroup = new Map();
    this.channelsByPlaylist = new Map();
    this.channelsByPlaylistGroup = new Map();
    this.groupsByPlaylist = new Map();
    this.groupKeyByDisplay = new Map();
    this.channelByKey = new Map();
    this.channelByLegacyKey = new Map();
    this.channelSearchIndex = [];
    this.channelSearchByPlaylist = new Map();
    this.indexedChannels = null;
    this.indexedChannelCount = -1;
    this.searchIndexedChannels = null;
    this.searchIndexedChannelCount = -1;
  }

  async load(onProgress?: (progress: PlaylistLoadProgress) => void): Promise<Channel[]> {
    const enabledSources = StorageService.getPlaylists().filter(isSourceEnabled);
    const enabledIds = new Set(enabledSources.map(source => source.id));
    if (!enabledIds.size) {
      this.reset();
      this.logLoadCompleted('none', 0, 0);
      return [];
    }
    const cached = await getCachedPlaylist();
    if (cached) {
      this.failedSourceIds.clear();
      const channelsNeedFiltering = cached.channels
        .some(channel => channel.playlistIds.some(id => !enabledIds.has(id)));
      this.allChannels = channelsNeedFiltering
        ? cached.channels
            .map(channel => ({
              ...channel,
              playlistIds: channel.playlistIds.filter(id => enabledIds.has(id)),
            }))
            .filter(channel => channel.playlistIds.length > 0)
        : cached.channels;
      const epgSourcesNeedFiltering = cached.epgSources
        .some(source => source.playlistIds.some(id => !enabledIds.has(id)));
      this.epgSources = epgSourcesNeedFiltering
        ? cached.epgSources
            .map(source => ({
              ...source,
              playlistIds: source.playlistIds.filter(id => enabledIds.has(id)),
            }))
            .filter(source => source.playlistIds.length > 0)
        : cached.epgSources;
      log.info('Cache hit:', this.allChannels.length, 'channels,', this.epgSources.length, 'epg sources');
      this.applyCustomization();
      this.buildPlaylistTabs();
      StorageService.migrateFavoriteKeys(this.channels);
      this.logLoadCompleted('cache', enabledIds.size, 0);
      return this.channels;
    }
    log.info('Cache miss — refreshing from network');
    return this.refresh(onProgress);
  }

  async refresh(onProgress?: (progress: PlaylistLoadProgress) => void): Promise<Channel[]> {
    const done = log.time('refresh');
    const playlists = StorageService.getPlaylists().filter(isSourceEnabled);
    if (!playlists.length) {
      log.info('No playlist sources enabled');
      this.reset();
      this.logLoadCompleted('none', 0, 0);
      done();
      return [];
    }

    const allChannels: Channel[] = [];
    const byUrl = new Map<string, Channel>();
    const epgSources: EpgSource[] = [];
    let failedPlaylists = 0;
    const failedSourceIds = new Set<string>();
    let completedProcessed = 0;
    let completedKept = 0;
    const addEpgSource = (url: string, playlistId: string, kind: EpgSource['kind']): void => {
      const existing = epgSources.find((source) => source.url === url);
      if (existing) {
        if (!existing.playlistIds.includes(playlistId)) existing.playlistIds.push(playlistId);
        return;
      }
      epgSources.push({ url, playlistIds: [playlistId], kind });
    };

    for (let playlistIndex = 0; playlistIndex < playlists.length; playlistIndex++) {
      const pl = playlists[playlistIndex];
      const load = playlistIndex + 1;
      const source = pl.source === 'xtream' ? 'xtream' : 'm3u';
      const sourceStarted = Date.now();
      const sourceEpgStart = epgSources.length;
      let sourceProcessed = 0;
      let sourceKept = 0;
      log.info(
        'Playlist source load started',
        'event=playlist.source.load.started',
        `load=${String(load)}`,
        `source=${source}`,
      );
      // Tag channels by the playlist's stable id, not its name or position, so
      // two playlists sharing a name/URL stay distinct and deleting/reordering
      // one never re-points another's channels.
      const plKey = pl.id;
      // Use the Player API catalog to identify Live entries, but keep get.php as
      // the channel source so provider ordering, headers, URLs, and metadata survive.
      let fetchUrl = pl.url;
      let xtreamCredentials: XtreamCredentials | null = null;
      let xtreamOutput: XtreamLiveOutput = 'ts';
      let xtreamStreams: XtreamLiveStream[] | undefined;
      let xtreamCatalogAvailable = false;
      if (pl.source === 'xtream' && pl.xtream) {
        const credentials = { baseUrl: pl.url, ...pl.xtream };
        xtreamCredentials = credentials;
        const client = createXtreamClient(credentials);
        let allowedOutputFormats: string[] = [];
        if (pl.xtream.liveOutput === 'auto') {
          allowedOutputFormats =
            (await client.getAccountInfo())?.allowedOutputFormats ?? [];
        }
        xtreamOutput = resolveXtreamLiveOutput(pl.xtream.liveOutput, allowedOutputFormats);
        const catalogStarted = Date.now();
        log.info(
          'Xtream Live catalog load started',
          'event=xtream.live_catalog.started',
          `load=${String(load)}`,
          'endpoint=get_live_streams',
        );
        const liveCatalog = await client.getLiveStreamsResult();
        xtreamCatalogAvailable = liveCatalog.available;
        xtreamStreams = liveCatalog.streams;
        log[liveCatalog.available ? 'info' : 'warn'](
          'Xtream Live catalog load completed',
          'event=xtream.live_catalog.completed',
          `load=${String(load)}`,
          `available=${liveCatalog.available ? '1' : '0'}`,
          `items=${String(liveCatalog.streams.length)}`,
          `elapsedMs=${String(Date.now() - catalogStarted)}`,
        );
        fetchUrl = xtreamPlaylistUrl(
          credentials,
          xtreamOutput,
        );
      }
      const plDone = log.time(`fetch '${pl.name || pl.url}'`);
      try {
        let parsed: ParsedPlaylist | null = null;
        let playlistError: unknown;
        try {
          const loaded = await fetchAndParseM3U(
            fetchUrl,
            60000,
            xtreamCatalogAvailable ? xtreamStreams : undefined,
            xtreamCredentials?.baseUrl,
            (progress: M3ULoadProgress) => {
              sourceProcessed = Math.max(sourceProcessed, progress.channelsProcessed);
              sourceKept = Math.max(sourceKept, progress.channelsKept);
              onProgress?.({
                sourceNumber: load,
                sourceCount: playlists.length,
                inputBytes: progress.inputBytes,
                channelsProcessed: completedProcessed + sourceProcessed,
                channelsKept: completedKept + sourceKept,
              });
            },
          );
          parsed = loaded.data;
        } catch (err) {
          playlistError = err;
          if (!xtreamCredentials) throw err;
          log.warn(
            'Xtream playlist failed; trying the Player API live catalog',
            'event=xtream.live_fallback.used',
            `load=${String(load)}`,
            'reason=request_failed',
          );
        }

        let fallbackStreams: XtreamLiveStream[] | undefined;
        if (xtreamCredentials && (!parsed || !parsed.channels.length)) {
          if (parsed) {
            log.warn(
              'Xtream playlist contained no channels; trying the Player API live catalog',
              'event=xtream.live_fallback.used',
              `load=${String(load)}`,
              'reason=no_channels',
            );
          }
          const client = createXtreamClient(xtreamCredentials);
          const categories = await client.getLiveCategories();
          const streams = xtreamCatalogAvailable
            ? xtreamStreams ?? []
            : await client.getLiveStreams();
          fallbackStreams = streams;
          log.info(
            'Xtream Player API live catalog completed',
            'event=xtream.live_api.completed',
            `load=${String(load)}`,
            `categories=${String(categories.length)}`,
            `streams=${String(streams.length)}`,
          );
          if (streams.length) {
            parsed = xtreamLivePlaylist(
              xtreamCredentials,
              xtreamOutput,
              categories,
              streams,
            );
          } else if (!parsed && playlistError) {
            throw playlistError;
          }
        }
        if (!parsed) throw new Error('Xtream source returned no playlist or live catalog');

        if (xtreamCredentials) {
          await this.applyXtreamCatchup(
            parsed.channels,
            xtreamCredentials,
            plKey,
            xtreamOutput,
            fallbackStreams ?? xtreamStreams,
          );
        }
        if (parsed.issues.length) {
          log.warn('Playlist diagnostics:',
            parsed.issues.slice(0, 5).map(issue => `${issue.code}@${issue.line}`).join(', '));
        }
        log.info('Parsed', parsed.channels.length, 'channels,', parsed.groups.length, 'groups',
          parsed.epgUrl ? `| epg: ${parsed.epgUrl}` : '');
        let added = 0, dupes = 0;
        for (const ch of parsed.channels) {
          const existing = byUrl.get(ch.url);
          if (existing) {
            // Same stream in an earlier playlist: keep the one channel object
            // (so "All" stays de-duplicated), but record this playlist too so
            // its own tab still appears and shows the channel.
            if (!existing.playlistIds.includes(plKey)) existing.playlistIds.push(plKey);
            dupes++;
          } else {
            ch.playlistIds = [plKey];
            byUrl.set(ch.url, ch);
            allChannels.push(ch);
            added++;
          }
        }
        log.debug(`Added ${added} channels (${dupes} duplicates skipped)`);
        if (pl.source === 'xtream' && pl.xtream) {
          // The panel's own XMLTV endpoint; the get.php url-tvg (if any) is added below too.
          const epg = xtreamEpgUrl({ baseUrl: pl.url, ...pl.xtream });
          addEpgSource(epg, plKey, 'xtream');
        }
        for (const parsedEpgUrl of parsed.epgUrls) {
          // Resolve localhost/127.0.0.1 in embedded EPG URL to the playlist's host
          let epg = parsedEpgUrl;
          try {
            const epgParsed = new URL(epg);
            if (epgParsed.hostname === 'localhost' || epgParsed.hostname === '127.0.0.1') {
              const plParsed = new URL(pl.url);
              epgParsed.hostname = plParsed.hostname;
              epg = epgParsed.toString();
              log.info('Rewrote loopback EPG host to', epgParsed.hostname);
            }
          } catch (e) { log.warn('Could not parse EPG URL:', epg, e); }
          addEpgSource(epg, plKey, 'm3u');
        }
        log.info(
          'Playlist source load completed',
          'event=playlist.source.load.completed',
          `load=${String(load)}`,
          `source=${source}`,
          `channels=${String(parsed.channels.length)}`,
          `added=${String(added)}`,
          `duplicates=${String(dupes)}`,
          `epg=${String(epgSources.length - sourceEpgStart)}`,
          `elapsedMs=${String(Date.now() - sourceStarted)}`,
        );
      } catch (err) {
        failedPlaylists++;
        failedSourceIds.add(plKey);
        log.error(
          'Playlist source load failed',
          'event=playlist.source.load.failed',
          `load=${String(load)}`,
          `source=${source}`,
          'reason=request_failed',
          `elapsedMs=${String(Date.now() - sourceStarted)}`,
          err,
        );
        if (pl.source === 'xtream') {
          log.error(
            `Failed to load Xtream playlist '${pl.name || pl.url}'`,
            'event=xtream.playlist.load.failed',
            `load=${String(load)}`,
            err,
          );
        } else {
          log.error(`Failed to load playlist '${pl.name || pl.url}':`, err);
        }
      }
      completedProcessed += sourceProcessed;
      completedKept += sourceKept;
      plDone();
    }

    this.failedSourceIds = failedSourceIds;
    this.allChannels = allChannels;
    this.epgSources = epgSources;
    // Customization preserves source names/groups on each channel, so cached
    // channels can be re-customized after an edit without another network load.
    if (!failedPlaylists) {
      scheduleCachedPlaylist(allChannels, epgSources);
    } else {
      log.warn('Skipping cache write because one or more playlists failed');
    }
    this.applyCustomization();
    this.buildPlaylistTabs();
    StorageService.migrateFavoriteKeys(this.channels);
    log.info('Refresh complete:', allChannels.length, 'total channels,', epgSources.length, 'epg sources');
    this.logLoadCompleted('network', playlists.length, failedPlaylists);
    done();
    return this.channels;
  }

  /**
   * One structured line per load so a diagnostics report can tie an empty
   * channel list to the sources that produced it — the rendered list is
   * virtualized, so its DOM row count says nothing about the catalog.
   */
  private logLoadCompleted(
    source: 'cache' | 'network' | 'none',
    sources: number,
    failed: number,
  ): void {
    const level = failed || (sources && !this.channels.length) ? 'warn' : 'info';
    log[level](
      'Playlist load completed',
      'event=playlist.load.completed',
      `source=${source}`,
      `channels=${this.channels.length}`,
      `all=${this.allChannels.length}`,
      `groups=${this.groups.length}`,
      `epg=${this.epgSources.length}`,
      `sources=${sources}`,
      `failed=${failed}`,
    );
  }

  private async applyXtreamCatchup(
    channels: Channel[],
    credentials: XtreamCredentials,
    accountId: string,
    output: XtreamLiveOutput,
    knownStreams?: XtreamLiveStream[],
  ): Promise<void> {
    const client = createXtreamClient(credentials);
    const streams = knownStreams ?? await client.getLiveStreams();
    const archived = new Map(streams
      .filter(stream => stream.archive)
      .map(stream => [stream.streamId, stream]));
    if (!archived.size) return;

    const clock = await client.getServerClock();
    const knownIds = new Set(streams.map(stream => stream.streamId));
    const resolveLiveStreamId = createXtreamLiveStreamIdResolver(
      streams,
      credentials.baseUrl,
    );
    let enabled = 0;
    let unmatched = 0;
    for (const channel of channels) {
      const streamId = channel.catchupStreamId && knownIds.has(channel.catchupStreamId)
        ? channel.catchupStreamId
        : resolveLiveStreamId(channel.url);
      const stream = archived.get(streamId);
      if (!stream) {
        if (!streamId) unmatched++;
        continue;
      }
      channel.catchupStreamId = streamId;
      channel.catchupAccountId = accountId;
      if (!channel.catchupSource) {
        channel.catchup = 'xtream';
        channel.catchupSource = xtreamCatchupSource(credentials, streamId, output);
        channel.catchupDays = stream.archiveDurationDays;
        enabled++;
      }
      if (clock?.timeZone) channel.catchupTimeZone = clock.timeZone;
      if (clock?.offsetMinutes != null) channel.catchupTimeOffsetMinutes = clock.offsetMinutes;
    }
    log.info(
      'Xtream catch-up matching completed',
      'event=xtream.catchup.matched',
      `streams=${streams.length}`,
      `archived=${archived.size}`,
      `enabled=${enabled}`,
      `unmatched=${unmatched}`,
    );
    if (unmatched) {
      log.warn(
        'Xtream catch-up streams could not be matched',
        'event=xtream.catchup.unmatched',
        `channels=${unmatched}`,
      );
    }
  }

  /**
   * Rebuild `channels` from `allChannels` through the user's customization:
   * hidden channels drop out, the rest take the custom order, and renames and
   * group assignments are applied to the channel objects. Cheap enough to re-run
   * after every edit — no network, no re-parse.
   */
  applyCustomization(): void {
    const includeHidden = this.includeHidden || StorageService.getShowHiddenChannels();
    this.channels = ChannelCustomizationService.applyTo(this.allChannels, includeHidden);
    this.buildDerivedIndexes();
  }

  /**
   * The channels the EPG is fetched and retained for. Edit mode and the
   * "show hidden" setting both widen `channels`, and a widened selection
   * forces an EPG refetch — so the guide follows the visible selection alone
   * and stays stable across those two toggles.
   */
  getEpgEligibleChannels(): Channel[] {
    if (!this.includeHidden && !StorageService.getShowHiddenChannels()) return this.channels;
    return ChannelCustomizationService.applyTo(this.allChannels, false);
  }

  /** Edit mode reveals hidden channels so they can be un-hidden again. */
  setIncludeHidden(include: boolean): void {
    if (this.includeHidden === include) return;
    this.includeHidden = include;
    this.applyCustomization();
  }

  private buildDerivedIndexes(): void {
    const groupSet = new Set<string>();
    const groupSetsByPlaylist = new Map<string, Set<string>>();
    this.indexMap = new Map();
    this.channelsByGroup = new Map();
    this.channelsByPlaylist = new Map();
    this.channelsByPlaylistGroup = new Map();
    this.groupKeyByDisplay = new Map();
    this.channelByKey = new Map();
    this.channelByLegacyKey = new Map();
    this.channelSearchIndex = [];
    this.channelSearchByPlaylist = new Map();
    this.searchIndexedChannels = null;
    this.searchIndexedChannelCount = -1;

    for (const key of ChannelCustomizationService.customGroups) {
      this.groupKeyByDisplay.set(ChannelCustomizationService.groupLabel(key), key);
    }

    for (let i = 0; i < this.channels.length; i++) {
      const ch = this.channels[i];
      this.indexMap.set(ch, i);
      this.channelByKey.set(channelKey(ch), ch);
      const legacyKey = legacyChannelKey(ch);
      this.channelByLegacyKey.set(
        legacyKey,
        this.channelByLegacyKey.has(legacyKey) ? null : ch,
      );
      if (ch.group) {
        groupSet.add(ch.group);
        if (!this.groupKeyByDisplay.has(ch.group)) {
          this.groupKeyByDisplay.set(ch.group, groupKeyOf(ch));
        }
        this.appendIndexed(this.channelsByGroup, ch.group, ch);
      }
      for (const playlistId of ch.playlistIds) {
        this.appendIndexed(this.channelsByPlaylist, playlistId, ch);
        if (!ch.group) continue;
        let byGroup = this.channelsByPlaylistGroup.get(playlistId);
        if (!byGroup) {
          byGroup = new Map();
          this.channelsByPlaylistGroup.set(playlistId, byGroup);
        }
        this.appendIndexed(byGroup, ch.group, ch);
        let playlistGroups = groupSetsByPlaylist.get(playlistId);
        if (!playlistGroups) {
          playlistGroups = new Set();
          groupSetsByPlaylist.set(playlistId, playlistGroups);
        }
        playlistGroups.add(ch.group);
      }
    }
    for (const key of ChannelCustomizationService.customGroups) {
      const label = ChannelCustomizationService.groupLabel(key);
      groupSet.add(label);
      this.groupKeyByDisplay.set(label, key);
    }
    this.groups = this.orderGroups(Array.from(groupSet));
    this.groupsByPlaylist = new Map();
    groupSetsByPlaylist.forEach((playlistGroups, playlistId) => {
      this.groupsByPlaylist.set(playlistId, this.orderGroups(Array.from(playlistGroups)));
    });
    this.indexedChannels = this.channels;
    this.indexedChannelCount = this.channels.length;
    this.groupsRevision++;
  }

  private appendIndexed<T>(map: Map<string, T[]>, key: string, channel: T): void {
    const existing = map.get(key);
    if (existing) existing.push(channel);
    else map.set(key, [channel]);
  }

  private ensureDerivedIndexes(): void {
    if (this.indexedChannels !== this.channels || this.indexedChannelCount !== this.channels.length) {
      this.buildDerivedIndexes();
    }
  }

  private ensureLocalSearchIndexes(): void {
    this.ensureDerivedIndexes();
    if (this.searchIndexedChannels === this.channels
        && this.searchIndexedChannelCount === this.channels.length) return;
    this.channelSearchIndex = [];
    this.channelSearchByPlaylist = new Map();
    for (const channel of this.channels) {
      const searchItem = prepareSearchItem(
        channel,
        item => [item.name, item.group, item.sourceName ?? ''],
      );
      this.channelSearchIndex.push(searchItem);
      for (const playlistId of channel.playlistIds) {
        this.appendIndexed(this.channelSearchByPlaylist, playlistId, searchItem);
      }
    }
    this.searchIndexedChannels = this.channels;
    this.searchIndexedChannelCount = this.channels.length;
  }

  /** Sort display group names into the custom group order (keyed by group key). */
  private orderGroups(displayNames: string[]): string[] {
    return displayNames
      .map((name, index) => ({
        name,
        rank: ChannelCustomizationService.groupRank(
          this.groupKeyByDisplay.get(name) ?? name,
          index,
        ),
        index,
      }))
      .sort((a, b) => a.rank - b.rank || a.index - b.index)
      .map((entry) => entry.name);
  }

  private buildPlaylistTabs(): void {
    // One tab per configured playlist, in config order, keyed by its stable id —
    // including a playlist that loaded zero channels (empty/unreachable feed), so
    // it stays visible. Derived from the registry, not the cached channels, so a
    // stale/desynced channel cache can never blank out the tab bar.
    const configured = StorageService.getPlaylists().filter(isSourceEnabled);
    this.playlistTabs = configured.map(pl => ({ id: pl.id, name: pl.name || pl.url }));
  }

  getByGroup(group: ChannelGroupId, playlist?: string): Channel[] {
    this.ensureDerivedIndexes();
    const all = playlist ? this.channelsByPlaylist.get(playlist) ?? [] : this.channels;
    if (group === 'builtin:all' || group === 'builtin:recently-watched') return all;
    if (group === 'builtin:favorites') {
      const favorites = StorageService.getFavorites()
        .map(key => this.channelByKey.get(key))
        .filter((channel): channel is Channel =>
          !!channel && (!playlist || channel.playlistIds.includes(playlist)));
      favorites.sort((a, b) => this.indexOf(a) - this.indexOf(b));
      return favorites;
    }
    const sourceGroup = group.slice('source:'.length);
    return playlist
      ? this.channelsByPlaylistGroup.get(playlist)?.get(sourceGroup) ?? []
      : this.channelsByGroup.get(sourceGroup) ?? [];
  }

  getGroupCount(group: ChannelGroupId, playlist?: string): number {
    this.ensureDerivedIndexes();
    if (group === 'builtin:all' || group === 'builtin:recently-watched') {
      return playlist ? this.channelsByPlaylist.get(playlist)?.length ?? 0 : this.channels.length;
    }
    if (group === 'builtin:favorites') return this.getByGroup(group, playlist).length;
    const sourceGroup = group.slice('source:'.length);
    return playlist
      ? this.channelsByPlaylistGroup.get(playlist)?.get(sourceGroup)?.length ?? 0
      : this.channelsByGroup.get(sourceGroup)?.length ?? 0;
  }

  searchLocalRanked(
    query: string,
    limit: number,
    playlist?: string,
  ): RankedSearchResult<Channel> {
    if (!query.trim()) return { items: [], hasMore: false };
    this.ensureLocalSearchIndexes();
    const index = playlist
      ? this.channelSearchByPlaylist.get(playlist) ?? []
      : this.channelSearchIndex;
    return rankPreparedTopK(index, query, limit);
  }

  getGroupsForPlaylist(playlist?: string): string[] {
    this.ensureDerivedIndexes();
    return (playlist ? this.groupsByPlaylist.get(playlist) ?? [] : this.groups).slice();
  }

  getGroupKeyForDisplay(display: string): string {
    this.ensureDerivedIndexes();
    return this.groupKeyByDisplay.get(display) ?? display;
  }

  getByIndex(index: number): Channel | null {
    return this.channels[index] ?? null;
  }

  indexOf(channel: Channel): number {
    return this.indexMap.get(channel) ?? -1;
  }

  resolveChannelKey(key: string): { channel: Channel; channelIndex: number } | null {
    const channel = this.channelByKey.get(key) ?? this.channelByLegacyKey.get(key);
    if (!channel) return null;
    const channelIndex = this.indexOf(channel);
    return channelIndex < 0 ? null : { channel, channelIndex };
  }

  /** Index of the channel carrying this per-stream key, or -1. Used to re-resolve
   *  the playing channel after a customization changes the ordering. */
  indexOfKey(key: string): number {
    if (!key) return -1;
    for (let i = 0; i < this.channels.length; i++) {
      if (channelKey(this.channels[i]) === key) return i;
    }
    return -1;
  }

  private indexOfUniqueKey(key: string): number {
    let match = -1;
    for (let i = 0; i < this.channels.length; i++) {
      const channel = this.channels[i];
      if (channelKey(channel) !== key && legacyChannelKey(channel) !== key) continue;
      if (match >= 0) return -1;
      match = i;
    }
    return match;
  }

  resolveLastChannelIndex(stableKey: string, legacyIndex: number): number {
    if (!stableKey) return legacyIndex;
    return this.indexOfUniqueKey(stableKey);
  }
}

export const PlaylistService = new PlaylistServiceImpl();

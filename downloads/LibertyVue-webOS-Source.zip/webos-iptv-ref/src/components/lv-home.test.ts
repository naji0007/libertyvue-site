// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { LvHome } from './lv-home';
import { PlaylistService } from '../services/playlist-service';
import { StorageService } from '../services/storage-service';

function setup(channels: { name: string; radio?: boolean }[] = []) {
  document.body.innerHTML = '<div id="home"></div>';
  const el = document.getElementById('home')!;
  vi.spyOn(PlaylistService, 'channels', 'get').mockReturnValue(channels as never);
  const onSelect = vi.fn();
  const onOpenSettings = vi.fn();
  const home = new LvHome(el, { onSelect, onOpenSettings });
  return { el, home, onSelect, onOpenSettings };
}

describe('LvHome', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
    Element.prototype.scrollIntoView = vi.fn() as never;
  });

  it('renders six folder tiles with live and radio counts', () => {
    const { el, home } = setup([
      { name: 'A' },
      { name: 'B' },
      { name: 'R', radio: true },
    ]);
    home.render();
    expect(el.querySelectorAll('.lv-tile, .lv-small').length).toBe(6);
    expect(el.textContent).toContain('3 channels');
    expect(el.textContent).toContain('1 stations');
  });

  it('selects the live section when its tile is clicked', () => {
    const { el, home, onSelect } = setup();
    home.render();
    const tile = el.querySelector<HTMLElement>('[data-home-section="live"]')!;
    tile.click();
    expect(onSelect).toHaveBeenCalledWith('live');
  });

  it('opens settings from the settings tile', () => {
    const { el, home, onOpenSettings } = setup();
    home.render();
    el.querySelector<HTMLElement>('[data-home-settings]')!.click();
    expect(onOpenSettings).toHaveBeenCalled();
  });

  it('shows the device id so it can be given to a reseller', () => {
    StorageService.setPlaylists([]);
    const { el, home } = setup();
    home.render();
    expect(el.textContent).toMatch(/LV-[0-9A-F]{5}-[0-9A-F]{5}/);
  });

  it('routes arrows and select through spatial nav', () => {
    const { home } = setup([{ name: 'A' }]);
    home.render();
    expect(home.handleAction('down')).toBe(true);
    expect(home.handleAction('bogus' as never)).toBe(false);
  });
});

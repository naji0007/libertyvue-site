import type { Action } from '../types';
import type { Section } from './tab-bar';
import { html, raw } from '../utils/dom';
import { SpatialNav } from '../navigation/spatial-nav';
import { PlaylistService } from '../services/playlist-service';
import { StorageService } from '../services/storage-service';
import { getDeviceCredentials, getEffectiveLicense } from '../services/libertyvue-sync';
import { t } from '../i18n';
import { createLogger } from '../utils/logger';
import {
  APPEARANCE_ICON,
  GUIDE_ICON,
  PLAYBACK_ICON,
  SOURCES_ICON,
  SUBTITLE_ICON,
  VOLUME_ICON,
} from './icons';

const log = createLogger('LvHome');

export interface LvHomeHandlers {
  onSelect(section: Section): void;
  onOpenSettings(): void;
}

/** LibertyVue home dashboard: big section folders (Live / Films / Series)
 *  plus Radio, Guide and Settings — the Android-style landing. */
export class LvHome {
  private nav: SpatialNav;
  private updatedAt = 0;

  constructor(
    private container: HTMLElement,
    private handlers: LvHomeHandlers,
  ) {
    this.nav = new SpatialNav(container, () => {});
    this.container.addEventListener('click', (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const tile = target.closest<HTMLElement>('[data-home-section]');
      if (tile?.dataset.homeSection) {
        this.handlers.onSelect(tile.dataset.homeSection as Section);
        return;
      }
      if (target.closest('[data-home-settings]')) this.handlers.onOpenSettings();
    });
  }

  setUpdatedAt(ts: number): void {
    this.updatedAt = ts;
  }

  refresh(): void {
    this.render();
  }

  focusFirst(): void {
    this.nav.focusFirst();
  }

  handleAction(action: Action): boolean {
    if (action === 'up' || action === 'down' || action === 'left' || action === 'right') {
      return this.nav.move(action);
    }
    if (action === 'select') {
      const focused = this.nav.focused;
      if (focused) focused.click();
      return true;
    }
    return false;
  }

  render(): void {
    const device = getDeviceCredentials();
    const channels = PlaylistService.channels;
    const liveCount = channels.length;
    let radioCount = 0;
    for (const ch of channels) if (ch.radio) radioCount++;
    const updated = this.updatedAt
      ? new Date(this.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : '…';
    const accountName = this.accountName();
    const licence = getEffectiveLicense();
    const licenceText =
      licence.label === 'active'
        ? t('settings.libertyvueLicenceActive')
        : licence.label === 'trial'
          ? t('settings.libertyvueTrial', { days: licence.daysLeft ?? 7 })
          : t('settings.libertyvueExpired');
    const today = new Date().toLocaleDateString([], { day: '2-digit', month: 'short' });

    this.container.innerHTML = String(html`
      <div class="lv-home">
        <div class="lv-home-head">
          <div class="lv-brand"><span class="lv-badge">LV</span>
            <span class="lv-brand-text">LibertyVue<small>PLAYER</small></span>
          </div>
          <span class="lv-date">${today}</span>
        </div>
        <div class="lv-tiles-big">
          ${this.tile('live', 'lv-tile-gold', raw(PLAYBACK_ICON), t('nav.live'), t('home.channels', { count: liveCount }), true)}
          ${this.tile('movies', '', raw(SUBTITLE_ICON), t('nav.movies'), '…', false)}
          ${this.tile('series', '', raw(SOURCES_ICON), t('nav.series'), '…', false)}
        </div>
        <div class="lv-tiles-small">
          ${this.smallTile('live', raw(VOLUME_ICON), t('home.radio'), t('home.stations', { count: radioCount }))}
          ${this.smallTile('epg', raw(GUIDE_ICON), t('nav.epg'), '')}
          ${this.smallTile('__settings', raw(APPEARANCE_ICON), t('nav.settings'), '')}
        </div>
        <div class="lv-foot">
          <span>${t('home.updatedAt', { time: updated })}</span>
          <span class="lv-device">ID ${device.id} · Key ${device.key}</span>
          <span class="lv-connected">${t('home.connectedTo', { name: accountName })} · ${licenceText}</span>
        </div>
      </div>
    `);
    log.debug('LvHome rendered', 'event=lv.home.render', 'channels=' + liveCount);
  }

  private tile(section: Section, cls: string, icon: unknown, label: string, sub: string, first: boolean): unknown {
    return html`
      <button class="lv-tile ${cls}" data-focusable data-home-section="${section}" data-key="lv-${section}${first ? '' : '-x'}">
        <span class="lv-tile-icon">${icon}</span>
        <span class="lv-tile-label">${label}</span>
        <span class="lv-tile-sub">${sub}</span>
      </button>`;
  }

  private smallTile(target: Section | '__settings', icon: unknown, label: string, sub: string): unknown {
    const attr = target === '__settings' ? 'data-home-settings' : `data-home-section="${target}"`;
    return html`
      <button class="lv-small" data-focusable ${attr} data-key="lv-${target}">
        <span class="lv-small-icon">${icon}</span>
        <span><span class="lv-small-label">${label}</span>${sub ? html`<span class="lv-small-sub">${sub}</span>` : ''}</span>
      </button>`;
  }

  private accountName(): string {
    const playlists = StorageService.getPlaylists();
    const selId = StorageService.getSelectedXtreamAccountId();
    const sel = playlists.find((p) => p.id === selId) ?? playlists[0];
    return sel?.name || sel?.url || '…';
  }
}

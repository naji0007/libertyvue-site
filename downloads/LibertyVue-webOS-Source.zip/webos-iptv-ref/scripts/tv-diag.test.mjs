// @vitest-environment jsdom
// jsdom, because the active probe is stringified and evaluated inside the
// TV's webview; every other case here is a pure function.
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { execFileSync } from 'node:child_process';
import { EventEmitter } from 'node:events';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import {
  DiagnosticRedactor,
  assembleDiagnosticReport,
  captureDiagnostics,
  extractDiagnosticTimeline,
  extractInputTimeline,
  extractXtreamTimeline,
  normalizeNetworkRecords,
  parseNativeMetricOutput,
  parseDiagnosticArgs,
  activeProbeExpression,
  snapshotProbeExpression,
  formatDiagnosticSummary,
  runNativeProbe,
  runNativePlaylistProbe,
  inspectorWebSocketUrl,
  startAresInspector,
  startNativeMetricWindow,
} from './tv-diag.mjs';

describe('tv-diag arguments', () => {
  it('parses capture and render options', () => {
    expect(parseDiagnosticArgs([
      '--app', 'app.id',
      '--device', 'tv',
      '--timeout', '45',
      '--attach',
      '--duration', '25',
      '--output', 'report.json',
      '--full',
    ])).toMatchObject({
      appId: 'app.id',
      device: 'tv',
      timeoutMs: 45000,
      durationMs: 25000,
      attach: true,
      outputPath: 'report.json',
      full: true,
    });

    expect(parseDiagnosticArgs(['--summary', 'report.json']).summaryPath).toBe('report.json');
  });

  it('rejects invalid options', () => {
    expect(() => parseDiagnosticArgs(['--port', '0'])).toThrow('Invalid value for --port');
    expect(() => parseDiagnosticArgs(['--play-channel', '1.5']))
      .toThrow('Invalid value for --play-channel');
    expect(() => parseDiagnosticArgs(['--attach', '--play-channel', '0']))
      .toThrow('--attach cannot be combined with --play-channel');
    expect(() => parseDiagnosticArgs(['--attach', '--duration', '0']))
      .toThrow('Invalid value for --duration');
    expect(() => parseDiagnosticArgs(['--duration', '20']))
      .toThrow('--duration requires --attach or --play-channel');
    expect(() => parseDiagnosticArgs(['--unknown'])).toThrow('Unknown option');
  });
});

describe('ares-inspect lifecycle', () => {
  it('extracts the page WebSocket from inspector output', () => {
    expect(inspectorWebSocketUrl(
      'Application Debugging - http://localhost:62090/devtools/inspector.html'
      + '?ws=localhost:62090/devtools/page/ABC',
    )).toBe('ws://localhost:62090/devtools/page/ABC');
  });

  describe('native playback metrics', () => {
    const output = [
      '@ticks|before|100',
      '@proc|before|1|umediaserver|10|5|1000|2|1000000|2000000|500|0|2000|1800|1600|700|300|0|100',
      '@proc|before|3|starfish|5|5|50000|3|1000000|1000000|900|100|90000|80000|70000|40000|10000|0|5000',
      '@proc|before|4|webapp|10|5|80000|15|1000000|2000000|888|300|635084|535380|182884|40536|41644|84|4268',
      '@psi|before|cpu|0.10|1000',
      '@psi|before|memory|0.00|2000',
      '@psi|before|io|0.00|3000',
      '@net|before|1000|2000',
      '@tcp|before|4',
      '@mem|before|1000000|400000|200000|100000',
      '@mm|before|normal|normal|596|1',
      '@oom-access|before|1',
      '@oom|before|old oom record',
      '@native-ready',
      '@peak|1|1|umediaserver|1500|3',
      '@peak|1|3|starfish|70000|4',
      '@peak|1|4|webapp|90000|16',
      '@mem-sample|1|300000|90000',
      '@ticks|after|100',
      '@proc|after|1|umediaserver|20|10|1200|3|4000000|7000000|550|0|2100|1900|1700|800|400|0|90',
      '@proc|after|2|starfish|40|10|14000|5|8000000|9000000|700|50|30000|25000|20000|10000|4000|0|1000',
      '@proc|after|4|webapp|20|10|85000|16|4000000|7000000|890|300|640000|540000|185000|43000|41900|100|5000',
      '@psi|after|cpu|0.20|4000',
      '@psi|after|memory|0.00|2000',
      '@psi|after|io|0.01|5000',
      '@net|after|1500|2700',
      '@tcp|after|6',
      '@mem|after|1000000|350000|200000|95000',
      '@mm|after|low|normal|280|1',
      '@oom-access|after|1',
      '@oom|after|old oom record',
      '@oom|after|Out of memory: Killed process 3 (starfish)',
    ].join('\n');

    it('calculates process, pressure, network, and retransmit deltas', () => {
      const metrics = parseNativeMetricOutput(output, 10000);
      expect(metrics).toMatchObject({
        durationMs: 10000,
        network: { rxBytes: 500, txBytes: 700 },
        tcpRetransmits: 2,
        pressure: {
          cpu: { avg10: 0.2, stallMs: 3 },
          memory: { avg10: 0, stallMs: 0 },
          io: { avg10: 0.01, stallMs: 2 },
        },
        memory: {
          totalKb: 1000000,
          availableBeforeKb: 400000,
          availableAfterKb: 350000,
          minimumAvailableKb: 300000,
          usedBeforeKb: 600000,
          usedAfterKb: 650000,
          maximumUsedKb: 700000,
          swapTotalKb: 200000,
          swapFreeBeforeKb: 100000,
          swapFreeAfterKb: 95000,
          minimumSwapFreeKb: 90000,
        },
        oomLogAvailable: true,
        oomEvents: ['Out of memory: Killed process 3 (starfish)'],
        appMemory: {
          processCountBefore: 1,
          processCountAfter: 1,
          rssBeforeKb: 80000,
          rssAfterKb: 85000,
          peakObservedRssKb: 90000,
          lifetimeHighWaterKb: 185000,
          virtualSizeAfterKb: 540000,
          anonymousRssAfterKb: 43000,
          fileRssAfterKb: 41900,
          sharedRssAfterKb: 100,
          swapAfterKb: 5000,
          percentOfSystemAtPeak: 9,
        },
        memoryManager: {
          available: true,
          levelBefore: 'normal',
          levelAfter: 'low',
          previousLevelBefore: 'normal',
          previousLevelAfter: 'normal',
          usableBeforeMb: 596,
          usableAfterMb: 280,
          minimumUsableMb: 280,
        },
      });
      expect(metrics.processes).toEqual([
        expect.objectContaining({
          pid: 1,
          kind: 'umediaserver',
          startedDuringWindow: false,
          cpuPercent: 1.5,
          schedulerWaitMs: 5,
          initialRssKb: 1000,
          peakRssKb: 1500,
          initialOomScore: 500,
          oomScore: 550,
        }),
        expect.objectContaining({
          pid: 2,
          kind: 'starfish',
          startedDuringWindow: true,
          cpuPercent: 5,
          initialRssKb: null,
          peakRssKb: 14000,
          oomScore: 700,
        }),
        expect.objectContaining({
          pid: 4,
          kind: 'webapp',
          initialRssKb: 80000,
          rssKb: 85000,
          peakRssKb: 90000,
          vmHwmKb: 185000,
          swapKb: 5000,
        }),
      ]);
      expect(metrics.stoppedProcesses).toEqual([
        expect.objectContaining({
          pid: 3,
          kind: 'starfish',
          initialRssKb: 50000,
          peakRssKb: 70000,
          peakThreads: 4,
          initialOomScore: 900,
          oomScoreAdj: 100,
        }),
      ]);
    });

    it('waits for the remote baseline before resolving readiness', async () => {
      const child = new EventEmitter();
      child.stdout = new EventEmitter();
      child.stderr = new EventEmitter();
      child.killed = false;
      child.kill = () => { child.killed = true; };
      const session = startNativeMetricWindow(10000, {
        spawn: (_file, args) => {
          expect(args[1]).toContain('WebAppMgr');
          expect(args[1]).toContain("app_id='com.lennylxx.iptv'");
          expect(args[1]).toContain('*"--app-id=$app_id"*');
          expect(args[1]).toContain('/proc/$p/oom_score');
          expect(args[1]).toContain('MemAvailable');
          expect(args[1]).toContain('dmesg');
          expect(args[1]).toContain('com.webos.memorymanager/getCurrentMemState');
          expect(args[1]).toContain('new pb.Handle');
          return child;
        },
        timeoutMs: 1000,
      });
      child.stdout.emit('data', `${output}\n`);
      await session.ready;
      child.emit('close', 0);
      expect(await session.result).toMatchObject({
        network: { rxBytes: 500, txBytes: 700 },
        tcpRetransmits: 2,
      });
    });
  });

  it('starts a persistent inspector without waiting for process exit', async () => {
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stderr = new EventEmitter();
    child.killed = false;
    child.kill = () => { child.killed = true; };
    const inspector = startAresInspector('app.id', 'tv', {
      spawn: () => child,
      timeoutMs: 1000,
    });
    child.stdout.emit(
      'data',
      'http://localhost:62090/devtools/inspector.html?ws=localhost:62090/devtools/page/ABC',
    );
    expect(await inspector.wsUrl).toBe('ws://localhost:62090/devtools/page/ABC');
    expect(child.killed).toBe(false);
    inspector.close();
    expect(child.killed).toBe(true);
  });
});

describe('DiagnosticRedactor', () => {
  it('preserves URL shape while replacing hosts and credentials', () => {
    const redactor = new DiagnosticRedactor({ secrets: ['user1', 'pass1'] });
    const first = redactor.url('http://host:8080/live/user1/pass1/7.ts?token=abc&output=m3u8');
    const second = redactor.url('http://host:8080/get.php?username=user1&password=pass1');

    expect(first).toContain('http://<host-a>:8080/live/');
    expect(first).toContain('output=m3u8');
    expect(second).toContain('http://<host-a>:8080/get.php');
    expect(first).not.toContain('user1');
    expect(first).not.toContain('pass1');
    expect(first).not.toContain('abc');
    expect(second).not.toContain('user1');
  });

  it('redacts credential-like path segments from plain playlist URLs', () => {
    const report = assembleDiagnosticReport({
      capturedAt: '2026-01-01T00:00:00.000Z',
      full: false,
      app: {},
      environment: {},
      probe: {
        playlists: [{
          source: 'm3u',
          name: '',
          __url: 'http://host/live/user1/pass1/7.ts',
          __secrets: [],
          webview: {},
        }],
      },
      native: [],
      logs: [],
      networkEvents: [],
    });
    const serialized = JSON.stringify(report);
    expect(serialized).not.toContain('user1');
    expect(serialized).not.toContain('pass1');
    expect(report.playlists[0].url).toContain('/live/');
  });

  it('keeps a synthetic playlist filename while redacting parent path tokens', () => {
    const report = assembleDiagnosticReport({
      capturedAt: '2026-01-01T00:00:00.000Z',
      full: false,
      app: {},
      environment: {},
      probe: {
        playlists: [{
          source: 'm3u',
          name: '',
          __url: 'http://host/private/playlist.m3u',
          __secrets: [],
          webview: {},
        }],
      },
      native: [],
      logs: [],
      networkEvents: [],
    });
    expect(report.playlists[0].url).toContain('/~redacted-7-alnum~/playlist.m3u');
  });

  it('redacts media filenames that can reveal channel names', () => {
    const redactor = new DiagnosticRedactor();
    const url = redactor.url('http://host/play/Alpha.m3u8');
    expect(url).not.toContain('Alpha');
    expect(url).toContain('/~redacted-10-mixed~');
  });

  it('redacts credentials and URLs embedded in text', () => {
    const redactor = new DiagnosticRedactor({ secrets: ['pass1'] });
    const text = redactor.text('failed http://host/a?password=pass1 token=pass1');
    expect(text).toContain('<host-a>');
    expect(text).not.toContain('pass1');
  });

  it('leaves values untouched in full mode', () => {
    const redactor = new DiagnosticRedactor({ full: true, secrets: ['pass1'] });
    expect(redactor.url('http://host/a?password=pass1')).toBe('http://host/a?password=pass1');
  });
});

describe('diagnostic report assembly', () => {
  it('parses the native curl preview marker', () => {
    let command = '';
    const result = runNativeProbe('http://host/a', {
      execFile: (_file, args) => {
        command = args[1];
        return "\rEnter passphrase for key '/home/user/.ssh/key': \r\n"
          + '#EXTM3U\n__IPTV_DIAG__206|text/plain';
      },
    });
    expect(command).toContain('temp_root=/media/developer/temp');
    expect(command).toContain('temp_root=/tmp');
    expect(command).toContain('--range 0-2047');
    expect(command).toContain('| head -c 2048 > "$body"');
    expect(command).toContain('[ "$rc" -eq 23 ] && [ "$size" -eq 2048 ]');
    expect(command).not.toContain('-o "$body"');
    expect(result).toEqual({
      status: 206,
      contentType: 'text/plain',
      bodyPreview: '#EXTM3U',
      error: '',
    });
  });

  it('bounds native previews when the server ignores Range', () => {
    const bin = mkdtempSync(path.join(tmpdir(), 'tv-diag-native-'));
    try {
      writeFileSync(path.join(bin, 'node'), '#!/bin/sh\nprintf 12\n', { mode: 0o755 });
      writeFileSync(path.join(bin, 'curl'), `#!/bin/sh
headers=
while [ "$#" -gt 0 ]; do
  case "$1" in
    -D) headers="$2"; shift 2 ;;
    *) shift ;;
  esac
done
printf 'HTTP/1.1 200 OK\\r\\nContent-Type: text/plain\\r\\nContent-Length: 4096\\r\\n\\r\\n' > "$headers"
head -c 4096 /dev/zero
exit 23
`, { mode: 0o755 });

      const result = runNativeProbe('http://host/a', {
        execFile: (_file, args, options) => execFileSync('/bin/sh', ['-c', args[1]], {
          ...options,
          env: { ...process.env, PATH: `${bin}:${process.env.PATH}` },
        }),
      }, 15_000);

      expect(result.status).toBe(200);
      expect(result.contentType).toBe('text/plain');
      expect(result.bodyPreview).toHaveLength(2048);
      expect(result.error).toBe('');
    } finally {
      rmSync(bin, { recursive: true, force: true });
    }
  });

  it('normalizes network events without request headers', () => {
    const redactor = new DiagnosticRedactor();
    const records = normalizeNetworkRecords([
      {
        method: 'Network.requestWillBeSent',
        observedAt: '2026-01-01T00:00:00.000Z',
        params: { requestId: '1', request: { method: 'GET', url: 'http://host/a?token=abc' } },
      },
      {
        method: 'Network.responseReceived',
        observedAt: '2026-01-01T00:00:01.000Z',
        params: {
          requestId: '1',
          response: {
            status: 200,
            url: 'http://host/a?token=abc',
            mimeType: 'text/plain',
            headers: { 'Content-Type': 'text/plain', Authorization: 'secret' },
          },
        },
      },
      {
        method: 'Network.loadingFinished',
        observedAt: '2026-01-01T00:00:02.000Z',
        params: { requestId: '1', encodedDataLength: 42 },
      },
    ], redactor);

    expect(records).toHaveLength(1);
    expect(records[0]).toMatchObject({
      method: 'GET',
      status: 200,
      mimeType: 'text/plain',
      headers: { 'content-type': 'text/plain' },
      encodedBytes: 42,
      durationMs: 2000,
    });
    expect(records[0].url).not.toContain('abc');
    expect(records[0].headers).not.toHaveProperty('authorization');
  });

  it('extracts stable diagnostic events with optional context fields', () => {
    const timeline = extractDiagnosticTimeline([
      {
        observedAt: '2026-01-01T00:00:00.000Z',
        source: 'console',
        level: 'log',
        text: '[Player] event=playback.path.native session=3 load=2 reason=probe',
      },
      {
        observedAt: '2026-01-01T00:00:01.000Z',
        source: 'console',
        level: 'warning',
        text: '[EPG] event=epg.mapping.stale count=2 reason=missing_channel',
      },
      {
        observedAt: '2026-01-01T00:00:02.000Z',
        source: 'console',
        level: 'error',
        text: '[AppWorker] event=worker.lifecycle.failed'
          + ' generation=2 active=1 reason=execution_error',
      },
      {
        observedAt: '2026-01-01T00:00:03.000Z',
        source: 'console',
        level: 'log',
        text: '[M3ULoad] event=playlist.m3u.load.failed stage=decode_parse'
          + ' reason=exception transport=stream filter=live_catalog'
          + ' bytes=16777216 chunks=64 kept=8192 dropped=12000 elapsedMs=4500',
      },
      {
        observedAt: '2026-01-01T00:00:04.000Z',
        source: 'console',
        level: 'log',
        text: '[Player] ordinary log',
      },
    ]);
    expect(timeline).toEqual([
      expect.objectContaining({
        code: 'playback.path.native',
        session: 3,
        load: 2,
      }),
      expect.objectContaining({
        code: 'epg.mapping.stale',
        session: null,
        load: null,
        count: 2,
        reason: 'missing_channel',
      }),
      expect.objectContaining({
        code: 'worker.lifecycle.failed',
        generation: 2,
        active: 1,
        reason: 'execution_error',
      }),
      expect.objectContaining({
        code: 'playlist.m3u.load.failed',
        stage: 'decode_parse',
        transport: 'stream',
        filter: 'live_catalog',
        bytes: 16777216,
        chunks: 64,
        kept: 8192,
        dropped: 12000,
        elapsedMs: 4500,
      }),
    ]);
  });

  it('extracts remote-control input events into their own timeline', () => {
    const logs = [
      {
        observedAt: '2026-01-01T00:00:00.000Z',
        source: 'console',
        level: 'log',
        text: '[Key] Key down event=key.down code=52 action=number target=app',
      },
      {
        observedAt: '2026-01-01T00:00:00.500Z',
        source: 'console',
        level: 'log',
        text: '[Key] Number entry event=key.number number=42 handler=set',
      },
      {
        observedAt: '2026-01-01T00:00:00.600Z',
        source: 'console',
        level: 'log',
        text: '[App] Key routed event=key.action action=number'
          + ' view=player consumer=view_player number=42',
      },
      {
        observedAt: '2026-01-01T00:00:00.700Z',
        source: 'console',
        level: 'log',
        text: '[Key] Key down event=key.down code=999 action=unmapped target=app',
      },
      {
        observedAt: '2026-01-01T00:00:00.800Z',
        source: 'console',
        level: 'log',
        text: '[Key] Key ignored event=key.ignored reason=text_input',
      },
      {
        observedAt: '2026-01-01T00:00:01.000Z',
        source: 'console',
        level: 'log',
        text: '[Player] event=playback.path.native session=1 load=1',
      },
    ];

    expect(extractInputTimeline(logs)).toEqual([
      expect.objectContaining({ event: 'key.down', code: 52, action: 'number' }),
      expect.objectContaining({ event: 'key.number', number: 42 }),
      expect.objectContaining({
        event: 'key.action',
        action: 'number',
        view: 'player',
        consumer: 'view_player',
        number: 42,
      }),
      expect.objectContaining({
        event: 'key.down', code: 999, action: 'unmapped', target: 'app',
      }),
      expect.objectContaining({ event: 'key.ignored', reason: 'text_input', code: null }),
    ]);

    // Input stays out of the playback timeline: a press per line would bury it.
    expect(extractDiagnosticTimeline(logs)).toEqual([
      expect.objectContaining({ code: 'playback.path.native' }),
    ]);
  });

  it('extracts structured Xtream request failures from natural-language logs', () => {
    const timeline = extractXtreamTimeline([
      {
        observedAt: '2026-01-01T00:00:00.000Z',
        source: 'console',
        level: 'warning',
        text: '[Xtream] Xtream request failed event=xtream.request.failed'
          + ' endpoint=get_vod_streams operation=browse resource=vod_streams'
          + ' reason=request_failed code=too_large items=12'
          + ' timeoutMs=30000 limitBytes=33554432',
      },
      {
        observedAt: '2026-01-01T00:00:01.000Z',
        source: 'console',
        level: 'log',
        text: '[Playlist] event=xtream.live_catalog.completed'
          + ' load=2 available=1 items=32000 elapsedMs=4100',
      },
      {
        observedAt: '2026-01-01T00:00:02.000Z',
        source: 'console',
        level: 'log',
        text: '[Xtream] ordinary log',
      },
    ]);
    expect(timeline).toEqual([expect.objectContaining({
      event: 'xtream.request.failed',
      endpoint: 'get_vod_streams',
      operation: 'browse',
      resource: 'vod_streams',
      reason: 'request_failed',
      code: 'too_large',
      items: 12,
      timeoutMs: 30000,
      limitBytes: 33554432,
    }), expect.objectContaining({
      event: 'xtream.live_catalog.completed',
      load: 2,
      available: 1,
      items: 32000,
      elapsedMs: 4100,
    })]);
  });

  it('formats parser, worker, catalog, and cache lifecycle fields', () => {
    const diagnostics = extractDiagnosticTimeline([
      {
        observedAt: '2026-01-01T00:00:00.000Z',
        source: 'console',
        level: 'log',
        text: '[AppWorker] event=worker.task.completed task=xmltv.load'
          + ' generation=3 batches=257 progress=8 elapsedMs=9000',
      },
      {
        observedAt: '2026-01-01T00:00:01.000Z',
        source: 'console',
        level: 'log',
        text: '[CacheStorage] event=playlist.cache.write.started'
          + ' channels=38000 epg=2 delayMs=1300',
      },
    ]);
    const summary = formatDiagnosticSummary({
      capturedAt: '2026-01-01T00:00:02.000Z',
      app: {},
      environment: {},
      state: {},
      playlists: [],
      diagnostics,
      input: [],
      xtream: [],
      logs: [],
      network: [],
    });

    expect(summary).toContain(
      'worker.task.completed generation=3 task=xmltv.load'
        + ' batches=257 progress=8 elapsedMs=9000',
    );
    expect(summary).toContain(
      'playlist.cache.write.started channels=38000 epg=2 delayMs=1300',
    );
  });

  it('does not leak probe secrets into the assembled report', () => {
    const report = assembleDiagnosticReport({
      capturedAt: '2026-01-01T00:00:00.000Z',
      full: false,
      app: { id: 'app.id', version: '1.0.0' },
      environment: { userAgent: 'ua' },
      probe: {
        state: {
          view: 'view-player',
          channelsRendered: 1,
          media: {
            src: 'http://host/live/user1/pass1/7.ts',
            sources: [{
              src: 'http://host/movie/user1/pass1/7.mkv',
              type: 'video/x-matroska',
              canPlayType: '',
            }],
            readyState: 4,
            networkState: 2,
            paused: false,
            currentTime: 12,
            error: null,
          },
          codecSupport: {
            'video/mp4': 'probably',
            'video/x-matroska': '',
          },
        },
        storage: {},
        playlists: [{
          source: 'xtream',
          name: 'Alpha',
          __url: 'http://host/get.php?username=user1&password=pass1',
          __secrets: ['user1', 'pass1'],
          webview: { status: 200, bodyPreview: '#EXTM3U pass1' },
          xtreamAuth: { auth: 1 },
        }],
      },
      native: [{ status: 200, contentType: 'text/plain', bodyPreview: '#EXTM3U user1', error: '' }],
      logs: [{
        observedAt: '2026-01-01T00:00:00.000Z',
        source: 'console',
        level: 'error',
        text: 'failed pass1',
      }, {
        observedAt: '2026-01-01T00:00:01.000Z',
        source: 'console',
        level: 'log',
        text: 'Selected native playback event=playback.path.native session=1 load=1',
      }, {
        observedAt: '2026-01-01T00:00:02.000Z',
        source: 'console',
        level: 'warning',
        text: 'Xtream request failed event=xtream.request.failed'
          + ' endpoint=get_series code=timeout timeoutMs=30000 limitBytes=33554432',
      }, {
        observedAt: '2026-01-01T00:00:03.000Z',
        source: 'console',
        level: 'warning',
        text: '[EPG] Saved mapping missing event=epg.mapping.stale'
          + ' count=2 reason=missing_channel',
      }, {
        observedAt: '2026-01-01T00:00:04.000Z',
        source: 'console',
        level: 'error',
        text: '[AppWorker] App worker failed event=worker.lifecycle.failed'
          + ' generation=2 active=1 reason=execution_error',
      }, {
        observedAt: '2026-01-01T00:00:05.000Z',
        source: 'console',
        level: 'log',
        text: '[App] Key routed event=key.action action=number'
          + ' view=player consumer=view_player number=42',
      }, {
        observedAt: '2026-01-01T00:00:06.000Z',
        source: 'console',
        level: 'warning',
        text: '[Playlist] Playlist load completed event=playlist.load.completed'
          + ' source=network channels=0 all=0 groups=0 epg=1 sources=1 failed=1',
      }],
      networkEvents: [],
    });
    const serialized = JSON.stringify(report);
    expect(report.schemaVersion).toBe(3);
    expect(report.diagnostics).toHaveLength(5);
    expect(report.input).toEqual([
      expect.objectContaining({ event: 'key.action', view: 'player', number: 42 }),
    ]);
    expect(report).not.toHaveProperty('playback');
    expect(serialized).not.toContain('user1');
    expect(serialized).not.toContain('pass1');
    expect(serialized).not.toContain('Alpha.m3u8');
    const summary = formatDiagnosticSummary(report);
    expect(summary).toContain('webview=200');
    expect(summary).toContain('playback.path.native');
    expect(summary).toContain('Diagnostic events: 5');
    expect(summary).toContain('Input events: 1');
    expect(summary).toContain(
      'key.action number=42 action=number view=player consumer=view_player',
    );
    expect(summary).toContain('epg.mapping.stale count=2 reason=missing_channel');
    expect(summary).toContain(
      'worker.lifecycle.failed generation=2 active=1 reason=execution_error',
    );
    expect(summary).toContain(
      'xtream.request.failed endpoint=get_series code=timeout'
        + ' timeoutMs=30000 limitBytes=33554432',
    );
    expect(summary).toContain('Media: playing');
    expect(summary).toContain('channels=0 (network) rendered=1');
    expect(summary).toContain('playlist.load.completed channels=0 source=network failed=1');
    expect(summary).toContain(
      'Media source: type=video/x-matroska canPlayType="" — source skipped without an error event',
    );
    expect(summary).toContain('Codec support: 1/2 playable | rejected: video/x-matroska');
  });

  it('reports catalog counts as unknown when the app exposes no snapshot', () => {
    const summary = formatDiagnosticSummary({
      capturedAt: '2026-01-01T00:00:00.000Z',
      app: {},
      environment: {},
      state: { view: 'view-channels', channelsRendered: 0 },
      playlists: [],
      diagnostics: [],
      logs: [],
      network: [],
    });

    expect(summary).toContain('channels=? rendered=0');
    expect(summary).not.toContain('Codec support');
  });

  it('keeps long probe failures concise in the terminal summary', () => {
    const summary = formatDiagnosticSummary({
      capturedAt: '2026-01-01T00:00:00.000Z',
      app: {},
      environment: {},
      state: {},
      playlists: [{
        source: 'm3u',
        url: 'http://<host-a>/playlist.m3u',
        webview: { error: 'first line\nsecond line' },
        native: { error: 'x'.repeat(200) },
      }],
      diagnostics: [],
      network: [],
      logs: [],
    });
    expect(summary).not.toContain('second line');
    expect(summary.length).toBeLessThan(500);
  });

  it('formats legacy schema v1 playback events as diagnostics', () => {
    const summary = formatDiagnosticSummary({
      schemaVersion: 1,
      capturedAt: '2026-01-01T00:00:00.000Z',
      app: {},
      environment: {},
      state: {},
      playlists: [],
      playback: [{ code: 'playback.path.native', session: 1 }],
    });

    expect(summary).toContain('Diagnostic events: 1');
    expect(summary).toContain('playback.path.native session=1');
  });
});

describe('diagnostic capture recovery', () => {
  it('returns a marked partial report when CDP closes after the baseline', async () => {
    const listeners = new Map();
    let evaluations = 0;
    const client = {
      closed: false,
      on(method, listener) {
        const current = listeners.get(method) ?? [];
        current.push(listener);
        listeners.set(method, current);
        return () => {};
      },
      async call(method) {
        if (method !== 'Runtime.evaluate') return {};
        evaluations++;
        if (evaluations === 1) {
          return {
            result: {
              value: {
                app: {},
                state: { view: 'view-player', channelsRendered: 4, media: null },
                storage: {},
                environment: { userAgent: 'ua', viewport: '1920x1080' },
                playlists: [],
              },
            },
          };
        }
        for (const listener of listeners.get('Runtime.consoleAPICalled') ?? []) {
          listener({
            type: 'log',
            timestamp: Date.parse('2026-09-10T05:00:00.000Z'),
            args: [{ value: '[Key] Key down event=key.down code=461 action=back target=app' }],
          });
        }
        client.closed = true;
        throw new Error('CDP connection closed');
      },
      close() {
        client.closed = true;
      },
    };
    const options = parseDiagnosticArgs([
      '--host', 'tv',
      '--attach',
      '--duration', '1',
    ]);

    const report = await captureDiagnostics(options, {
      resolveTarget: async () => ({
        target: { title: 'App', description: 'TV app' },
        wsUrl: 'ws://tv/devtools/page/app',
      }),
      connect: async () => client,
      startNativeMetrics: () => ({
        ready: Promise.resolve(),
        result: Promise.resolve({ durationMs: 1000, processes: [] }),
        child: { killed: false, kill() { this.killed = true; } },
      }),
      now: () => new Date('2026-09-10T05:00:01.000Z'),
    });

    expect(report.capture).toEqual({
      complete: false,
      phase: 'capturing-final-state',
      error: 'CDP connection closed',
    });
    expect(report.state).toMatchObject({ view: 'view-player', channelsRendered: 4 });
    expect(report.nativeMetrics).toMatchObject({ durationMs: 1000 });
    expect(report.input).toEqual([
      expect.objectContaining({ event: 'key.down', code: 461, action: 'back' }),
    ]);
    expect(formatDiagnosticSummary(report))
      .toContain('Capture: incomplete at capturing-final-state (CDP connection closed)');
  });
});

describe('active diagnostics probe', () => {
  // The probe is stringified and evaluated inside the TV's webview, so run it
  // the same way here: a real DOM, no bundler, no module scope.
  const runProbe = () => (0, eval)(activeProbeExpression);
  const runSnapshot = () => (0, eval)(snapshotProbeExpression);

  beforeEach(() => {
    localStorage.clear();
    document.body.innerHTML = '';
    window.fetch = () => Promise.reject(new Error('offline'));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  const appInfoResponse = {
    json: async () => ({ id: 'app.id', version: '1.0.0' }),
  };

  it('takes a local snapshot without fetching playlist endpoints', async () => {
    localStorage.setItem('iptv_playlists', JSON.stringify([{
      source: 'm3u',
      name: 'Alpha',
      url: 'http://host/playlist.m3u',
    }]));
    let fetches = 0;
    window.fetch = () => {
      fetches++;
      return Promise.reject(new Error('unexpected fetch'));
    };

    const probe = await runSnapshot();

    expect(fetches).toBe(0);
    expect(probe.playlists).toEqual([
      expect.objectContaining({
        source: 'm3u',
        name: 'Alpha',
        __url: 'http://host/playlist.m3u',
        webview: null,
      }),
    ]);
  });

  it('reports only rendered rows, leaving the catalog size to the load event', async () => {
    document.body.innerHTML = '<div class="channel-item"></div><div class="channel-item"></div>';

    const probe = await runProbe();

    expect(probe.state.channelsRendered).toBe(2);
    expect(probe.state).not.toHaveProperty('channels');
  });

  it('bounds playlist previews with an exact range and cancels ignored ranges', async () => {
    localStorage.setItem('iptv_playlists', JSON.stringify([{
      source: 'm3u',
      name: 'Alpha',
      url: 'http://host/playlist.m3u',
    }]));
    const cancel = vi.fn(async () => {});
    const fetches = [];
    window.fetch = async (url, init) => {
      fetches.push({ url: String(url), init });
      if (String(url) === 'appinfo.json') return appInfoResponse;
      return {
        status: 200,
        headers: {
          get: (name) => ({
            'content-type': 'audio/x-mpegurl',
            'content-length': '9000',
          })[name] || null,
        },
        body: {
          getReader: () => ({
            read: async () => ({
              done: false,
              value: new TextEncoder().encode(`#EXTM3U\n${'a'.repeat(4096)}`),
            }),
            cancel,
          }),
        },
      };
    };

    const probe = await runProbe();

    expect(fetches).toHaveLength(2);
    expect(fetches[1].init.headers).toEqual({ Range: 'bytes=0-2047' });
    expect(fetches[1].init.signal).toBeInstanceOf(AbortSignal);
    expect(cancel).toHaveBeenCalledOnce();
    expect(probe.playlists[0].webview).toMatchObject({
      status: 200,
      contentType: 'audio/x-mpegurl',
      contentLength: '9000',
    });
    expect(probe.playlists[0].webview.bodyPreview).toHaveLength(2048);
  });

  it('aborts a timed-out playlist probe without retrying', async () => {
    vi.useFakeTimers();
    localStorage.setItem('iptv_playlists', JSON.stringify([{
      source: 'm3u',
      name: 'Alpha',
      url: 'http://host/playlist.m3u',
    }]));
    let playlistFetches = 0;
    window.fetch = (url, init) => {
      if (String(url) === 'appinfo.json') return Promise.resolve(appInfoResponse);
      playlistFetches++;
      return new Promise((_resolve, reject) => {
        init.signal.addEventListener('abort', () => reject(new Error('probe timed out')));
      });
    };

    const pending = runProbe();
    await vi.advanceTimersByTimeAsync(5000);
    const probe = await pending;

    expect(playlistFetches).toBe(1);
    expect(probe.playlists[0].webview).toMatchObject({
      status: null,
      bodyPreview: '',
      error: 'Error: probe timed out',
    });
  });

  it('skips webview and native playlist probes for one-connection accounts', async () => {
    localStorage.setItem('iptv_playlists', JSON.stringify([{
      source: 'xtream',
      name: 'Alpha',
      url: 'http://host',
      xtream: { username: 'user1', password: 'pass1', liveOutput: 'auto' },
    }]));
    const urls = [];
    window.fetch = async (url) => {
      urls.push(String(url));
      if (String(url) === 'appinfo.json') return appInfoResponse;
      return {
        status: 200,
        json: async () => ({
          user_info: {
            auth: 1,
            max_connections: '1',
            allowed_output_formats: ['m3u8'],
          },
        }),
      };
    };

    const probe = await runProbe();
    const execFile = vi.fn();
    const native = runNativePlaylistProbe(probe.playlists[0], { execFile });

    expect(urls).toHaveLength(2);
    expect(urls[1]).toContain('/player_api.php?');
    expect(urls.join(' ')).not.toContain('/get.php?');
    expect(probe.playlists[0].webview).toEqual({
      status: null,
      contentType: '',
      contentLength: '',
      bodyPreview: '',
      error: '',
      skipped: true,
      skipReason: 'xtream-max-connections-at-most-one',
    });
    expect(native).toMatchObject({
      skipped: true,
      skipReason: 'xtream-max-connections-at-most-one',
    });
    expect(execFile).not.toHaveBeenCalled();
    expect(JSON.stringify({ webview: probe.playlists[0].webview, native }))
      .not.toContain('user1');
    expect(JSON.stringify({ webview: probe.playlists[0].webview, native }))
      .not.toContain('pass1');
  });

  it('captures each <source> type with its canPlayType verdict', async () => {
    document.body.innerHTML =
      '<video><source src="http://host/movie/u1/p1/7.mkv" type="video/x-matroska"></video>';
    const video = document.querySelector('video');
    video.canPlayType = (type) => (type === 'video/mp4' ? 'probably' : '');

    const probe = await runProbe();

    expect(probe.state.media.sources).toEqual([{
      src: 'http://host/movie/u1/p1/7.mkv',
      type: 'video/x-matroska',
      canPlayType: '',
    }]);
    expect(probe.state.codecSupport['video/mp4']).toBe('probably');
    expect(probe.state.codecSupport['video/x-matroska']).toBe('');
  });

  it('probes container support even with no <video> on the page', async () => {
    const probe = await runProbe();

    expect(probe.state.media).toBeNull();
    expect(Object.keys(probe.state.codecSupport)).toContain('video/x-matroska');
    expect(Object.keys(probe.state.codecSupport)).toContain('audio/mp4; codecs="ec-3"');
  });
});
